import { readJSON, writeJSON } from "./utils/storage";
import React, { useEffect, useMemo, useState } from "react";
/* ════════════════════════════════════════════════════════
   THEME SYSTEM — 4 curated palettes
   ════════════════════════════════════════════════════════ */
const THEMES = {
  carta: {
    name:"Carta Antica", icon:"📜",
    bg:"#F2EDE4", bgAlt:"#EBE4D8", bgCard:"#FFFFFF", bgCardAlt:"#FAF7F2", bgGlass:"rgba(242,237,228,0.90)",
    ink:"#151210", inkSoft:"#3D3530", inkMuted:"#7A7168", inkFaint:"#B0A899", inkGhost:"#D5CFC6",
    accent:"#8B1E2F", accentDeep:"#6A1525", accentGlow:"rgba(139,30,47,0.10)",
    secondary:"#182040", secondaryDeep:"#0F1530",
    gold:"#C19A3E", goldBright:"#D9B44A", goldDim:"rgba(193,154,62,0.30)", goldFaint:"rgba(193,154,62,0.08)",
    success:"#3D7A4A", warning:"#C19A3E", danger:"#8B1E2F",
    div:"rgba(21,18,16,0.07)", divStrong:"rgba(21,18,16,0.14)",
    shadow:"rgba(0,0,0,0.06)", shadowStrong:"rgba(0,0,0,0.12)", grain:0.30,
  },
  ardesia: {
    name:"Ardesia", icon:"🪨",
    bg:"#1A1D24", bgAlt:"#22262F", bgCard:"#262A34", bgCardAlt:"#2C313C", bgGlass:"rgba(26,29,36,0.92)",
    ink:"#E8E4DD", inkSoft:"#C5C0B8", inkMuted:"#8A857D", inkFaint:"#5C5850", inkGhost:"#3A3833",
    accent:"#C75B5B", accentDeep:"#A04040", accentGlow:"rgba(199,91,91,0.15)",
    secondary:"#4A6FA5", secondaryDeep:"#3A5A8A",
    gold:"#D4A843", goldBright:"#E8BC55", goldDim:"rgba(212,168,67,0.30)", goldFaint:"rgba(212,168,67,0.10)",
    success:"#5B9E6F", warning:"#D4A843", danger:"#C75B5B",
    div:"rgba(255,255,255,0.06)", divStrong:"rgba(255,255,255,0.12)",
    shadow:"rgba(0,0,0,0.25)", shadowStrong:"rgba(0,0,0,0.45)", grain:0.15,
  },
  notte: {
    name:"Blu Notte", icon:"🌙",
    bg:"#0D1117", bgAlt:"#151B26", bgCard:"#1A2233", bgCardAlt:"#1F2940", bgGlass:"rgba(13,17,23,0.92)",
    ink:"#E6E1D6", inkSoft:"#B8B3A8", inkMuted:"#6E6A62", inkFaint:"#484540", inkGhost:"#2E2C28",
    accent:"#E85D5D", accentDeep:"#C04040", accentGlow:"rgba(232,93,93,0.12)",
    secondary:"#5B8DD9", secondaryDeep:"#4070B8",
    gold:"#F0C050", goldBright:"#FFD466", goldDim:"rgba(240,192,80,0.28)", goldFaint:"rgba(240,192,80,0.08)",
    success:"#60B878", warning:"#F0C050", danger:"#E85D5D",
    div:"rgba(255,255,255,0.05)", divStrong:"rgba(255,255,255,0.10)",
    shadow:"rgba(0,0,0,0.35)", shadowStrong:"rgba(0,0,0,0.55)", grain:0.12,
  },
  avorio: {
    name:"Avorio Reale", icon:"👑",
    bg:"#FDFBF7", bgAlt:"#F5F1EA", bgCard:"#FFFFFF", bgCardAlt:"#FEFCF8", bgGlass:"rgba(253,251,247,0.90)",
    ink:"#1C1810", inkSoft:"#3E3A30", inkMuted:"#807A6E", inkFaint:"#ADA798", inkGhost:"#D8D2C8",
    accent:"#7A2842", accentDeep:"#5C1830", accentGlow:"rgba(122,40,66,0.08)",
    secondary:"#2A3F6A", secondaryDeep:"#1C2E52",
    gold:"#B08A30", goldBright:"#CCA040", goldDim:"rgba(176,138,48,0.28)", goldFaint:"rgba(176,138,48,0.06)",
    success:"#3A7848", warning:"#B08A30", danger:"#7A2842",
    div:"rgba(28,24,16,0.06)", divStrong:"rgba(28,24,16,0.12)",
    shadow:"rgba(0,0,0,0.04)", shadowStrong:"rgba(0,0,0,0.10)", grain:0.25,
  },
};

/* ════════════════════════════════════════════════════════
   STORE — useReducer + localStorage
   ════════════════════════════════════════════════════════ */
const STORAGE_KEY = "kitchen-pro-v4";
const nowISO  = () => new Date().toISOString();
const todayDate = () => new Date().toISOString().slice(0,10);
const genId   = () => Math.random().toString(36).slice(2,9) + Date.now().toString(36);

function mapStock(k, loc) {
  if (loc==="freezer") return k.freezer;
  if (loc==="fridge")  return k.fridge;
  if (loc==="dry")     return k.dry;
  return k.counter;
}
function setStock(k, loc, next) {
  if (loc==="freezer") return {...k, freezer:next};
  if (loc==="fridge")  return {...k, fridge:next};
  if (loc==="dry")     return {...k, dry:next};
  return {...k, counter:next};
}
function findLoc(k, id) {
  if (k.freezer.some(x=>x.id===id)) return "freezer";
  if (k.fridge.some(x=>x.id===id))  return "fridge";
  if (k.dry.some(x=>x.id===id))     return "dry";
  if (k.counter.some(x=>x.id===id)) return "counter";
  return null;
}
function mkKitchen(name, ownerName="Admin") {
  const owner = { id:genId(), name:ownerName.trim()||"Admin", role:"admin", joinedAt:nowISO() };
  return {
    id:genId(), name:name.trim(), ownerName:owner.name, createdAt:nowISO(),
    members:[owner], freezer:[], fridge:[], dry:[], counter:[],
    parByCategory:{}, shopping:[], ledger:[],
  };
}
function ensureKitchen(k) {
  return { ledger:[], shopping:[], parByCategory:{}, freezer:[], fridge:[], dry:[], counter:[], members:[], ...k };
}

function reducer(state, action) {
  const { kitchens } = state;
  const mapK = (id, fn) => kitchens.map(k => k.id!==id ? k : fn(ensureKitchen(k)));

  switch (action.type) {
    case "KITCHEN_CREATE":
      return { ...state, kitchens:[...kitchens, action.kitchen], selectedKitchenId:action.kitchen.id, selectedMemberId:action.kitchen.members[0]?.id };
    case "KITCHEN_SELECT":
      return { ...state, selectedKitchenId:action.id };
    case "MEMBER_SELECT":
      return { ...state, selectedMemberId:action.id };
    case "MEMBER_ADD":
      return { ...state, kitchens: mapK(action.kitchenId, k => ({...k, members:[...k.members, action.member]})) };
    case "MEMBER_ROLE":
      return { ...state, kitchens: mapK(action.kitchenId, k => ({...k, members:k.members.map(m=>m.id!==action.memberId?m:{...m,role:action.role})})) };
    case "MEMBER_REMOVE":
      return { ...state, kitchens: mapK(action.kitchenId, k => ({...k, members:k.members.filter(m=>m.id!==action.memberId)})), selectedMemberId: state.selectedMemberId===action.memberId?undefined:state.selectedMemberId };
    case "PAR_CATEGORY":
      return { ...state, kitchens: mapK(action.kitchenId, k => ({...k, parByCategory:{...k.parByCategory,[action.key]:action.par}})) };
    case "STOCK_ADD":
      return { ...state, kitchens: mapK(action.kitchenId, k => { const loc=action.item.location; return setStock(k,loc,[action.item,...mapStock(k,loc)]); }) };
    case "ITEM_ADJUST":
      return { ...state, kitchens: mapK(action.kitchenId, k => { const loc=findLoc(k,action.id); if(!loc)return k; return setStock(k,loc,mapStock(k,loc).map(x=>x.id!==action.id?x:{...x,quantity:Math.max(0,(x.quantity||0)+action.delta)}).filter(x=>x.quantity>0)); }) };
    case "ITEM_REMOVE":
      return { ...state, kitchens: mapK(action.kitchenId, k => { const loc=findLoc(k,action.id); if(!loc)return k; return setStock(k,loc,mapStock(k,loc).filter(x=>x.id!==action.id)); }) };
    case "ITEM_PAR":
      return { ...state, kitchens: mapK(action.kitchenId, k => { const loc=findLoc(k,action.id); if(!loc)return k; return setStock(k,loc,mapStock(k,loc).map(x=>x.id!==action.id?x:{...x,parLevel:action.par})); }) };
    case "STOCK_MOVE": {
      return { ...state, kitchens: mapK(action.kitchenId, k => {
        const fromLoc = findLoc(k,action.id); if(!fromLoc)return k;
        const src = mapStock(k,fromLoc).find(x=>x.id===action.id); if(!src)return k;
        const qty = Math.min(Number(action.qty)||0, src.quantity); if(qty<=0)return k;
        const remaining = src.quantity - qty;
        const moved = {...src, id:genId(), location:action.to, quantity:qty, insertedAt:nowISO(), insertedDate:todayDate()};
        const ledgerRow = {id:genId(), at:nowISO(), itemId:src.id, name:src.name, qty, unit:src.unit, from:fromLoc, to:action.to, lot:src.lot};
        let upd = setStock(k, fromLoc, mapStock(k,fromLoc).map(x=>x.id!==action.id?x:{...x,quantity:remaining}).filter(x=>x.quantity>0));
        upd = setStock(upd, action.to, [moved, ...mapStock(upd,action.to)]);
        return {...upd, ledger:[ledgerRow, ...upd.ledger]};
      })};
    }
    case "SHOP_ADD":
      return { ...state, kitchens: mapK(action.kitchenId, k => ({...k, shopping:[action.item,...k.shopping]})) };
    case "SHOP_TOGGLE":
      return { ...state, kitchens: mapK(action.kitchenId, k => ({...k, shopping:k.shopping.map(x=>x.id!==action.id?x:{...x,checked:!x.checked})})) };
    case "SHOP_REMOVE":
      return { ...state, kitchens: mapK(action.kitchenId, k => ({...k, shopping:k.shopping.filter(x=>x.id!==action.id)})) };
    case "SHOP_CLEAR":
      return { ...state, kitchens: mapK(action.kitchenId, k => ({...k, shopping:k.shopping.filter(x=>!x.checked || (action.cat && x.category!==action.cat))})) };
    default: return state;
  }
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { kitchens:[] };
    const p = JSON.parse(raw);
    if (!p || !Array.isArray(p.kitchens)) return { kitchens:[] };
    p.kitchens = p.kitchens.map(ensureKitchen);
    return p;
  } catch { return { kitchens:[] }; }
}

const KCtx = createContext(null);

function KitchenProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadState);
  useEffect(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {} }, [state]);

  const api = useMemo(() => {
    const kid = () => state.selectedKitchenId || state.kitchens[0]?.id;
    const curKitchen = () => state.kitchens.find(k=>k.id===kid());

    return {
      state,
      kitchen: curKitchen(),
      currentRole: () => { const k=curKitchen(); if(!k)return"admin"; const m=k.members.find(x=>x.id===state.selectedMemberId)||k.members[0]; return m?.role||"admin"; },
      allItems: () => { const k=curKitchen(); if(!k)return[]; return [...k.freezer,...k.fridge,...k.dry,...k.counter]; },

      createKitchen: (name, owner) => { if(!(name||"").trim())return; dispatch({type:"KITCHEN_CREATE", kitchen:mkKitchen(name,owner)}); },
      selectKitchen: (id) => dispatch({type:"KITCHEN_SELECT",id}),
      selectMember: (id) => dispatch({type:"MEMBER_SELECT",id}),

      addMember: (name, role="staff") => { const k=kid(); if(!k||!(name||"").trim())return; dispatch({type:"MEMBER_ADD",kitchenId:k,member:{id:genId(),name:name.trim(),role,joinedAt:nowISO()}}); },
      updateRole: (memberId, role) => { const k=kid(); if(k)dispatch({type:"MEMBER_ROLE",kitchenId:k,memberId,role}); },
      removeMember: (memberId) => { const k=kid(); if(k)dispatch({type:"MEMBER_REMOVE",kitchenId:k,memberId}); },

      setParCategory: (key, par) => { const k=kid(); if(k)dispatch({type:"PAR_CATEGORY",kitchenId:k,key,par:Math.max(0,Number(par)||0)}); },

      stockAdd: (item) => {
        const k=kid(); if(!k)return;
        const name=(item.name||"").trim(); const qty=Number(item.quantity);
        if(!name||!isFinite(qty)||qty<=0)return;
        dispatch({type:"STOCK_ADD",kitchenId:k,item:{
          id:genId(),name,quantity:qty,unit:item.unit||"pz",location:item.location||"fridge",
          insertedAt:item.insertedAt||nowISO(),insertedDate:item.insertedDate||todayDate(),
          expiresAt:item.expiresAt,lot:item.lot,notes:item.notes,category:item.category,parLevel:item.parLevel,
        }});
      },
      adjustItem: (id, delta) => { const k=kid(); if(k)dispatch({type:"ITEM_ADJUST",kitchenId:k,id,delta:Number(delta)||0}); },
      removeItem: (id) => { const k=kid(); if(k)dispatch({type:"ITEM_REMOVE",kitchenId:k,id}); },
      setItemPar: (id, par) => { const k=kid(); if(k)dispatch({type:"ITEM_PAR",kitchenId:k,id,par}); },
      moveStock: (id, qty, to) => { const k=kid(); if(k)dispatch({type:"STOCK_MOVE",kitchenId:k,id,qty,to}); },

      shopAdd: (name, qty, unit, category, notes) => {
        const k=kid(); if(!k)return;
        const n=(name||"").trim(); const q=Number(qty);
        if(!n||!isFinite(q)||q<=0)return;
        dispatch({type:"SHOP_ADD",kitchenId:k,item:{id:genId(),name:n,quantity:q,unit,category,notes:(notes||"").trim()||undefined,checked:false,createdAt:nowISO()}});
      },
      shopToggle: (id) => { const k=kid(); if(k)dispatch({type:"SHOP_TOGGLE",kitchenId:k,id}); },
      shopRemove: (id) => { const k=kid(); if(k)dispatch({type:"SHOP_REMOVE",kitchenId:k,id}); },
      shopClear: (cat) => { const k=kid(); if(k)dispatch({type:"SHOP_CLEAR",kitchenId:k,cat}); },
    };
  }, [state]);

  return <KCtx.Provider value={api}>{children}</KCtx.Provider>;
}
const useK = () => useContext(KCtx);

/* ════════════════════════════════════════════════════════
   TOAST
   ════════════════════════════════════════════════════════ */
const ToastCtx = createContext(null);
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const show = useCallback((msg, type="info") => {
    const id = genId();
    setToasts(p=>[...p, {id,msg,type}]);
    setTimeout(()=>setToasts(p=>p.filter(t=>t.id!==id)), 3000);
  },[]);
  return (
    <ToastCtx.Provider value={show}>
      {children}
      <div style={{position:"fixed",top:20,right:20,zIndex:9999,display:"flex",flexDirection:"column",gap:8}}>
        {toasts.map(t=>(
          <div key={t.id} style={{
            padding:"10px 18px",borderRadius:10,fontSize:12,fontFamily:"var(--mono)",fontWeight:500,
            letterSpacing:"0.04em",
            background: t.type==="success"?"#3D7A4A": t.type==="error"?"#8B1E2F":"#C19A3E",
            color:"#fff", boxShadow:"0 4px 20px rgba(0,0,0,0.2)",
            animation:"toastIn 0.3s cubic-bezier(0.4,0,0.2,1) both",
          }}>{t.msg}</div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
const useToast = () => useContext(ToastCtx);

/* ════════════════════════════════════════════════════════
   SPEECH HOOK
   ════════════════════════════════════════════════════════ */
function useSpeech(onResult) {
  const [listening, setListening] = useState(false);
  const recRef = useRef(null);
  const supported = typeof window!=="undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window);

  const start = useCallback(()=>{
    if(!supported||listening) return;
    const SR = window.SpeechRecognition||window.webkitSpeechRecognition;
    const r = new SR(); r.lang="it-IT"; r.interimResults=false; r.maxAlternatives=1;
    r.onresult = e => { try { onResult(e.results[0][0].transcript); }catch{} };
    r.onerror = () => setListening(false);
    r.onend = () => setListening(false);
    recRef.current = r;
    try { r.start(); setListening(true); } catch { setListening(false); }
  },[supported,listening,onResult]);

  const stop = useCallback(()=>{ recRef.current?.stop(); setListening(false); },[]);
  useEffect(()=>()=>recRef.current?.abort(),[]);
  return { listening, start, stop, supported };
}

/* ════════════════════════════════════════════════════════
   UTILITY
   ════════════════════════════════════════════════════════ */
const CATEGORIES = {
  proteine:"Proteine",pesce:"Pesce",verdure:"Verdure",erbe:"Erbe",
  dairy:"Latticini",cereali:"Cereali",grassi:"Grassi",acidi:"Acidi",
  spezie:"Spezie",fondi:"Fondi",beverage:"Beverage",secco:"Secco",
};
const PAR_PRESET = {proteine:6,pesce:4,verdure:8,erbe:12,dairy:6,cereali:3,grassi:4,acidi:6,spezie:10,fondi:4,beverage:6,secco:5};
const UNITS = ["pz","g","kg","ml","l","vac","busta","brik","latta","box","vasch"];
const ROLES = ["admin","chef","sous-chef","capo-partita","commis","stagista","staff","fb","mm"];
const CAN_EDIT = ["admin","chef","sous-chef","capo-partita"];

function hoursUntil(iso) {
  if(!iso) return null;
  return (new Date(iso)-new Date())/3600000;
}
function expiryBadge(iso) {
  const h = hoursUntil(iso);
  if(h===null) return null;
  if(h<=0)  return {label:"SCADUTO",  color:"#fff", bg:"#8B1E2F"};
  if(h<=24) return {label:"≤24h",     color:"#fff", bg:"#8B1E2F"};
  if(h<=72) return {label:"≤72h",     color:"#fff", bg:"#C19A3E"};
  return null;
}
function stepFor(unit) {
  if(["g","ml"].includes(unit)) return [100,500];
  if(["kg","l"].includes(unit)) return [0.5,1];
  return [1,5];
}
function fmtDate(iso) { return iso ? iso.slice(0,10) : "—"; }

/* ════════════════════════════════════════════════════════
   MICRO-COMPONENTS
   ════════════════════════════════════════════════════════ */
function LiveClock({ t }) {
  const [now,setNow]=useState(new Date());
  useEffect(()=>{ const i=setInterval(()=>setNow(new Date()),1000); return()=>clearInterval(i);},[]);
  return (
    <span className="mono" style={{fontSize:13,color:t.gold,letterSpacing:"0.06em"}}>
      {now.toLocaleTimeString("it-IT",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}
    </span>
  );
}

function BarMini({ value, max, t, color }) {
  const pct = Math.min((value/max)*100,100);
  const isLow = value/max < 0.25;
  const c = color||(isLow?t.danger:pct<50?t.warning:t.success);
  return (
    <div style={{height:4,background:t.div,borderRadius:2,overflow:"hidden",flex:1}}>
      <div style={{height:"100%",width:`${pct}%`,background:c,borderRadius:2,transition:"width 0.8s cubic-bezier(0.4,0,0.2,1)"}}/>
    </div>
  );
}

function Badge({ label, color, bg, style:sx={} }) {
  return (
    <span className="mono" style={{fontSize:8,letterSpacing:"0.1em",fontWeight:500,padding:"3px 9px",borderRadius:4,color,background:bg,whiteSpace:"nowrap",...sx}}>
      {label}
    </span>
  );
}

function Btn({ onClick, disabled, children, variant="primary", t, style:sx={} }) {
  const variants = {
    primary:{ background:`linear-gradient(135deg, ${t.secondary}, ${t.secondaryDeep})`, color:"#fff", border:"none" },
    danger: { background:`linear-gradient(135deg, ${t.accent}, ${t.accentDeep})`, color:"#fff", border:"none" },
    ghost:  { background:"transparent", color:t.inkMuted, border:`1px solid ${t.div}` },
    gold:   { background:`linear-gradient(135deg, ${t.gold}, ${t.goldBright})`, color:"#fff", border:"none" },
  };
  return (
    <button disabled={disabled} onClick={onClick} style={{
      padding:"8px 18px",borderRadius:8,cursor:disabled?"not-allowed":"pointer",
      fontSize:10,fontFamily:"var(--mono)",fontWeight:500,letterSpacing:"0.08em",
      opacity:disabled?0.45:1,transition:"all 0.2s",...variants[variant],...sx,
    }}
    onMouseEnter={e=>{if(!disabled)e.currentTarget.style.filter="brightness(1.08)";}}
    onMouseLeave={e=>{e.currentTarget.style.filter="none";}}
    >{children}</button>
  );
}

function LuxInput({ value, onChange, placeholder, type="text", t, style:sx={} }) {
  return (
    <input value={value} onChange={onChange} type={type} placeholder={placeholder}
      style={{
        width:"100%",padding:"9px 14px",borderRadius:8,fontSize:12,fontFamily:"var(--serif)",
        background:t.bgCardAlt,color:t.ink,border:`1px solid ${t.div}`,outline:"none",
        transition:"border-color 0.2s",...sx,
      }}
      onFocus={e=>e.target.style.borderColor=t.gold}
      onBlur={e=>e.target.style.borderColor=t.div}
    />
  );
}

function LuxSelect({ value, onChange, children, t, style:sx={} }) {
  return (
    <select value={value} onChange={onChange} style={{
      width:"100%",padding:"9px 14px",borderRadius:8,fontSize:12,fontFamily:"var(--mono)",
      background:t.bgCardAlt,color:t.ink,border:`1px solid ${t.div}`,outline:"none",cursor:"pointer",...sx,
    }}>{children}</select>
  );
}

function VoiceBtn({ t, onResult }) {
  const speech = useSpeech(onResult);
  if(!speech.supported) return null;
  return (
    <button onClick={speech.listening?speech.stop:speech.start} style={{
      width:34,height:34,borderRadius:"50%",border:"none",cursor:"pointer",
      background:speech.listening?`linear-gradient(135deg,${t.accent},${t.accentDeep})`:`${t.div}`,
      display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,
      flexShrink:0,transition:"all 0.2s",
      animation:speech.listening?"pulse 1s ease-in-out infinite":"none",
    }} title={speech.listening?"Stop":"Parla"}>🎤</button>
  );
}

function Card({ children, t, style:sx={}, glow=false }) {
  return (
    <div style={{
      background:t.bgCard,borderRadius:14,border:`1px solid ${glow?t.accent+"30":t.div}`,
      boxShadow:glow?`0 4px 20px ${t.accentGlow}`:`0 2px 12px ${t.shadow}`,
      overflow:"hidden",transition:"all 0.3s",...sx,
    }}>{children}</div>
  );
}

function CardHeader({ title, right, t }) {
  return (
    <div style={{padding:"16px 22px",borderBottom:`1px solid ${t.div}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
      <span className="mono" style={{fontSize:9,letterSpacing:"0.14em",color:t.inkMuted,fontWeight:500,textTransform:"uppercase"}}>{title}</span>
      {right}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   SETUP SCREEN
   ════════════════════════════════════════════════════════ */
function SetupScreen({ t }) {
  const { createKitchen } = useK();
  const [name, setName] = useState("");
  const [owner, setOwner] = useState("");
  return (
    <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:t.bg}}>
      <Card t={t} style={{width:420,padding:40}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{
            width:64,height:64,borderRadius:"50%",margin:"0 auto 16px",
            background:`linear-gradient(135deg,${t.secondary},${t.secondaryDeep})`,
            border:`2px solid ${t.goldBright}`,display:"flex",alignItems:"center",justifyContent:"center",
          }}>
            <span className="mono" style={{fontSize:11,color:t.goldBright}}>★★★</span>
          </div>
          <div style={{fontFamily:"var(--serif)",fontSize:26,fontWeight:500,color:t.ink,marginBottom:6}}>Kitchen Pro</div>
          <div className="mono" style={{fontSize:8,letterSpacing:"0.2em",color:t.inkFaint}}>CREA LA TUA CUCINA</div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <LuxInput value={name} onChange={e=>setName(e.target.value)} placeholder="Nome cucina / ristorante" t={t}/>
          <LuxInput value={owner} onChange={e=>setOwner(e.target.value)} placeholder="Tuo nome (admin)" t={t}/>
          <Btn t={t} onClick={()=>createKitchen(name,owner)} disabled={!name.trim()} variant="primary" sx={{marginTop:8}}>
            Crea Cucina
          </Btn>
        </div>
      </Card>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   DASHBOARD
   ════════════════════════════════════════════════════════ */
function DashboardView({ t }) {
  const { kitchen, allItems } = useK();
  if (!kitchen) return null;

  const items = allItems();
  const now = new Date();
  const expired  = items.filter(x=>x.expiresAt && new Date(x.expiresAt)<now);
  const urgent   = items.filter(x=>{ const h=hoursUntil(x.expiresAt); return h!==null&&h>0&&h<=72; });
  const k = kitchen;
  const parKeys  = Object.keys(PAR_PRESET);
  const lowItems = items.filter(x=>{
    const par = x.parLevel ?? (x.category ? PAR_PRESET[x.category] : null) ?? (k.parByCategory[x.category]||0);
    return par>0 && x.quantity<par;
  });

  const kpis = [
    {label:"REFERENZE",val:items.length,sub:"totali",icon:"◆"},
    {label:"SCADUTI",val:expired.length,sub:"articoli",icon:"⚠",hi:expired.length>0},
    {label:"URGENTI ≤72h",val:urgent.length,sub:"articoli",icon:"⏱",hi:urgent.length>0},
    {label:"SOTTO PAR",val:lowItems.length,sub:"articoli",icon:"↓",hi:lowItems.length>0},
  ];

  return (
    <div style={{display:"flex",flexDirection:"column",gap:24}}>
      {/* KPI */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14}}>
        {kpis.map((kpi,i)=>(
          <Card key={i} t={t} glow={kpi.hi} style={{padding:"20px 22px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
              <span className="mono" style={{fontSize:8,letterSpacing:"0.16em",color:t.inkFaint}}>{kpi.label}</span>
              <span style={{fontSize:16,color:kpi.hi?t.accent:t.goldDim,lineHeight:1}}>{kpi.icon}</span>
            </div>
            <div style={{display:"flex",alignItems:"baseline",gap:6}}>
              <span style={{fontSize:32,fontWeight:400,fontFamily:"var(--serif)",color:kpi.hi?t.accent:t.ink,lineHeight:1}}>{kpi.val}</span>
              <span className="mono" style={{fontSize:10,color:t.inkFaint}}>{kpi.sub}</span>
            </div>
          </Card>
        ))}
      </div>

      {/* Urgenti + Shopping preview */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
        {/* Scadenze urgenti */}
        <Card t={t}>
          <CardHeader t={t} title="Scadenze urgenti"
            right={<Badge label={`${urgent.length+expired.length}`} color={t.danger} bg={t.accentGlow}/>}/>
          <div style={{padding:"8px 0"}}>
            {[...expired,...urgent].length===0 ? (
              <div style={{padding:"20px 22px",color:t.inkFaint,fontSize:12,fontFamily:"var(--serif)",fontStyle:"italic"}}>✓ Nessun articolo in scadenza</div>
            ) : [...expired,...urgent].slice(0,6).map((item,i)=>{
              const badge = expiryBadge(item.expiresAt);
              return (
                <div key={item.id} style={{padding:"11px 22px",display:"flex",alignItems:"center",gap:12,borderBottom:i<5?`1px solid ${t.div}`:"none"}}>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontFamily:"var(--serif)",color:t.ink,fontWeight:500}}>{item.name}</div>
                    <div className="mono" style={{fontSize:9,color:t.inkFaint}}>{item.location} · {item.quantity} {item.unit}</div>
                  </div>
                  {badge&&<Badge label={badge.label} color={badge.color} bg={badge.bg}/>}
                </div>
              );
            })}
          </div>
        </Card>

        {/* Sotto par */}
        <Card t={t}>
          <CardHeader t={t} title="Sotto livello PAR"
            right={<Badge label={`${lowItems.length}`} color={t.warning} bg={t.goldFaint}/>}/>
          <div style={{padding:"8px 0"}}>
            {lowItems.length===0 ? (
              <div style={{padding:"20px 22px",color:t.inkFaint,fontSize:12,fontFamily:"var(--serif)",fontStyle:"italic"}}>✓ Tutti i livelli nella norma</div>
            ) : lowItems.slice(0,6).map((item,i)=>{
              const par = item.parLevel ?? PAR_PRESET[item.category] ?? 0;
              return (
                <div key={item.id} style={{padding:"11px 22px",display:"flex",alignItems:"center",gap:12,borderBottom:i<5?`1px solid ${t.div}`:"none"}}>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontFamily:"var(--serif)",color:t.ink,fontWeight:500}}>{item.name}</div>
                    <div className="mono" style={{fontSize:9,color:t.inkFaint}}>{item.quantity}/{par} {item.unit}</div>
                  </div>
                  <BarMini value={item.quantity} max={par||1} t={t}/>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Shopping list preview */}
      {(kitchen.shopping||[]).length>0 && (
        <Card t={t}>
          <CardHeader t={t} title="Lista della spesa"
            right={<Badge label={`${kitchen.shopping.filter(x=>!x.checked).length} da fare`} color={t.secondary} bg={t.goldFaint}/>}/>
          <div style={{padding:"12px 22px",display:"flex",flexWrap:"wrap",gap:8}}>
            {kitchen.shopping.filter(x=>!x.checked).slice(0,12).map(x=>(
              <Badge key={x.id} label={`${x.name} ×${x.quantity}${x.unit}`} color={t.inkSoft} bg={t.bgAlt}/>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   INVENTORY VIEW
   ════════════════════════════════════════════════════════ */
function InventoryView({ t }) {
  const { kitchen, stockAdd, adjustItem, removeItem, setItemPar, currentRole } = useK();
  const toast = useToast();
  const canEdit = CAN_EDIT.includes(currentRole());

  const [loc,    setLoc]    = useState("fridge");
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);

  // Form state
  const [fName,     setFName]     = useState("");
  const [fQty,      setFQty]      = useState("1");
  const [fUnit,     setFUnit]     = useState("pz");
  const [fCat,      setFCat]      = useState("proteine");
  const [fLot,      setFLot]      = useState("");
  const [fExpiry,   setFExpiry]   = useState("");
  const [fNotes,    setFNotes]    = useState("");

  const speech = useSpeech(t=>setFName(t));

  const LOCS = [
    {key:"fridge",   label:"Frigo",       icon:"❄️", temp:"2-4°C"},
    {key:"freezer",  label:"Congelatore", icon:"🧊", temp:"-18°C"},
    {key:"dry",      label:"Dispensa",    icon:"🏺", temp:"Ambiente"},
    {key:"counter",  label:"Banco",       icon:"🍽️", temp:"Servizio"},
  ];

  const items = ((kitchen||{})[loc]||[]).filter(item=>{
    if(!search) return true;
    return item.name.toLowerCase().includes(search.toLowerCase()) || (item.lot||"").toLowerCase().includes(search.toLowerCase());
  });

  function submitStock() {
    const qty=parseFloat(fQty);
    if(!fName.trim()||!isFinite(qty)||qty<=0) { toast("Compila nome e quantità","error"); return; }
    stockAdd({
      name:fName,quantity:qty,unit:fUnit,location:loc,category:fCat,
      lot:fLot||undefined,expiresAt:fExpiry?new Date(fExpiry).toISOString():undefined,
      notes:fNotes||undefined,insertedDate:todayDate(),
    });
    toast(`${fName} aggiunto/a`,"success");
    setFName(""); setFQty("1"); setFLot(""); setFExpiry(""); setFNotes("");
  }

  return (
    <div style={{display:"flex",flexDirection:"column",gap:20}}>
      {/* Location tabs */}
      <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
        {LOCS.map(l=>(
          <button key={l.key} onClick={()=>setLoc(l.key)} style={{
            padding:"10px 20px",borderRadius:12,border:"none",cursor:"pointer",
            display:"flex",alignItems:"center",gap:8,fontFamily:"var(--mono)",fontSize:10,letterSpacing:"0.08em",
            background:loc===l.key?`linear-gradient(135deg,${t.secondary},${t.secondaryDeep})`:t.bgCard,
            color:loc===l.key?"#fff":t.inkMuted,
            boxShadow:loc===l.key?`0 4px 20px ${t.shadow}`:`0 1px 4px ${t.shadow}`,
            border:loc===l.key?"none":`1px solid ${t.div}`,
            transform:loc===l.key?"scale(1.02)":"scale(1)",transition:"all 0.3s",
          }}>
            <span style={{fontSize:16}}>{l.icon}</span>{l.label}
            <span style={{fontSize:8,opacity:0.7}}>{l.temp}</span>
            <span style={{background:loc===l.key?"rgba(255,255,255,0.2)":t.div,padding:"2px 8px",borderRadius:10,fontSize:9}}>
              {(kitchen?.[loc]||[]).length}
            </span>
          </button>
        ))}
      </div>

      {/* Search + Add */}
      <div style={{display:"flex",gap:10}}>
        <LuxInput value={search} onChange={e=>setSearch(e.target.value)} placeholder="Cerca per nome o lotto…" t={t} style={{flex:1}}/>
        {canEdit&&<Btn t={t} variant={showForm?"ghost":"primary"} onClick={()=>setShowForm(!showForm)}>
          {showForm?"✕ Chiudi":"+ Aggiungi"}
        </Btn>}
      </div>

      {/* Add form */}
      {showForm&&canEdit&&(
        <Card t={t} style={{padding:20}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:12}}>
            <div style={{display:"flex",gap:8}}>
              <LuxInput value={fName} onChange={e=>setFName(e.target.value)} placeholder="Nome prodotto" t={t} style={{flex:1}}/>
              <VoiceBtn t={t} onResult={r=>setFName(r)}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <LuxInput value={fQty} onChange={e=>setFQty(e.target.value)} type="number" placeholder="Qtà" t={t}/>
              <LuxSelect value={fUnit} onChange={e=>setFUnit(e.target.value)} t={t}>
                {UNITS.map(u=><option key={u} value={u}>{u}</option>)}
              </LuxSelect>
            </div>
            <LuxSelect value={fCat} onChange={e=>setFCat(e.target.value)} t={t}>
              {Object.entries(CATEGORIES).map(([k,v])=><option key={k} value={k}>{v}</option>)}
            </LuxSelect>
            <LuxInput value={fLot} onChange={e=>setFLot(e.target.value)} placeholder="Lotto (HACCP)" t={t}/>
            <LuxInput value={fExpiry} onChange={e=>setFExpiry(e.target.value)} type="date" t={t}/>
            <LuxInput value={fNotes} onChange={e=>setFNotes(e.target.value)} placeholder="Note" t={t}/>
          </div>
          <Btn t={t} variant="gold" onClick={submitStock} disabled={!fName.trim()}>Carica in {LOCS.find(l=>l.key===loc)?.label}</Btn>
        </Card>
      )}

      {/* Items grid */}
      {items.length===0 ? (
        <div style={{textAlign:"center",padding:"48px 0",color:t.inkFaint}}>
          <div style={{fontFamily:"var(--serif)",fontSize:20,fontStyle:"italic",marginBottom:8}}>Nessun articolo</div>
          <div className="mono" style={{fontSize:9,letterSpacing:"0.14em"}}>
            {search?"NESSUN RISULTATO PER LA RICERCA":"SEZIONE VUOTA — AGGIUNGI PRODOTTI"}
          </div>
        </div>
      ) : (
        <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:12}}>
          {items.map((item,idx)=>{
            const badge  = expiryBadge(item.expiresAt);
            const par    = item.parLevel ?? PAR_PRESET[item.category] ?? 0;
            const isLow  = par>0 && item.quantity<par;
            const [sm,lg] = stepFor(item.unit);
            return (
              <div key={item.id} style={{
                background:t.bgCard,borderRadius:12,overflow:"hidden",
                border:`1px solid ${badge&&badge.bg==="#8B1E2F"?t.accent+"40":t.div}`,
                boxShadow:badge?`0 4px 20px ${t.accentGlow}`:`0 1px 6px ${t.shadow}`,
                animation:`cardIn 0.4s cubic-bezier(0.4,0,0.2,1) ${idx*0.04}s both`,
                transition:"all 0.3s",
              }}
              onMouseEnter={e=>e.currentTarget.style.transform="translateY(-2px)"}
              onMouseLeave={e=>e.currentTarget.style.transform="translateY(0)"}>
                {/* time progress bar at top */}
                {item.expiresAt&&(()=>{
                  const h=hoursUntil(item.expiresAt);
                  const maxH=72;
                  const pct = h===null?100:Math.min(Math.max((1-h/maxH)*100,0),100);
                  const barColor = !h||h<=0?t.danger:h<=24?t.danger:h<=72?t.warning:t.success;
                  return <div style={{height:3,background:t.bgAlt}}><div style={{height:"100%",width:`${pct}%`,background:barColor,transition:"width 1s"}}/></div>;
                })()}

                <div style={{padding:"16px 20px"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:14,fontWeight:500,fontFamily:"var(--serif)",color:t.ink,marginBottom:3,fontStyle:"italic"}}>{item.name}</div>
                      <div className="mono" style={{fontSize:9,color:t.inkFaint}}>
                        {CATEGORIES[item.category]||item.category||"—"}
                        {item.lot&&` · ${item.lot}`}
                        {item.expiresAt&&` · Scad. ${fmtDate(item.expiresAt)}`}
                      </div>
                    </div>
                    <div style={{textAlign:"right",flexShrink:0,marginLeft:12}}>
                      <span style={{fontSize:24,fontWeight:300,fontFamily:"var(--serif)",color:isLow?t.danger:t.ink,lineHeight:1}}>{item.quantity}</span>
                      <span className="mono" style={{fontSize:9,color:t.inkFaint,display:"block"}}>{item.unit}</span>
                    </div>
                  </div>

                  {par>0&&<div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
                    <BarMini value={item.quantity} max={par} t={t}/>
                    <span className="mono" style={{fontSize:8,color:t.inkFaint,minWidth:48,textAlign:"right"}}>par {par}</span>
                  </div>}

                  <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:8}}>
                    {badge&&<Badge label={badge.label} color={badge.color} bg={badge.bg}/>}
                    {isLow&&<Badge label="↓ SCORTA" color={t.warning} bg={t.goldFaint}/>}
                  </div>

                  {canEdit&&(
                    <div style={{display:"flex",gap:6,alignItems:"center"}}>
                      <button onClick={()=>adjustItem(item.id,-sm)} style={btnSmall(t)}>−{sm}</button>
                      <button onClick={()=>adjustItem(item.id,-lg)} style={btnSmall(t)}>−{lg}</button>
                      <button onClick={()=>adjustItem(item.id,+sm)} style={{...btnSmall(t),background:t.success+"20",color:t.success}}>+{sm}</button>
                      <button onClick={()=>adjustItem(item.id,+lg)} style={{...btnSmall(t),background:t.success+"20",color:t.success}}>+{lg}</button>
                      <div style={{flex:1}}/>
                      <button onClick={()=>{ const p=prompt("Set par level:",item.parLevel||""); if(p!==null)setItemPar(item.id,p===""?null:Number(p)); }} style={{...btnSmall(t),fontSize:8}}>PAR</button>
                      <button onClick={()=>{ if(confirm(`Rimuovi ${item.name}?`))removeItem(item.id); }} style={{...btnSmall(t),background:t.accentGlow,color:t.danger}}>✕</button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function btnSmall(t) {
  return {
    padding:"4px 10px",borderRadius:6,border:`1px solid ${t.div}`,cursor:"pointer",
    fontSize:10,fontFamily:"var(--mono)",background:t.bgAlt,color:t.inkMuted,
    transition:"all 0.15s",
  };
}

/* ════════════════════════════════════════════════════════
   STATIONS — partite di cucina
   ════════════════════════════════════════════════════════ */
const STATIONS = [
  {key:"saucier",    label:"Saucier",       icon:"🫕", color:"#8B1E2F"},
  {key:"poissonnier",label:"Poissonnier",   icon:"🐟", color:"#2A4FA5"},
  {key:"rotisseur",  label:"Rôtisseur",     icon:"🥩", color:"#8B4A1E"},
  {key:"garde",      label:"Garde Manger",  icon:"🥗", color:"#3D7A4A"},
  {key:"patissier",  label:"Pâtissier",     icon:"🍮", color:"#7A5A1E"},
  {key:"communard",  label:"Communard",     icon:"🍲", color:"#555"},
  {key:"all",        label:"Tutta la brigata", icon:"⭐", color:"#C19A3E"},
];

/* ════════════════════════════════════════════════════════
   MEP VIEW — AI-powered: foto / file / voce → tasks per partita
   ════════════════════════════════════════════════════════ */
function MepView({ t }) {
  const { kitchen, stockAdd, currentRole } = useK();
  const toast = useToast();
  const canEdit = CAN_EDIT.includes(currentRole());
  const kid = kitchen?.id;

  // ── Persistent task list ──────────────────────────────
  const STORAGE = `mep-tasks-${kid}`;
  const [tasks, setTasks] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE) || "[]"); } catch { return []; }
  });
  useEffect(() => { localStorage.setItem(STORAGE, JSON.stringify(tasks)); }, [tasks, STORAGE]);

  // ── Filters ───────────────────────────────────────────
  const [filterStation, setFilterStation] = useState("all");
  const [filterDone,    setFilterDone]    = useState(false);

  // ── Manual add ────────────────────────────────────────
  const [manualText,    setManualText]    = useState("");
  const [manualStation, setManualStation] = useState("saucier");
  const speech = useSpeech(r => setManualText(r));

  // ── Load-in modal ─────────────────────────────────────
  const [moveModal, setMoveModal] = useState(null);
  const [moveQty,   setMoveQty]   = useState("1");
  const [moveDest,  setMoveDest]  = useState("fridge");

  // ── AI import panel ───────────────────────────────────
  const [showAIImport,  setShowAIImport]  = useState(false);
  const [aiMode,        setAiMode]        = useState("voice"); // voice | file | text
  const [aiText,        setAiText]        = useState("");
  const [aiFile,        setAiFile]        = useState(null);   // {name, base64, mimeType}
  const [aiLoading,     setAiLoading]     = useState(false);
  const [aiPreview,     setAiPreview]     = useState(null);   // [{station, text}] after parse
  const [aiPreviewSel,  setAiPreviewSel]  = useState({});     // id → bool for selection
  const fileInputRef = useRef(null);
  const voiceSpeech  = useSpeech(r => setAiText(prev => (prev ? prev + " " + r : r)));

  // ── Task helpers ──────────────────────────────────────
  function addTask(text, station) {
    const tx = text.trim(); if (!tx) return;
    setTasks(p => [...p, { id:genId(), text:tx, station:station||"all", done:false, createdAt:nowISO() }]);
  }
  function toggleTask(id) { setTasks(p => p.map(x => x.id !== id ? x : {...x, done:!x.done})); }
  function removeTask(id) { setTasks(p => p.filter(x => x.id !== id)); }

  function doManualAdd() {
    if (!manualText.trim()) { toast("Scrivi la preparazione","error"); return; }
    addTask(manualText, manualStation);
    toast(`Aggiunto a ${STATIONS.find(s=>s.key===manualStation)?.label}`,"success");
    setManualText("");
  }

  function doLoadIn() {
    if (!moveModal) return;
    const qty = parseFloat(moveQty);
    if (!isFinite(qty) || qty <= 0) { toast("Inserisci quantità valida","error"); return; }
    stockAdd({ name:moveModal.text, quantity:qty, unit:"pz", location:moveDest, lot:`MEP-${todayDate()}` });
    setTasks(p => p.map(x => x.id !== moveModal.id ? x : {...x, done:true}));
    setMoveModal(null);
    toast(`${moveModal.text} → ${moveDest}`,"success");
  }

  // ── File → base64 ─────────────────────────────────────
  function handleFile(e) {
    const file = e.target.files?.[0]; if (!file) return;
    const allowed = ["image/jpeg","image/png","image/webp","image/gif","application/pdf","text/plain","text/csv"];
    if (!allowed.includes(file.type)) { toast("Formato non supportato. Usa: foto, PDF, testo","error"); return; }
    const reader = new FileReader();
    reader.onload = ev => {
      const b64 = ev.target.result.split(",")[1];
      setAiFile({ name:file.name, base64:b64, mimeType:file.type });
      toast(`File caricato: ${file.name}`,"success");
    };
    reader.readAsDataURL(file);
  }

  // ── AI parse ──────────────────────────────────────────
  async function runAI() {
    const hasInput = (aiMode==="file" && aiFile) || (aiMode!=="file" && aiText.trim());
    if (!hasInput) { toast("Inserisci contenuto da analizzare","error"); return; }

    setAiLoading(true);
    setAiPreview(null);

    const brigataContext = (kitchen?.members||[])
      .map(m => `${m.name} (${m.role})`).join(", ");

    const systemPrompt = `Sei un assistente per cucine professionali Michelin. Il tuo compito è analizzare documenti (ricette, piani di produzione, foglietti interni, menu, appunti scritti a mano) ed estrarre le preparazioni MEP (mise en place) per ogni partita.

Brigata attuale: ${brigataContext || "non specificata"}.
Partite disponibili: ${STATIONS.filter(s=>s.key!=="all").map(s=>s.label).join(", ")}.

Rispondi SOLO con un JSON array, senza markdown, senza testo extra. Formato:
[
  {"station": "saucier", "tasks": ["Fondo bruno ridotto", "Salsa Périgueux"]},
  {"station": "poissonnier", "tasks": ["Sfilettare rombo", "Pulire vongole"]},
  ...
]

Usa i valori di station: saucier, poissonnier, rotisseur, garde, patissier, communard.
Se non riesci ad assegnare una stazione, usa "all".
Se non trovi preparazioni, rispondi [].
Non inventare nulla che non sia nel documento.`;

    try {
      let userContent;

      if (aiMode === "file" && aiFile) {
        if (aiFile.mimeType.startsWith("image/")) {
          userContent = [
            { type:"image", source:{ type:"base64", media_type:aiFile.mimeType, data:aiFile.base64 } },
            { type:"text",  text:"Analizza questa immagine ed estrai le preparazioni MEP per partita." },
          ];
        } else if (aiFile.mimeType === "application/pdf") {
          userContent = [
            { type:"document", source:{ type:"base64", media_type:"application/pdf", data:aiFile.base64 } },
            { type:"text", text:"Analizza questo documento ed estrai le preparazioni MEP per partita." },
          ];
        } else {
          // plain text file
          const decoded = atob(aiFile.base64);
          userContent = `Analizza questo documento ed estrai le preparazioni MEP per partita:\n\n${decoded}`;
        }
      } else {
        userContent = `Analizza questo testo ed estrai le preparazioni MEP per partita:\n\n${aiText.trim()}`;
      }

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:1000,
          system: systemPrompt,
          messages:[{ role:"user", content:userContent }],
        }),
      });
      const data = await res.json();
      const raw  = (data.content||[]).map(b=>b.text||"").join("").trim();

      let parsed;
      try {
        const clean = raw.replace(/```json|```/g,"").trim();
        parsed = JSON.parse(clean);
      } catch {
        toast("Risposta AI non valida. Riprova.","error");
        setAiLoading(false); return;
      }

      if (!Array.isArray(parsed) || parsed.length === 0) {
        toast("Nessuna preparazione trovata nel documento","error");
        setAiLoading(false); return;
      }

      // Flatten to preview items with selection state
      const items = [];
      parsed.forEach(group => {
        const stationKey = STATIONS.find(s=>s.key===group.station||s.label.toLowerCase()===group.station?.toLowerCase())?.key || "all";
        (group.tasks||[]).forEach(taskText => {
          if (typeof taskText==="string" && taskText.trim()) {
            items.push({ id:genId(), station:stationKey, text:taskText.trim() });
          }
        });
      });

      if (items.length===0) { toast("Nessuna preparazione estratta","error"); setAiLoading(false); return; }

      setAiPreview(items);
      // select all by default
      const sel = {};
      items.forEach(x => { sel[x.id]=true; });
      setAiPreviewSel(sel);
      toast(`${items.length} preparazioni trovate — conferma prima di inserire`,"success");

    } catch(err) {
      toast("Errore API: " + (err.message||"rete"), "error");
    }
    setAiLoading(false);
  }

  function confirmInsert() {
    const toInsert = (aiPreview||[]).filter(x=>aiPreviewSel[x.id]);
    if (!toInsert.length) { toast("Nessuna selezione","error"); return; }
    toInsert.forEach(x => addTask(x.text, x.station));
    toast(`${toInsert.length} preparazioni inserite in lista`,"success");
    setAiPreview(null);
    setAiPreviewSel({});
    setAiText("");
    setAiFile(null);
    setShowAIImport(false);
  }

  // ── Filtered task list ────────────────────────────────
  const visibleTasks = tasks.filter(x => {
    if (!filterDone && x.done) return false;
    if (filterStation !== "all" && x.station !== filterStation) return false;
    return true;
  });
  const todo = visibleTasks.filter(x=>!x.done);
  const done = visibleTasks.filter(x=>x.done);

  // ── Station group counts for badge ────────────────────
  const countByStation = {};
  STATIONS.forEach(s => { countByStation[s.key] = tasks.filter(x=>!x.done&&(s.key==="all"||x.station===s.key)).length; });

  return (
    <div style={{display:"flex",flexDirection:"column",gap:20}}>

      {/* ── AI IMPORT PANEL ─────────────────────────────── */}
      {showAIImport && (
        <Card t={t} glow style={{padding:0,overflow:"visible"}}>
          {/* Panel header */}
          <div style={{
            padding:"16px 22px",
            background:`linear-gradient(135deg, ${t.secondary}, ${t.secondaryDeep})`,
            display:"flex",alignItems:"center",justifyContent:"space-between",
            borderRadius:"14px 14px 0 0",
          }}>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <span style={{fontSize:20}}>🤖</span>
              <div>
                <div style={{color:"#fff",fontFamily:"var(--serif)",fontSize:15,fontWeight:500}}>Importa preparazioni con AI</div>
                <div className="mono" style={{fontSize:7,color:"rgba(255,255,255,0.45)",letterSpacing:"0.16em",marginTop:1}}>
                  FOTO · FILE · TESTO · VOCE → LISTA MEP
                </div>
              </div>
            </div>
            <button onClick={()=>{setShowAIImport(false);setAiPreview(null);}} style={{background:"none",border:"none",color:"rgba(255,255,255,0.5)",fontSize:20,cursor:"pointer",lineHeight:1}}>✕</button>
          </div>

          <div style={{padding:22,display:"flex",flexDirection:"column",gap:18}}>
            {/* Mode selector */}
            <div style={{display:"flex",gap:8}}>
              {[
                {key:"voice", label:"🎤 Voce / Testo", desc:"Ditta o scrivi"},
                {key:"file",  label:"📄 Foto / File",  desc:"Immagine, PDF, .txt"},
              ].map(m=>(
                <button key={m.key} onClick={()=>{setAiMode(m.key);setAiPreview(null);}} style={{
                  flex:1,padding:"12px 16px",borderRadius:10,border:"none",cursor:"pointer",
                  background:aiMode===m.key?`linear-gradient(135deg,${t.gold},${t.goldBright})`:t.bgAlt,
                  color:aiMode===m.key?"#fff":t.inkMuted,
                  fontFamily:"var(--mono)",fontSize:10,letterSpacing:"0.06em",
                  boxShadow:aiMode===m.key?`0 4px 16px ${t.goldFaint}`:`0 1px 4px ${t.shadow}`,
                  transition:"all 0.25s",
                  border:aiMode===m.key?"none":`1px solid ${t.div}`,
                }}>
                  <div style={{fontSize:14,marginBottom:4}}>{m.label}</div>
                  <div style={{fontSize:8,opacity:0.7}}>{m.desc}</div>
                </button>
              ))}
            </div>

            {/* Voice / text mode */}
            {aiMode==="voice" && !aiPreview && (
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                <div style={{fontSize:11,fontFamily:"var(--serif)",fontStyle:"italic",color:t.inkMuted}}>
                  Ditta le preparazioni, oppure incolla il testo del foglio cucina. L'AI le assegnerà alle partite.
                </div>
                <div style={{display:"flex",gap:8,alignItems:"flex-start"}}>
                  <textarea
                    value={aiText}
                    onChange={e=>setAiText(e.target.value)}
                    placeholder={"Es: Saucier — fondo bruno ridotto, salsa Périgueux.\nPoissonnier — sfilettare 8 rombi, aprire 2kg vongole.\nPâtissier — crema pasticcera x40, mignardises."}
                    style={{
                      flex:1,minHeight:120,padding:"12px 14px",borderRadius:10,
                      fontSize:12,fontFamily:"var(--serif)",fontStyle:"italic",
                      background:t.bgCardAlt,color:t.ink,border:`1px solid ${t.div}`,
                      outline:"none",resize:"vertical",lineHeight:1.6,
                    }}
                    onFocus={e=>e.target.style.borderColor=t.gold}
                    onBlur={e=>e.target.style.borderColor=t.div}
                  />
                  <VoiceBtn t={t} onResult={r=>setAiText(p=>p?(p+" "+r):r)}/>
                </div>
              </div>
            )}

            {/* File mode */}
            {aiMode==="file" && !aiPreview && (
              <div style={{display:"flex",flexDirection:"column",gap:12}}>
                <div style={{fontSize:11,fontFamily:"var(--serif)",fontStyle:"italic",color:t.inkMuted}}>
                  Carica la foto del foglio MEP, un PDF stampato, o un file di testo. Funziona anche con scrittura a mano.
                </div>
                <input ref={fileInputRef} type="file" accept="image/*,.pdf,text/plain" style={{display:"none"}} onChange={handleFile}/>
                <div
                  onClick={()=>fileInputRef.current?.click()}
                  style={{
                    border:`2px dashed ${aiFile?t.gold:t.div}`,borderRadius:12,
                    padding:"28px 22px",textAlign:"center",cursor:"pointer",
                    background:aiFile?t.goldFaint:t.bgAlt,transition:"all 0.25s",
                  }}
                  onDragOver={e=>{e.preventDefault();e.currentTarget.style.borderColor=t.gold;}}
                  onDragLeave={e=>{e.currentTarget.style.borderColor=aiFile?t.gold:t.div;}}
                  onDrop={e=>{
                    e.preventDefault();
                    const f=e.dataTransfer.files?.[0];
                    if(f){ const fakeEv={target:{files:[f]}}; handleFile(fakeEv); }
                  }}
                >
                  {aiFile ? (
                    <div>
                      <div style={{fontSize:28,marginBottom:6}}>✓</div>
                      <div style={{fontFamily:"var(--serif)",fontSize:14,color:t.gold,fontStyle:"italic"}}>{aiFile.name}</div>
                      <div className="mono" style={{fontSize:9,color:t.inkFaint,marginTop:4}}>Clicca per sostituire</div>
                    </div>
                  ) : (
                    <div>
                      <div style={{fontSize:32,marginBottom:8}}>📸</div>
                      <div style={{fontFamily:"var(--serif)",fontSize:13,fontStyle:"italic",color:t.inkMuted}}>Trascina qui o clicca per scegliere</div>
                      <div className="mono" style={{fontSize:9,color:t.inkFaint,marginTop:4}}>JPG · PNG · WEBP · PDF · TXT</div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Preview extracted tasks */}
            {aiPreview && (
              <div style={{display:"flex",flexDirection:"column",gap:12}}>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                  <div style={{fontFamily:"var(--serif)",fontSize:13,fontStyle:"italic",color:t.ink}}>
                    {aiPreview.length} preparazioni estratte — seleziona quelle da inserire:
                  </div>
                  <div style={{display:"flex",gap:8}}>
                    <button onClick={()=>{const s={};aiPreview.forEach(x=>{s[x.id]=true;});setAiPreviewSel(s);}} style={{...btnSmall(t),fontSize:8}}>Tutto</button>
                    <button onClick={()=>setAiPreviewSel({})} style={{...btnSmall(t),fontSize:8}}>Niente</button>
                  </div>
                </div>

                {/* Group by station */}
                {STATIONS.filter(s=>s.key!=="all").map(station=>{
                  const stTasks = aiPreview.filter(x=>x.station===station.key);
                  if (!stTasks.length) return null;
                  return (
                    <div key={station.key} style={{borderRadius:10,overflow:"hidden",border:`1px solid ${t.div}`}}>
                      <div style={{
                        padding:"9px 14px",display:"flex",alignItems:"center",gap:10,
                        background:`linear-gradient(135deg, ${station.color}22, ${station.color}11)`,
                        borderBottom:`1px solid ${t.div}`,
                      }}>
                        <span style={{fontSize:14}}>{station.icon}</span>
                        <span className="mono" style={{fontSize:9,letterSpacing:"0.1em",color:station.color,fontWeight:600}}>{station.label.toUpperCase()}</span>
                        <span style={{marginLeft:"auto",fontSize:9,fontFamily:"var(--mono)",color:t.inkFaint}}>{stTasks.filter(x=>aiPreviewSel[x.id]).length}/{stTasks.length} selezionate</span>
                      </div>
                      {stTasks.map((item,i)=>(
                        <div key={item.id} style={{
                          padding:"10px 14px",display:"flex",alignItems:"center",gap:12,
                          borderBottom:i<stTasks.length-1?`1px solid ${t.div}`:"none",
                          background:aiPreviewSel[item.id]?t.bgAlt:t.bgCard,
                          cursor:"pointer",transition:"background 0.15s",
                        }}
                        onClick={()=>setAiPreviewSel(p=>({...p,[item.id]:!p[item.id]}))}>
                          <div style={{
                            width:18,height:18,borderRadius:4,border:`1.5px solid ${aiPreviewSel[item.id]?t.gold:t.div}`,
                            background:aiPreviewSel[item.id]?t.gold:"transparent",
                            display:"flex",alignItems:"center",justifyContent:"center",
                            flexShrink:0,transition:"all 0.15s",
                          }}>
                            {aiPreviewSel[item.id]&&<span style={{color:"#fff",fontSize:10,lineHeight:1}}>✓</span>}
                          </div>
                          <span style={{fontFamily:"var(--serif)",fontSize:13,fontStyle:"italic",color:t.ink,flex:1}}>{item.text}</span>
                        </div>
                      ))}
                    </div>
                  );
                })}

                {/* Also show "all" items */}
                {aiPreview.filter(x=>x.station==="all").length>0&&(
                  <div style={{borderRadius:10,overflow:"hidden",border:`1px solid ${t.div}`}}>
                    <div style={{padding:"9px 14px",background:t.bgAlt,borderBottom:`1px solid ${t.div}`}}>
                      <span className="mono" style={{fontSize:9,letterSpacing:"0.1em",color:t.inkMuted}}>STAZIONE NON SPECIFICATA</span>
                    </div>
                    {aiPreview.filter(x=>x.station==="all").map((item,i,arr)=>(
                      <div key={item.id} style={{
                        padding:"10px 14px",display:"flex",alignItems:"center",gap:12,
                        borderBottom:i<arr.length-1?`1px solid ${t.div}`:"none",
                        background:aiPreviewSel[item.id]?t.bgAlt:t.bgCard,cursor:"pointer",transition:"background 0.15s",
                      }}
                      onClick={()=>setAiPreviewSel(p=>({...p,[item.id]:!p[item.id]}))}>
                        <div style={{width:18,height:18,borderRadius:4,border:`1.5px solid ${aiPreviewSel[item.id]?t.gold:t.div}`,background:aiPreviewSel[item.id]?t.gold:"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"all 0.15s"}}>
                          {aiPreviewSel[item.id]&&<span style={{color:"#fff",fontSize:10}}>✓</span>}
                        </div>
                        <span style={{fontFamily:"var(--serif)",fontSize:13,fontStyle:"italic",color:t.ink,flex:1}}>{item.text}</span>
                      </div>
                    ))}
                  </div>
                )}

                <div style={{display:"flex",gap:10}}>
                  <Btn t={t} variant="gold" onClick={confirmInsert} disabled={!Object.values(aiPreviewSel).some(Boolean)}>
                    ✓ Inserisci {Object.values(aiPreviewSel).filter(Boolean).length} preparazioni in lista
                  </Btn>
                  <Btn t={t} variant="ghost" onClick={()=>{setAiPreview(null);setAiPreviewSel({});}}>← Rianalizza</Btn>
                </div>
              </div>
            )}

            {/* Analyze button */}
            {!aiPreview && (
              <Btn t={t} variant="primary"
                onClick={runAI}
                disabled={aiLoading || (aiMode==="file"?!aiFile:!aiText.trim())}
                style={{alignSelf:"flex-start"}}
              >
                {aiLoading
                  ? <span style={{display:"flex",alignItems:"center",gap:8}}><span style={{animation:"blink 1s ease-in-out infinite"}}>◷</span> Analisi in corso…</span>
                  : "🤖 Analizza ed estrai preparazioni"}
              </Btn>
            )}
          </div>
        </Card>
      )}

      {/* ── MANUAL ADD + AI BUTTON ───────────────────────── */}
      {canEdit && !showAIImport && (
        <Card t={t} style={{padding:20}}>
          <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
            <LuxInput value={manualText} onChange={e=>setManualText(e.target.value)} placeholder="Preparazione manuale (es: Brunoise scalogno)" t={t} style={{flex:"1 1 200px"}}
              onKeyDown={e=>e.key==="Enter"&&doManualAdd()}/>
            <LuxSelect value={manualStation} onChange={e=>setManualStation(e.target.value)} t={t} style={{width:160}}>
              {STATIONS.filter(s=>s.key!=="all").map(s=><option key={s.key} value={s.key}>{s.icon} {s.label}</option>)}
            </LuxSelect>
            <VoiceBtn t={t} onResult={r=>setManualText(r)}/>
            <Btn t={t} onClick={doManualAdd} disabled={!manualText.trim()}>+ Aggiungi</Btn>
            <button onClick={()=>setShowAIImport(true)} style={{
              padding:"8px 18px",borderRadius:8,border:"none",cursor:"pointer",
              background:`linear-gradient(135deg, ${t.gold}, ${t.goldBright})`,
              color:"#fff",fontFamily:"var(--mono)",fontSize:10,letterSpacing:"0.08em",
              boxShadow:`0 3px 14px ${t.goldFaint}`,display:"flex",alignItems:"center",gap:8,
            }}>
              <span>🤖</span> Importa da foto / file / voce
            </button>
          </div>
        </Card>
      )}
      {canEdit && showAIImport && !aiPreview && (
        <div style={{display:"flex",justifyContent:"flex-end"}}>
          <Btn t={t} variant="ghost" onClick={()=>setShowAIImport(false)}>← Torna alla lista</Btn>
        </div>
      )}

      {/* ── STATION FILTER TABS ──────────────────────────── */}
      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
        {STATIONS.map(s=>{
          const cnt = countByStation[s.key];
          const active = filterStation===s.key;
          return (
            <button key={s.key} onClick={()=>setFilterStation(s.key)} style={{
              padding:"8px 16px",borderRadius:10,border:"none",cursor:"pointer",
              fontFamily:"var(--mono)",fontSize:9,letterSpacing:"0.06em",
              background:active?`linear-gradient(135deg,${s.color},${s.color}CC)`:t.bgCard,
              color:active?"#fff":t.inkMuted,
              border:active?"none":`1px solid ${t.div}`,
              display:"flex",alignItems:"center",gap:6,transition:"all 0.25s",
              boxShadow:active?`0 4px 16px ${s.color}30`:`0 1px 4px ${t.shadow}`,
            }}>
              <span style={{fontSize:12}}>{s.icon}</span>
              {s.label}
              {cnt>0&&<span style={{background:active?"rgba(255,255,255,0.25)":s.color+"25",color:active?"#fff":s.color,padding:"1px 7px",borderRadius:8,fontSize:8}}>{cnt}</span>}
            </button>
          );
        })}
        <button onClick={()=>setFilterDone(!filterDone)} style={{
          padding:"8px 14px",borderRadius:10,border:`1px solid ${t.div}`,cursor:"pointer",
          fontFamily:"var(--mono)",fontSize:9,letterSpacing:"0.06em",
          background:filterDone?t.bgAlt:t.bgCard,color:t.inkMuted,marginLeft:"auto",
        }}>
          {filterDone?"Nascondi completate":"Mostra completate"}
        </button>
      </div>

      {/* ── TASK COLUMNS ─────────────────────────────────── */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        {/* Da fare */}
        <Card t={t}>
          <CardHeader t={t} title={`Da fare (${todo.length})`}/>
          <div>
            {todo.length===0 && (
              <div style={{padding:"24px 22px",color:t.inkFaint,fontSize:12,fontFamily:"var(--serif)",fontStyle:"italic",textAlign:"center"}}>
                ✓ Tutto completato
              </div>
            )}
            {todo.map((task,i)=>{
              const station = STATIONS.find(s=>s.key===task.station)||STATIONS[STATIONS.length-1];
              return (
                <div key={task.id} style={{
                  padding:"12px 22px",display:"flex",alignItems:"flex-start",gap:12,
                  borderBottom:i<todo.length-1?`1px solid ${t.div}`:"none",
                  borderLeft:`3px solid ${station.color}`,
                  transition:"background 0.15s",
                }}
                onMouseEnter={e=>e.currentTarget.style.background=t.bgAlt}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <span style={{fontSize:12,marginTop:2,flexShrink:0}}>{station.icon}</span>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:13,fontFamily:"var(--serif)",fontStyle:"italic",color:t.ink,lineHeight:1.4}}>{task.text}</div>
                    <div className="mono" style={{fontSize:8,color:station.color,marginTop:3,opacity:0.8}}>{station.label}</div>
                  </div>
                  {canEdit&&(
                    <div style={{display:"flex",gap:5,flexShrink:0}}>
                      <button onClick={()=>setMoveModal(task)} style={{...btnSmall(t),background:t.success+"20",color:t.success,fontSize:8,padding:"3px 8px"}}>↑ Carica</button>
                      <button onClick={()=>toggleTask(task.id)} style={{...btnSmall(t),fontSize:8,padding:"3px 8px"}}>✓</button>
                      <button onClick={()=>removeTask(task.id)} style={{...btnSmall(t),background:t.accentGlow,color:t.danger,fontSize:8,padding:"3px 8px"}}>✕</button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>

        {/* Completate */}
        <Card t={t}>
          <CardHeader t={t} title={`Completate (${done.length})`}
            right={done.length>0&&canEdit?(
              <button onClick={()=>setTasks(p=>p.filter(x=>!x.done))} style={{...btnSmall(t),fontSize:8}}>Pulisci</button>
            ):null}/>
          <div>
            {done.length===0 && (
              <div style={{padding:"24px 22px",color:t.inkFaint,fontSize:12,fontFamily:"var(--serif)",fontStyle:"italic",textAlign:"center"}}>
                Nessuna completata
              </div>
            )}
            {done.map((task,i)=>{
              const station = STATIONS.find(s=>s.key===task.station)||STATIONS[STATIONS.length-1];
              return (
                <div key={task.id} style={{
                  padding:"12px 22px",display:"flex",alignItems:"center",gap:12,
                  borderBottom:i<done.length-1?`1px solid ${t.div}`:"none",
                  opacity:0.55, borderLeft:`3px solid ${station.color}44`,
                }}>
                  <span style={{fontSize:12,color:t.success}}>✓</span>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontFamily:"var(--serif)",fontStyle:"italic",color:t.inkMuted,textDecoration:"line-through"}}>{task.text}</div>
                    <div className="mono" style={{fontSize:8,color:station.color,marginTop:2,opacity:0.7}}>{station.label}</div>
                  </div>
                  {canEdit&&<button onClick={()=>toggleTask(task.id)} style={{...btnSmall(t),fontSize:8}}>Annulla</button>}
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* ── LOAD-IN MODAL ────────────────────────────────── */}
      {moveModal&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.55)",zIndex:9000,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <Card t={t} style={{width:380,padding:28}}>
            <div className="mono" style={{fontSize:8,letterSpacing:"0.14em",color:t.inkFaint,marginBottom:8}}>CARICA IN GIACENZA</div>
            <div style={{fontFamily:"var(--serif)",fontSize:17,fontStyle:"italic",color:t.ink,marginBottom:20,lineHeight:1.4}}>{moveModal.text}</div>
            <div style={{display:"flex",flexDirection:"column",gap:12}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                <LuxInput value={moveQty} onChange={e=>setMoveQty(e.target.value)} type="number" placeholder="Quantità" t={t}/>
                <LuxSelect value={moveDest} onChange={e=>setMoveDest(e.target.value)} t={t}>
                  <option value="fridge">Frigo</option>
                  <option value="freezer">Congelatore</option>
                  <option value="dry">Dispensa</option>
                  <option value="counter">Banco</option>
                </LuxSelect>
              </div>
              <div style={{display:"flex",gap:8}}>
                <Btn t={t} variant="gold" onClick={doLoadIn}>↑ Carica in giacenza</Btn>
                <Btn t={t} variant="ghost" onClick={()=>setMoveModal(null)}>Annulla</Btn>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   SHOPPING VIEW
   ════════════════════════════════════════════════════════ */
function ShoppingView({ t }) {
  const { kitchen, shopAdd, shopToggle, shopRemove, shopClear, currentRole } = useK();
  const toast = useToast();
  const canEdit = CAN_EDIT.includes(currentRole());

  const [name, setName]  = useState("");
  const [qty,  setQty]   = useState("1");
  const [unit, setUnit]  = useState("pz");
  const [cat,  setCat]   = useState("economato");
  const [notes,setNotes] = useState("");
  const speech = useSpeech(t=>setName(t));

  const CATS = ["economato","giornaliero","settimanale","altro"];
  const items = (kitchen?.shopping||[]);

  function add() {
    if(!name.trim()||parseFloat(qty)<=0) { toast("Compila nome e quantità","error"); return; }
    shopAdd(name,parseFloat(qty),unit,cat,notes);
    toast(`${name} aggiunto alla lista`,"success");
    setName(""); setQty("1"); setNotes("");
  }

  return (
    <div style={{display:"flex",flexDirection:"column",gap:20}}>
      {canEdit&&(
        <Card t={t} style={{padding:20}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:12}}>
            <div style={{display:"flex",gap:8}}>
              <LuxInput value={name} onChange={e=>setName(e.target.value)} placeholder="Articolo" t={t} style={{flex:1}}/>
              <VoiceBtn t={t} onResult={r=>setName(r)}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <LuxInput value={qty} onChange={e=>setQty(e.target.value)} type="number" placeholder="Qtà" t={t}/>
              <LuxSelect value={unit} onChange={e=>setUnit(e.target.value)} t={t}>
                {UNITS.map(u=><option key={u} value={u}>{u}</option>)}
              </LuxSelect>
            </div>
            <LuxSelect value={cat} onChange={e=>setCat(e.target.value)} t={t}>
              {CATS.map(c=><option key={c} value={c}>{c.charAt(0).toUpperCase()+c.slice(1)}</option>)}
            </LuxSelect>
            <LuxInput value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Note" t={t}/>
          </div>
          <Btn t={t} onClick={add} disabled={!name.trim()}>Aggiungi alla lista</Btn>
        </Card>
      )}

      {CATS.map(category=>{
        const catItems = items.filter(x=>x.category===category);
        if(!catItems.length) return null;
        const unchecked = catItems.filter(x=>!x.checked);
        const checked   = catItems.filter(x=>x.checked);
        return (
          <Card key={category} t={t}>
            <CardHeader t={t} title={category.toUpperCase()}
              right={canEdit&&checked.length>0?<button onClick={()=>shopClear(category)} style={{...btnSmall(t),fontSize:8}}>Pulisci spuntati</button>:null}/>
            <div>
              {[...unchecked,...checked].map((item,i)=>(
                <div key={item.id} style={{padding:"11px 22px",display:"flex",alignItems:"center",gap:12,borderBottom:i<catItems.length-1?`1px solid ${t.div}`:"none",opacity:item.checked?0.5:1,transition:"opacity 0.2s"}}>
                  <input type="checkbox" checked={item.checked} onChange={()=>shopToggle(item.id)} style={{cursor:"pointer",accentColor:t.gold}}/>
                  <div style={{flex:1}}>
                    <span style={{fontSize:13,fontFamily:"var(--serif)",color:t.ink,textDecoration:item.checked?"line-through":"none",fontStyle:"italic"}}>{item.name}</span>
                    <span className="mono" style={{fontSize:9,color:t.inkFaint,marginLeft:8}}>{item.quantity} {item.unit}</span>
                    {item.notes&&<span style={{fontSize:9,color:t.inkFaint,marginLeft:8,fontStyle:"italic"}}>· {item.notes}</span>}
                  </div>
                  {canEdit&&<button onClick={()=>shopRemove(item.id)} style={{...btnSmall(t),background:t.accentGlow,color:t.danger}}>✕</button>}
                </div>
              ))}
            </div>
          </Card>
        );
      })}

      {items.length===0&&(
        <div style={{textAlign:"center",padding:"48px 0",color:t.inkFaint}}>
          <div style={{fontFamily:"var(--serif)",fontSize:20,fontStyle:"italic",marginBottom:8}}>Lista vuota</div>
          <div className="mono" style={{fontSize:9,letterSpacing:"0.14em"}}>AGGIUNGI ARTICOLI DA ORDINARE</div>
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   BRIGATA VIEW
   ════════════════════════════════════════════════════════ */
function BrigataView({ t }) {
  const { state, kitchen, addMember, updateRole, removeMember, currentRole, selectMember } = useK();
  const toast = useToast();
  const isAdmin = currentRole()==="admin";

  const [name,setName] = useState("");
  const [role,setRole] = useState("commis");

  if(!kitchen) return null;
  const members = kitchen.members||[];

  const ROLE_STYLE = {
    admin:         {color:"#fff", bg:"#C19A3E"},
    chef:          {color:"#fff", bg:"#8B1E2F"},
    "sous-chef":   {color:"#fff", bg:"#8B1E2F"},
    "capo-partita":{color:"#fff", bg:"#8B1E2F"},
    commis:        {color:"#555", bg:"rgba(0,0,0,0.08)"},
    stagista:      {color:"#555", bg:"rgba(0,0,0,0.08)"},
    staff:         {color:"#555", bg:"rgba(0,0,0,0.08)"},
    fb:            {color:"#555", bg:"rgba(0,0,0,0.08)"},
    mm:            {color:"#555", bg:"rgba(0,0,0,0.08)"},
  };

  function doAdd() {
    if(!name.trim()){toast("Inserisci un nome","error");return;}
    addMember(name,role);
    toast(`${name} aggiunto alla brigata`,"success");
    setName("");
  }

  return (
    <div style={{display:"flex",flexDirection:"column",gap:20}}>
      {/* Current user */}
      <Card t={t} style={{padding:"14px 22px",display:"flex",alignItems:"center",gap:14}}>
        <div style={{width:40,height:40,borderRadius:"50%",background:`linear-gradient(135deg,${t.secondary},${t.secondaryDeep})`,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontFamily:"var(--serif)",fontSize:16,fontWeight:600}}>
          {(members.find(m=>m.id===state.selectedMemberId)||members[0])?.name?.[0]||"?"}
        </div>
        <div>
          <div style={{fontFamily:"var(--serif)",fontSize:14,fontWeight:500,color:t.ink}}>
            {(members.find(m=>m.id===state.selectedMemberId)||members[0])?.name||"—"}
          </div>
          <div className="mono" style={{fontSize:8,letterSpacing:"0.1em",color:t.inkFaint}}>UTENTE CORRENTE · {currentRole().toUpperCase()}</div>
        </div>
        <div style={{flex:1}}/>
        <div style={{fontSize:9,fontFamily:"var(--mono)",color:t.inkFaint}}>Accedi come:</div>
        <LuxSelect value={state.selectedMemberId||""} onChange={e=>selectMember(e.target.value)} t={t} style={{width:160}}>
          {members.map(m=><option key={m.id} value={m.id}>{m.name} ({m.role})</option>)}
        </LuxSelect>
      </Card>

      {isAdmin&&(
        <Card t={t} style={{padding:20}}>
          <div className="mono" style={{fontSize:9,letterSpacing:"0.14em",color:t.inkFaint,marginBottom:14}}>AGGIUNGI MEMBRO</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr auto",gap:10}}>
            <LuxInput value={name} onChange={e=>setName(e.target.value)} placeholder="Nome e cognome" t={t}/>
            <LuxSelect value={role} onChange={e=>setRole(e.target.value)} t={t}>
              {ROLES.map(r=><option key={r} value={r}>{r}</option>)}
            </LuxSelect>
            <Btn t={t} onClick={doAdd} disabled={!name.trim()}>Aggiungi</Btn>
          </div>
        </Card>
      )}

      <Card t={t}>
        <CardHeader t={t} title={`Brigata (${members.length})`}/>
        <div>
          {members.map((m,i)=>{
            const rs = ROLE_STYLE[m.role]||ROLE_STYLE.staff;
            return (
              <div key={m.id} style={{padding:"14px 22px",display:"flex",alignItems:"center",gap:14,borderBottom:i<members.length-1?`1px solid ${t.div}`:"none"}}>
                <div style={{width:36,height:36,borderRadius:"50%",background:`linear-gradient(135deg,${t.secondary},${t.secondaryDeep})`,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontFamily:"var(--serif)",fontSize:14,fontWeight:600,flexShrink:0}}>
                  {m.name[0]}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"var(--serif)",fontSize:14,fontWeight:500,color:t.ink}}>{m.name}</div>
                  <div className="mono" style={{fontSize:8,color:t.inkFaint}}>Dal {m.joinedAt?.slice(0,10)||"—"}</div>
                </div>
                {isAdmin&&m.role!=="admin"?(
                  <LuxSelect value={m.role} onChange={e=>updateRole(m.id,e.target.value)} t={t} style={{width:140}}>
                    {ROLES.map(r=><option key={r} value={r}>{r}</option>)}
                  </LuxSelect>
                ):(
                  <Badge label={m.role.toUpperCase()} color={rs.color} bg={rs.bg}/>
                )}
                {isAdmin&&m.role!=="admin"&&(
                  <button onClick={()=>{if(confirm(`Rimuovi ${m.name}?`))removeMember(m.id);}} style={{...btnSmall(t),background:t.accentGlow,color:t.danger}}>✕</button>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   SETTINGS VIEW
   ════════════════════════════════════════════════════════ */
function SettingsView({ t }) {
  const { state, kitchen, createKitchen, selectKitchen, setParCategory, currentRole } = useK();
  const toast = useToast();
  const isAdmin = currentRole()==="admin";

  const [newName, setNewName] = useState("");
  const [newOwner,setNewOwner] = useState("");

  const parKeys = Object.keys(PAR_PRESET);
  const currentPar = kitchen?.parByCategory||{};

  return (
    <div style={{display:"flex",flexDirection:"column",gap:20}}>
      {/* Kitchen selector */}
      <Card t={t}>
        <CardHeader t={t} title="Cucine"/>
        <div style={{padding:20}}>
          <div style={{display:"flex",gap:10,flexWrap:"wrap",marginBottom:16}}>
            {state.kitchens.map(k=>(
              <button key={k.id} onClick={()=>selectKitchen(k.id)} style={{
                padding:"8px 18px",borderRadius:10,border:"none",cursor:"pointer",
                fontFamily:"var(--mono)",fontSize:10,letterSpacing:"0.06em",
                background:(state.selectedKitchenId||state.kitchens[0]?.id)===k.id?`linear-gradient(135deg,${t.gold},${t.goldBright})`:`${t.bgAlt}`,
                color:(state.selectedKitchenId||state.kitchens[0]?.id)===k.id?"#fff":t.inkMuted,
                border:`1px solid ${t.div}`,
              }}>{k.name}</button>
            ))}
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr auto",gap:10}}>
            <LuxInput value={newName} onChange={e=>setNewName(e.target.value)} placeholder="Nuova cucina" t={t}/>
            <LuxInput value={newOwner} onChange={e=>setNewOwner(e.target.value)} placeholder="Admin" t={t}/>
            <Btn t={t} onClick={()=>{createKitchen(newName,newOwner);setNewName("");setNewOwner("");toast("Cucina creata","success");}} disabled={!newName.trim()}>Crea</Btn>
          </div>
        </div>
      </Card>

      {/* Par levels */}
      {isAdmin&&(
        <Card t={t}>
          <CardHeader t={t} title="Livelli PAR per categoria"/>
          <div style={{padding:20}}>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
              {parKeys.map(key=>(
                <div key={key}>
                  <div className="mono" style={{fontSize:8,letterSpacing:"0.12em",color:t.inkFaint,marginBottom:4}}>{(CATEGORIES[key]||key).toUpperCase()}</div>
                  <LuxInput
                    value={currentPar[key]??PAR_PRESET[key]??0}
                    onChange={e=>setParCategory(key,e.target.value)}
                    type="number" t={t}
                    style={{padding:"7px 10px",fontSize:12}}
                  />
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   AI ASSISTANT PANEL
   ════════════════════════════════════════════════════════ */
function AIPanel({ t, onClose }) {
  const { allItems, stockAdd, removeItem, kitchen } = useK();
  const [messages, setMessages] = useState([{role:"ai",text:"Ciao! Sono il tuo assistente cucina. Posso aiutarti con le giacenze, scadenze, e liste. Cosa vuoi sapere?"}]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);
  const speech = useSpeech(t2=>setInput(t2));

  useEffect(()=>endRef.current?.scrollIntoView({behavior:"smooth"}),[messages]);

  async function send() {
    const msg=input.trim(); if(!msg)return;
    setInput("");
    setMessages(p=>[...p,{role:"user",text:msg}]);

    // Local intent parsing
    const lower=msg.toLowerCase();
    let reply=null;

    const items=allItems();
    const now=new Date();

    if(/scadenz|urgenti|in scadenza/.test(lower)) {
      const urgent=items.filter(x=>{ const h=hoursUntil(x.expiresAt); return h!==null&&h>0&&h<=72; });
      const expired=items.filter(x=>x.expiresAt&&new Date(x.expiresAt)<now);
      if(!urgent.length&&!expired.length) reply="✓ Nessuna scadenza urgente al momento.";
      else {
        const lines=[...expired.map(x=>`⛔ ${x.name} — SCADUTO`), ...urgent.map(x=>`⚠ ${x.name} — ${Math.round(hoursUntil(x.expiresAt))}h rimaste`)];
        reply=lines.join("\n");
      }
    } else if(/low|scorta bassa|sotto par/.test(lower)) {
      const low=items.filter(x=>{ const par=x.parLevel??PAR_PRESET[x.category]??0; return par>0&&x.quantity<par; });
      if(!low.length) reply="✓ Tutti i livelli nella norma.";
      else reply=low.map(x=>`↓ ${x.name}: ${x.quantity} (par ${x.parLevel??PAR_PRESET[x.category]})`).join("\n");
    } else if(/aggiungi|carica/.test(lower)) {
      const m=lower.match(/(\d+[\.,]?\d*)\s*(pz|kg|g|ml|l)?\s+(di\s+)?(.+?)(\s+al\s+(frigo|freezer|dispensa|banco))?$/);
      if(m) {
        const qty=parseFloat(m[1].replace(",",".")), name=m[4].trim();
        const locMap={frigo:"fridge",freezer:"freezer",dispensa:"dry",banco:"counter"};
        const loc=locMap[m[6]||"frigo"]||"fridge";
        if(qty>0&&name){ stockAdd({name,quantity:qty,unit:m[2]||"pz",location:loc}); reply=`✓ ${name} (${qty} ${m[2]||"pz"}) aggiunto in ${loc}.`; }
      }
    } else if(/rimuovi|elimina/.test(lower)) {
      const name=lower.replace(/rimuovi|elimina/,"").trim();
      const found=items.find(x=>x.name.toLowerCase().includes(name));
      if(found){ removeItem(found.id); reply=`✓ ${found.name} rimosso.`; }
      else reply=`Non ho trovato "${name}" in magazzino.`;
    }

    if(reply) { setMessages(p=>[...p,{role:"ai",text:reply}]); return; }

    // Claude API fallback
    setLoading(true);
    try {
      const context=`Cucina: ${kitchen?.name||"—"}. Giacenze: ${items.map(x=>`${x.name} ${x.quantity}${x.unit} (${x.location})`).join(", ")}`;
      const res=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514",max_tokens:400,
          system:`Sei un assistente chef per cucine Michelin. Rispondi SEMPRE in italiano, in modo conciso. Dati cucina: ${context}`,
          messages:[{role:"user",content:msg}],
        }),
      });
      const data=await res.json();
      const text=data.content?.map(b=>b.text||"").join("")||"(nessuna risposta)";
      setMessages(p=>[...p,{role:"ai",text}]);
    } catch { setMessages(p=>[...p,{role:"ai",text:"Errore di connessione. Verificare la rete."}]); }
    finally { setLoading(false); }
  }

  return (
    <div style={{
      position:"fixed",bottom:90,right:24,zIndex:8000,
      width:480,height:520,borderRadius:16,overflow:"hidden",
      boxShadow:`0 20px 60px ${t.shadowStrong}`,
      display:"flex",flexDirection:"column",
      background:t.bgCard,border:`1px solid ${t.div}`,
    }}>
      {/* Header */}
      <div style={{padding:"14px 20px",background:`linear-gradient(135deg,${t.secondary},${t.secondaryDeep})`,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div>
          <span style={{color:"#fff",fontFamily:"var(--serif)",fontSize:14,fontWeight:500}}>🤖 Assistente AI</span>
          <div className="mono" style={{fontSize:7,color:"rgba(255,255,255,0.5)",letterSpacing:"0.14em",marginTop:1}}>KITCHEN PRO INTELLIGENCE</div>
        </div>
        <button onClick={onClose} style={{background:"none",border:"none",color:"rgba(255,255,255,0.6)",fontSize:18,cursor:"pointer"}}>✕</button>
      </div>

      {/* Messages */}
      <div style={{flex:1,overflowY:"auto",padding:"14px 16px",display:"flex",flexDirection:"column",gap:10}}>
        {messages.map((m,i)=>(
          <div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
            <div style={{
              maxWidth:"80%",padding:"10px 14px",borderRadius:12,fontSize:12,lineHeight:1.5,
              fontFamily:m.role==="ai"?"var(--serif)":"var(--mono)",fontStyle:m.role==="ai"?"italic":"normal",
              whiteSpace:"pre-wrap",
              background:m.role==="user"?`linear-gradient(135deg,${t.secondary},${t.secondaryDeep})`:t.bgAlt,
              color:m.role==="user"?"#fff":t.ink,
              borderBottomRightRadius:m.role==="user"?2:12,
              borderBottomLeftRadius:m.role==="ai"?2:12,
            }}>{m.text}</div>
          </div>
        ))}
        {loading&&<div style={{color:t.inkFaint,fontFamily:"var(--mono)",fontSize:10,animation:"pulse 1.5s ease-in-out infinite"}}>...</div>}
        <div ref={endRef}/>
      </div>

      {/* Input */}
      <div style={{padding:"12px 16px",borderTop:`1px solid ${t.div}`,display:"flex",gap:8}}>
        <LuxInput value={input} onChange={e=>setInput(e.target.value)} placeholder="Chiedi qualcosa…" t={t} style={{flex:1}}
          onKeyDown={e=>e.key==="Enter"&&send()}/>
        <VoiceBtn t={t} onResult={r=>setInput(r)}/>
        <Btn t={t} onClick={send} disabled={!input.trim()||loading}>→</Btn>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   MAIN APP
   ════════════════════════════════════════════════════════ */
const NAV = [
  {key:"dashboard",  label:"Dashboard",    icon:"◫"},
  {key:"giacenze",   label:"Giacenze",      icon:"❄"},
  {key:"mep",        label:"MEP",           icon:"◷"},
  {key:"spesa",      label:"Spesa",         icon:"◻"},
  {key:"brigata",    label:"Brigata",       icon:"★"},
  {key:"settings",   label:"Impostazioni",  icon:"⊞"},
];

const SECTION_TITLE = {
  dashboard:"Command Center",giacenze:"Giacenze & Inventario",mep:"Organizzazione MEP",
  spesa:"Lista della Spesa",brigata:"Brigata",settings:"Impostazioni",
};

export default function KitchenPro() {
  return (
    <KitchenProvider>
      <ToastProvider>
        <KitchenProInner/>
      </ToastProvider>
    </KitchenProvider>
  );
}

function KitchenProInner() {
  const [themeKey,    setThemeKey]    = useState(()=>localStorage.getItem("kp-theme")||"carta");
  const [section,     setSection]     = useState("dashboard");
  const [ready,       setReady]       = useState(false);
  const [sideCollapsed, setSideCollapsed] = useState(false);
  const [showAI,      setShowAI]      = useState(false);
  const t = THEMES[themeKey]||THEMES.carta;
  const { state, kitchen } = useK();

  useEffect(()=>{ setTimeout(()=>setReady(true),60); },[]);
  useEffect(()=>{ localStorage.setItem("kp-theme",themeKey); },[themeKey]);

  const needsSetup = state.kitchens.length===0;
  if(needsSetup) return <><style>{CSS(t)}</style><SetupScreen t={t}/></>;

  return (
    <div style={{minHeight:"100vh",display:"flex",fontFamily:"var(--serif)",color:t.ink,background:t.bg,transition:"background 0.6s, color 0.4s"}}>
      <style>{CSS(t)}</style>

      {/* Sidebar */}
      <aside style={{
        width:sideCollapsed?68:240,background:`linear-gradient(180deg,${t.secondary},${t.secondaryDeep})`,
        display:"flex",flexDirection:"column",transition:"width 0.4s cubic-bezier(0.4,0,0.2,1)",
        position:"fixed",top:0,bottom:0,left:0,zIndex:20,
        boxShadow:`4px 0 24px ${t.shadowStrong}`,overflow:"hidden",
      }}>
        {/* Logo */}
        <div style={{padding:sideCollapsed?"20px 12px":"24px 24px 20px",borderBottom:"1px solid rgba(255,255,255,0.08)",display:"flex",alignItems:"center",gap:14}}>
          <div style={{width:42,height:42,minWidth:42,borderRadius:"50%",border:`2px solid ${t.goldBright}`,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(255,255,255,0.06)",boxShadow:`0 0 0 4px ${t.goldFaint}`,flexShrink:0}}>
            <span className="mono" style={{fontSize:9,color:t.goldBright,fontWeight:600}}>★★★</span>
          </div>
          {!sideCollapsed&&(
            <div style={{animation:"fadeIn 0.3s ease"}}>
              <div style={{fontSize:16,fontWeight:600,letterSpacing:"0.12em",color:"#fff",textTransform:"uppercase",whiteSpace:"nowrap"}}>
                {kitchen?.name||"Kitchen Pro"}
              </div>
              <div className="mono" style={{fontSize:7,letterSpacing:"0.2em",color:"rgba(255,255,255,0.35)",marginTop:2}}>GESTIONE CUCINA</div>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav style={{flex:1,padding:"16px 10px",display:"flex",flexDirection:"column",gap:4}}>
          {NAV.map(n=>{
            const active=section===n.key;
            return (
              <button key={n.key} onClick={()=>setSection(n.key)} style={{
                display:"flex",alignItems:"center",gap:14,padding:sideCollapsed?"12px 16px":"12px 18px",
                borderRadius:10,border:"none",cursor:"pointer",
                background:active?"rgba(255,255,255,0.12)":"transparent",
                color:active?"#fff":"rgba(255,255,255,0.45)",
                fontFamily:"var(--mono)",fontSize:10,letterSpacing:"0.06em",
                transition:"all 0.25s",textAlign:"left",width:"100%",
                borderLeft:active?`3px solid ${t.goldBright}`:"3px solid transparent",
              }}>
                <span style={{fontSize:16,minWidth:20,textAlign:"center"}}>{n.icon}</span>
                {!sideCollapsed&&<span style={{whiteSpace:"nowrap"}}>{n.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Theme switcher */}
        <div style={{padding:sideCollapsed?"12px 8px 16px":"16px 14px 20px",borderTop:"1px solid rgba(255,255,255,0.08)"}}>
          {!sideCollapsed&&<div className="mono" style={{fontSize:7,letterSpacing:"0.2em",color:"rgba(255,255,255,0.25)",marginBottom:10,paddingLeft:4}}>TEMA</div>}
          <div style={{display:"flex",flexWrap:"wrap",gap:6,justifyContent:sideCollapsed?"center":"flex-start"}}>
            {Object.entries(THEMES).map(([key,th])=>(
              <button key={key} onClick={()=>setThemeKey(key)} title={th.name} style={{
                width:sideCollapsed?36:48,height:sideCollapsed?36:32,borderRadius:8,
                border:themeKey===key?`2px solid ${t.goldBright}`:"2px solid rgba(255,255,255,0.1)",
                background:th.bg,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",
                fontSize:sideCollapsed?14:12,transition:"all 0.3s",
                transform:themeKey===key?"scale(1.08)":"scale(1)",
                boxShadow:themeKey===key?`0 0 12px ${t.goldFaint}`:"none",
              }}>{th.icon}</button>
            ))}
          </div>
        </div>

        {/* Collapse */}
        <button onClick={()=>setSideCollapsed(!sideCollapsed)} style={{padding:"14px",border:"none",background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.3)",cursor:"pointer",fontSize:14,borderTop:"1px solid rgba(255,255,255,0.06)",transition:"all 0.25s",fontFamily:"var(--mono)"}}>
          {sideCollapsed?"→":"← Comprimi"}
        </button>
      </aside>

      {/* Main */}
      <div style={{flex:1,marginLeft:sideCollapsed?68:240,transition:"margin-left 0.4s cubic-bezier(0.4,0,0.2,1)",display:"flex",flexDirection:"column"}}>
        {/* Topbar */}
        <header style={{
          padding:"16px 36px",background:t.bgGlass,backdropFilter:"blur(20px)",
          borderBottom:`1px solid ${t.div}`,display:"flex",justifyContent:"space-between",alignItems:"center",
          position:"sticky",top:0,zIndex:10,transition:"background 0.4s",
        }}>
          <div>
            <div style={{fontSize:22,fontWeight:600,letterSpacing:"0.06em",color:t.ink}}>{SECTION_TITLE[section]}</div>
            <div className="mono" style={{fontSize:9,color:t.inkFaint,letterSpacing:"0.1em",marginTop:3}}>
              {kitchen?.name?.toUpperCase()||"—"} · {new Date().toLocaleDateString("it-IT",{weekday:"long",day:"2-digit",month:"long"})}
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:18}}>
            <LiveClock t={t}/>
            <div style={{width:1,height:28,background:t.div}}/>
            <button onClick={()=>setShowAI(!showAI)} style={{
              display:"flex",alignItems:"center",gap:8,padding:"7px 18px",borderRadius:10,border:"none",cursor:"pointer",
              background:showAI?`linear-gradient(135deg,${t.gold},${t.goldBright})`:`linear-gradient(135deg,${t.secondary},${t.secondaryDeep})`,
              color:"#fff",fontFamily:"var(--mono)",fontSize:10,letterSpacing:"0.08em",
              boxShadow:`0 3px 14px ${showAI?t.goldFaint:t.shadowStrong}`,transition:"all 0.3s",
            }}>
              <span>🤖</span> AI
            </button>
          </div>
        </header>

        {/* Content */}
        <main style={{flex:1,padding:"28px 36px 48px",overflow:"auto"}} key={section}>
          <div style={{animation:ready?"cardIn 0.45s cubic-bezier(0.4,0,0.2,1) both":"none"}}>
            {section==="dashboard"  && <DashboardView t={t}/>}
            {section==="giacenze"   && <InventoryView t={t}/>}
            {section==="mep"        && <MepView t={t}/>}
            {section==="spesa"      && <ShoppingView t={t}/>}
            {section==="brigata"    && <BrigataView t={t}/>}
            {section==="settings"   && <SettingsView t={t}/>}
          </div>
        </main>
      </div>

      {/* AI Panel */}
      {showAI&&<AIPanel t={t} onClose={()=>setShowAI(false)}/>}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   GLOBAL CSS
   ════════════════════════════════════════════════════════ */
function CSS(t) {
  return `
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500&family=JetBrains+Mono:wght@300;400;500;600&display=swap');
    :root { --serif:'Playfair Display',Georgia,serif; --mono:'JetBrains Mono',monospace; }
    *{margin:0;padding:0;box-sizing:border-box;}
    .mono{font-family:var(--mono);}
    @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.25}}
    @keyframes blink{0%,100%{opacity:1}50%{opacity:0.2}}
    @keyframes cardIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
    @keyframes fadeIn{from{opacity:0}to{opacity:1}}
    @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
    ::-webkit-scrollbar{width:4px;}
    ::-webkit-scrollbar-track{background:transparent;}
    ::-webkit-scrollbar-thumb{background:${t.goldDim};border-radius:2px;}
    input[type=date]::-webkit-calendar-picker-indicator{filter:${t.ink==="#151210"?"none":"invert(1)"};}
    input,select{color-scheme:${t.bg.startsWith("#0")||t.bg.startsWith("#1")||t.bg.startsWith("#2")?"dark":"light"};}
  `;
}

