export type MEPTask = {
  id: string;
  name: string;
  station: string;
  completed: boolean;
  createdAt: string;
};
