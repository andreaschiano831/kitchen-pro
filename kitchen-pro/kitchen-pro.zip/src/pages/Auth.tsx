export default function Auth() {
  return (
    <div className="space-y-2">
      <h2 className="text-lg font-semibold">Auth</h2>
      <p className="text-sm text-neutral-400">Login/Register (placeholder).</p>
    </div>
  );
}
