import { createContext, useContext, useEffect, useMemo, useReducer } from "react";
import type { ReactNode } from "react";
import { v4 as uuid } from "uuid";
import type { FreezerItem, Location, Unit } from "../types/freezer";

// ── Roles ──────────────────────────────────────────────────────────────────────

export type Role =
  | "admin"
  | "chef"
  | "sous-chef"
  | "capo-partita"
  | "commis"
  | "stagista"
  | "staff"
  | "fb"
  | "mm";

// ── Members ────────────────────────────────────────────────────────────────────

export type Member = {
  id: string;
  name: string;
  role: Role;
  joinedAt: string;
};

// ── Shopping ───────────────────────────────────────────────────────────────────

export type ShoppingCategory = "economato" | "giornaliero" | "settimanale" | "altro";

export type ShoppingItem = {
  id: string;
  name: string;
  quantity: number;
  unit: Unit;
  category: ShoppingCategory;
  notes?: string;
  checked: boolean;
  createdAt: string;
};

// ── Legacy StockMovement (kept for migration compat) ──────────────────────────

export type StockMovement = {
  id: string;
  at: string;
  itemId: string;
  name: string;
  from: Location | null;
  to: Location | null;
  quantity: number;
  unit: Unit;
  reason?: string;
};

// ── Ledger ─────────────────────────────────────────────────────────────────────
//
// One immutable row per stock event. Never deleted, only appended.
// Replaces StockMovement going forward.

export type LedgerAction =
  | "ADD"       // new batch loaded
  | "ADJUST"    // manual qty correction
  | "MOVE"      // moved between locations
  | "CONSUME"   // removed/zeroed (future)
  | "MERGE";    // merged into existing batch on move

export type LedgerRow = {
  id: string;
  at: string;              // ISO timestamp
  memberId: string | null; // who triggered (currentMemberId)
  memberName: string;      // denormalised for readability
  action: LedgerAction;
  batchId: string;         // FreezerItem.id of source batch
  name: string;            // item name (denorm)
  qty: number;             // positive always; sign implied by action
  unit: Unit;
  fromLocation: Location | null;
  toLocation: Location | null;
  lot: string;
  reason?: string;
  catalogId?: string;
};

// ── Kitchen ────────────────────────────────────────────────────────────────────

export type Kitchen = {
  id: string;
  name: string;
  ownerName: string;

  members: Member[];

  freezer: FreezerItem[];
  fridge: FreezerItem[];
  dry: FreezerItem[];
  counter: FreezerItem[];

  shopping: ShoppingItem[];

  /** @deprecated use ledger instead */
  movements: StockMovement[];

  /** Immutable audit ledger */
  ledger: LedgerRow[];

  parByCategory: Record<string, number>;

  createdAt: string;
  updatedAt: string;
};

// ── Global state ───────────────────────────────────────────────────────────────

export type KitchenState = {
  kitchens: Kitchen[];
  currentKitchenId: string | null;
  currentMemberId: string | null;
};

// ── Actions ────────────────────────────────────────────────────────────────────

export type StockAddPayload = Omit<FreezerItem, "id"> & {
  id?: string;
  /** Required for ledger — batch without lot gets uuid-lot assigned */
  lot: string;
};

export type StockMovePayload = {
  /** Prefer batchId for exact traceability */
  batchId?: string;
  /** Fallback: match by catalogId (FIFO — oldest insertedAt first) */
  catalogId?: string;
  /** Fallback: match by name (case-insensitive) */
  name?: string;
  fromLocation?: Location;  // if omitted, auto-detect from batchId/name
  toLocation: Location;
  qty: number;
  reason?: string;
};

type Action =
  | { type: "KITCHEN_CREATE"; name: string; ownerName?: string }
  | { type: "KITCHEN_SELECT"; kitchenId: string }
  | { type: "MEMBER_ADD"; kitchenId: string; name: string; role?: Role }
  | { type: "MEMBER_ROLE_UPDATE"; kitchenId: string; memberId: string; role: Role }
  | { type: "MEMBER_REMOVE"; kitchenId: string; memberId: string }
  | { type: "CURRENT_MEMBER_SET"; memberId: string }
  | { type: "PAR_SET_CATEGORY"; kitchenId: string; categoryKey: string; par: number }
  // Stock
  | { type: "STOCK_ADD"; kitchenId: string; item: StockAddPayload; memberId: string | null; memberName: string }
  | { type: "STOCK_ADJUST"; kitchenId: string; batchId: string; delta: number; reason?: string; memberId: string | null; memberName: string }
  | { type: "STOCK_MOVE"; kitchenId: string; payload: StockMovePayload; memberId: string | null; memberName: string }
  | { type: "ITEM_REMOVE"; kitchenId: string; itemId: string }
  | { type: "ITEM_SET_PAR"; kitchenId: string; itemId: string; parLevel?: number }
  // Shopping
  | { type: "SHOP_ADD"; kitchenId: string; name: string; quantity: number; unit: Unit; category: ShoppingCategory; notes?: string }
  | { type: "SHOP_TOGGLE"; kitchenId: string; itemId: string }
  | { type: "SHOP_REMOVE"; kitchenId: string; itemId: string }
  | { type: "SHOP_CLEAR_CHECKED"; kitchenId: string };

// ── Persistence ────────────────────────────────────────────────────────────────

const STORAGE_KEY = "kitchen-pro/state";
const LOCS: Location[] = ["freezer", "fridge", "dry", "counter"];

const nowIso = () => new Date().toISOString();
const today = () => new Date().toISOString().slice(0, 10);

function safeLoad(): KitchenState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return null;
    return parsed as KitchenState;
  } catch {
    return null;
  }
}

function ensureKitchenShape(k: any): Kitchen {
  return {
    id:           String(k?.id ?? uuid()),
    name:         String(k?.name ?? "Kitchen"),
    ownerName:    String(k?.ownerName ?? "Admin"),
    members:      Array.isArray(k?.members)   ? k.members   : [],
    freezer:      Array.isArray(k?.freezer)   ? k.freezer   : [],
    fridge:       Array.isArray(k?.fridge)    ? k.fridge    : [],
    dry:          Array.isArray(k?.dry)       ? k.dry       : [],
    counter:      Array.isArray(k?.counter)   ? k.counter   : [],
    shopping:     Array.isArray(k?.shopping)  ? k.shopping  : [],
    movements:    Array.isArray(k?.movements) ? k.movements : [],
    ledger:       Array.isArray(k?.ledger)    ? k.ledger    : [],
    parByCategory: k?.parByCategory && typeof k.parByCategory === "object" ? k.parByCategory : {},
    createdAt:    String(k?.createdAt ?? nowIso()),
    updatedAt:    String(k?.updatedAt ?? nowIso()),
  };
}

function normalizeState(s: any): KitchenState {
  const kitchens = Array.isArray(s?.kitchens) ? s.kitchens.map(ensureKitchenShape) : [];
  return {
    kitchens,
    currentKitchenId: s?.currentKitchenId ? String(s.currentKitchenId) : (kitchens[0]?.id ?? null),
    currentMemberId:  s?.currentMemberId  ? String(s.currentMemberId)  : null,
  };
}

const SEED: KitchenState = { kitchens: [], currentKitchenId: null, currentMemberId: null };

// ── Reducer helpers ────────────────────────────────────────────────────────────

function getKitchenId(state: KitchenState) {
  return state.currentKitchenId ?? state.kitchens[0]?.id ?? null;
}

function updateKitchen(
  state: KitchenState,
  kitchenId: string,
  fn: (k: Kitchen) => Kitchen
): KitchenState {
  return {
    ...state,
    kitchens: state.kitchens.map((k) =>
      k.id !== kitchenId ? k : { ...fn(k), updatedAt: nowIso() }
    ),
  };
}

function findBatch(
  k: Kitchen,
  opts: { batchId?: string; catalogId?: string; name?: string; fromLocation?: Location }
): { loc: Location; idx: number; item: FreezerItem } | null {
  // 1. Exact batchId
  if (opts.batchId) {
    for (const loc of LOCS) {
      const idx = k[loc].findIndex((x) => x.id === opts.batchId);
      if (idx >= 0) return { loc, idx, item: k[loc][idx] };
    }
    return null;
  }

  // 2. catalogId — FIFO (oldest insertedAt first)
  const locs = opts.fromLocation ? [opts.fromLocation] : LOCS;
  let best: { loc: Location; idx: number; item: FreezerItem } | null = null;

  for (const loc of locs) {
    for (let i = 0; i < k[loc].length; i++) {
      const item = k[loc][i];
      const matchCatalog = opts.catalogId && item.catalogId === opts.catalogId;
      const matchName    = opts.name && item.name.toLowerCase() === opts.name.toLowerCase();
      if (!matchCatalog && !matchName) continue;
      if (!best || item.insertedAt < best.item.insertedAt) {
        best = { loc, idx: i, item };
      }
    }
  }
  return best;
}

function appendLedger(k: Kitchen, row: LedgerRow): Kitchen {
  return { ...k, ledger: [row, ...k.ledger] };
}

// ── Reducer ────────────────────────────────────────────────────────────────────

function reducer(state: KitchenState, action: Action): KitchenState {
  switch (action.type) {

    // ── Kitchen management ──────────────────────────────────────────────────

    case "KITCHEN_CREATE": {
      const ownerMember: Member = {
        id: uuid(), name: (action.ownerName ?? "Admin").trim() || "Admin",
        role: "admin", joinedAt: nowIso(),
      };
      const k: Kitchen = {
        id: uuid(),
        name: (action.name || "Kitchen").trim(),
        ownerName: ownerMember.name,
        members: [ownerMember],
        freezer: [], fridge: [], dry: [], counter: [],
        shopping: [], movements: [], ledger: [],
        parByCategory: {},
        createdAt: nowIso(), updatedAt: nowIso(),
      };
      return { ...state, kitchens: [...state.kitchens, k], currentKitchenId: k.id, currentMemberId: ownerMember.id };
    }

    case "KITCHEN_SELECT":
      return { ...state, currentKitchenId: action.kitchenId };

    case "CURRENT_MEMBER_SET":
      return { ...state, currentMemberId: action.memberId };

    case "MEMBER_ADD":
      return updateKitchen(state, action.kitchenId, (k) => {
        const name = action.name.trim();
        if (!name) return k;
        const m: Member = { id: uuid(), name, role: action.role ?? "commis", joinedAt: nowIso() };
        return { ...k, members: [...k.members, m] };
      });

    case "MEMBER_ROLE_UPDATE":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        members: k.members.map((m) => m.id === action.memberId ? { ...m, role: action.role } : m),
      }));

    case "MEMBER_REMOVE":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        members: k.members.filter((m) => m.id !== action.memberId),
      }));

    case "PAR_SET_CATEGORY":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        parByCategory: { ...k.parByCategory, [action.categoryKey]: action.par },
      }));

    // ── Stock: ADD ──────────────────────────────────────────────────────────
    // Adds a new batch. Always creates a new FreezerItem (no merge on add —
    // each batch is its own traceable unit with lot/date).

    case "STOCK_ADD": {
      return updateKitchen(state, action.kitchenId, (k) => {
        const it = action.item;
        const name = String(it.name ?? "").trim();
        const qty  = Number(it.quantity ?? 0);
        if (!name || !Number.isFinite(qty) || qty <= 0) return k;

        const loc: Location = (it.location as Location) ?? "fridge";
        const lot = it.lot?.trim() || `LOT-${today()}-${uuid().slice(0, 6)}`;

        const batch: FreezerItem = {
          id:           it.id ?? uuid(),
          name,
          quantity:     qty,
          unit:         (it.unit as Unit) ?? "pz",
          location:     loc,
          insertedAt:   it.insertedAt  ?? nowIso(),
          insertedDate: it.insertedDate ?? today(),
          expiresAt:    it.expiresAt,
          lot,
          notes:        it.notes,
          section:      it.section,
          category:     it.category,
          catalogId:    it.catalogId,
          parLevel:     it.parLevel,
        };

        const row: LedgerRow = {
          id:           uuid(),
          at:           batch.insertedAt,
          memberId:     action.memberId,
          memberName:   action.memberName,
          action:       "ADD",
          batchId:      batch.id,
          name:         batch.name,
          qty,
          unit:         batch.unit,
          fromLocation: null,
          toLocation:   loc,
          lot,
          catalogId:    batch.catalogId,
        };

        return appendLedger({ ...k, [loc]: [...k[loc], batch] }, row);
      });
    }

    // ── Stock: ADJUST ───────────────────────────────────────────────────────
    // Correction to a specific batch (+ or -). If result <= 0 batch is removed.

    case "STOCK_ADJUST": {
      return updateKitchen(state, action.kitchenId, (k) => {
        const found = findBatch(k, { batchId: action.batchId });
        if (!found) return k;

        const { loc, idx, item } = found;
        const newQty = item.quantity + action.delta;
        const arr = [...k[loc]];

        if (newQty <= 0) {
          arr.splice(idx, 1);
        } else {
          arr[idx] = { ...item, quantity: newQty };
        }

        const row: LedgerRow = {
          id:           uuid(),
          at:           nowIso(),
          memberId:     action.memberId,
          memberName:   action.memberName,
          action:       "ADJUST",
          batchId:      item.id,
          name:         item.name,
          qty:          Math.abs(action.delta),
          unit:         item.unit,
          fromLocation: loc,
          toLocation:   loc,
          lot:          item.lot ?? "",
          reason:       action.reason,
          catalogId:    item.catalogId,
        };

        return appendLedger({ ...k, [loc]: arr }, row);
      });
    }

    // ── Stock: MOVE ─────────────────────────────────────────────────────────
    // Deduct from source batch, merge-or-create at destination, write ledger.

    case "STOCK_MOVE": {
      return updateKitchen(state, action.kitchenId, (k) => {
        const p = action.payload;
        const found = findBatch(k, {
          batchId:      p.batchId,
          catalogId:    p.catalogId,
          name:         p.name,
          fromLocation: p.fromLocation,
        });
        if (!found) return k;

        const { loc: fromLoc, idx, item } = found;
        const qty = Math.min(Math.max(0, p.qty), item.quantity);
        if (qty <= 0) return k;

        // --- source ---
        const fromArr = [...k[fromLoc]];
        const remaining = item.quantity - qty;
        if (remaining <= 0) {
          fromArr.splice(idx, 1);
        } else {
          fromArr[idx] = { ...item, quantity: remaining };
        }

        // --- destination: soft merge (same name + unit + lot) ---
        const toLoc = p.toLocation;
        const toArr = [...k[toLoc]];
        const mergeIdx = toArr.findIndex(
          (x) =>
            x.name.toLowerCase() === item.name.toLowerCase() &&
            x.unit === item.unit &&
            String(x.lot ?? "") === String(item.lot ?? "")
        );

        let destBatchId: string;
        let ledgerAction: LedgerAction;

        if (mergeIdx >= 0) {
          destBatchId = toArr[mergeIdx].id;
          toArr[mergeIdx] = { ...toArr[mergeIdx], quantity: toArr[mergeIdx].quantity + qty };
          ledgerAction = "MERGE";
        } else {
          destBatchId = uuid();
          toArr.push({
            ...item,
            id:           destBatchId,
            location:     toLoc,
            quantity:     qty,
            insertedAt:   nowIso(),
            insertedDate: today(),
          });
          ledgerAction = "MOVE";
        }

        const row: LedgerRow = {
          id:           uuid(),
          at:           nowIso(),
          memberId:     action.memberId,
          memberName:   action.memberName,
          action:       ledgerAction,
          batchId:      item.id,          // source batch
          name:         item.name,
          qty,
          unit:         item.unit,
          fromLocation: fromLoc,
          toLocation:   toLoc,
          lot:          item.lot ?? "",
          reason:       p.reason,
          catalogId:    item.catalogId,
        };

        // Also keep legacy movements array populated for backward compat
        const legacyMv: StockMovement = {
          id:       row.id,
          at:       row.at,
          itemId:   item.id,
          name:     item.name,
          from:     fromLoc,
          to:       toLoc,
          quantity: qty,
          unit:     item.unit,
          reason:   p.reason,
        };

        return appendLedger(
          { ...k, [fromLoc]: fromArr, [toLoc]: toArr, movements: [legacyMv, ...k.movements] },
          row
        );
      });
    }

    // ── Stock: legacy helpers ───────────────────────────────────────────────

    case "ITEM_REMOVE":
      return updateKitchen(state, action.kitchenId, (k) => {
        const next = { ...k };
        for (const loc of LOCS) next[loc] = next[loc].filter((x) => x.id !== action.itemId);
        return next;
      });

    case "ITEM_SET_PAR":
      return updateKitchen(state, action.kitchenId, (k) => {
        for (const loc of LOCS) {
          const idx = k[loc].findIndex((x) => x.id === action.itemId);
          if (idx < 0) continue;
          const arr = [...k[loc]];
          arr[idx] = { ...arr[idx], parLevel: action.parLevel };
          return { ...k, [loc]: arr };
        }
        return k;
      });

    // ── Shopping ────────────────────────────────────────────────────────────

    case "SHOP_ADD":
      return updateKitchen(state, action.kitchenId, (k) => {
        const name = action.name.trim();
        if (!name) return k;
        const it: ShoppingItem = {
          id: uuid(), name,
          quantity: Math.max(1, Number(action.quantity || 1)),
          unit: action.unit,
          category: action.category,
          notes: action.notes?.trim() || undefined,
          checked: false,
          createdAt: nowIso(),
        };
        return { ...k, shopping: [it, ...k.shopping] };
      });

    case "SHOP_TOGGLE":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        shopping: k.shopping.map((x) => x.id === action.itemId ? { ...x, checked: !x.checked } : x),
      }));

    case "SHOP_REMOVE":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        shopping: k.shopping.filter((x) => x.id !== action.itemId),
      }));

    case "SHOP_CLEAR_CHECKED":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        shopping: k.shopping.filter((x) => !x.checked),
      }));

    default:
      return state;
  }
}

// ── Store API type ─────────────────────────────────────────────────────────────

export type KitchenStore = {
  state: KitchenState;

  createKitchen: (name: string, ownerName?: string) => void;
  selectKitchen: (kitchenId: string) => void;

  addMember:        (name: string, role?: Role) => void;
  updateMemberRole: (memberId: string, role: Role) => void;
  removeMember:     (memberId: string) => void;

  setCurrentMember: (memberId: string) => void;
  getCurrentRole:   () => Role;

  setParCategory: (categoryKey: string, par: number) => void;

  /**
   * Load a new batch into stock.
   * `lot` is mandatory; if blank, an auto-lot is generated.
   * Always creates a new FreezerItem (no merge) to preserve traceability.
   */
  stockAdd: (item: StockAddPayload) => void;

  /**
   * Adjust quantity of a specific batch by delta (+/-).
   * Negative delta reduces; batch removed if result <= 0.
   */
  stockAdjust: (batchId: string, delta: number, reason?: string) => void;

  /**
   * Move stock between locations.
   * Source batch resolved by batchId > catalogId > name (FIFO).
   * Destination: merge if same name+unit+lot exists, else new batch.
   * Writes one LedgerRow per call.
   */
  stockMove: (payload: StockMovePayload) => void;

  // Legacy aliases (keep backward compat with existing pages)
  /** @deprecated use stockAdd */
  addFreezerItem:   (item: StockAddPayload) => void;
  /** @deprecated use stockAdjust */
  adjustFreezerItem:(itemId: string, value: number, mode?: "delta" | "set") => void;
  removeFreezerItem:(itemId: string) => void;
  setFreezerParLevel:(itemId: string, parLevel?: number) => void;
  /** @deprecated use stockMove */
  moveStock: (itemId: string, qty: number, to: Location, reason?: string) => void;

  shopAdd:         (name: string, quantity: number, unit: Unit, category: ShoppingCategory, notes?: string) => void;
  shopToggle:      (itemId: string) => void;
  shopRemove:      (itemId: string) => void;
  shopClearChecked:() => void;
};

// ── Provider ───────────────────────────────────────────────────────────────────

const Ctx = createContext<KitchenStore | null>(null);

export function KitchenProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, SEED, () => {
    const loaded = safeLoad();
    return loaded ? normalizeState(loaded) : SEED;
  });

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { /* ignore */ }
  }, [state]);

  const store = useMemo<KitchenStore>(() => {
    const kid      = getKitchenId(state) ?? "";
    const memberId = state.currentMemberId;

    /** Resolve current member display name (fallback "Sistema") */
    function memberName(): string {
      if (!kid || !memberId) return "Sistema";
      const k = state.kitchens.find((x) => x.id === kid);
      return k?.members.find((m) => m.id === memberId)?.name ?? "Sistema";
    }

    return {
      state,

      createKitchen: (name, ownerName) => dispatch({ type: "KITCHEN_CREATE", name, ownerName }),
      selectKitchen: (kitchenId)       => dispatch({ type: "KITCHEN_SELECT", kitchenId }),

      addMember: (name, role) => {
        if (!kid) return;
        dispatch({ type: "MEMBER_ADD", kitchenId: kid, name, role });
      },
      updateMemberRole: (memberId, role) => {
        if (!kid) return;
        dispatch({ type: "MEMBER_ROLE_UPDATE", kitchenId: kid, memberId, role });
      },
      removeMember: (memberId) => {
        if (!kid) return;
        dispatch({ type: "MEMBER_REMOVE", kitchenId: kid, memberId });
      },

      setCurrentMember: (mid) => dispatch({ type: "CURRENT_MEMBER_SET", memberId: mid }),
      getCurrentRole: () => {
        const k = state.kitchens.find((x) => x.id === kid) ?? state.kitchens[0];
        if (!k) return "admin";
        const m = k.members.find((mm) => mm.id === memberId);
        return m?.role ?? "admin";
      },

      setParCategory: (categoryKey, par) => {
        if (!kid) return;
        dispatch({ type: "PAR_SET_CATEGORY", kitchenId: kid, categoryKey, par });
      },

      // ── Primary stock API ───────────────────────────────────────────────

      stockAdd: (item) => {
        if (!kid) return;
        dispatch({ type: "STOCK_ADD", kitchenId: kid, item, memberId, memberName: memberName() });
      },

      stockAdjust: (batchId, delta, reason) => {
        if (!kid) return;
        dispatch({ type: "STOCK_ADJUST", kitchenId: kid, batchId, delta, reason, memberId, memberName: memberName() });
      },

      stockMove: (payload) => {
        if (!kid) return;
        dispatch({ type: "STOCK_MOVE", kitchenId: kid, payload, memberId, memberName: memberName() });
      },

      // ── Legacy aliases ──────────────────────────────────────────────────

      addFreezerItem: (item) => {
        if (!kid) return;
        dispatch({ type: "STOCK_ADD", kitchenId: kid, item, memberId, memberName: memberName() });
      },

      adjustFreezerItem: (itemId, value, mode = "delta") => {
        if (!kid) return;
        const delta = mode === "set"
          ? (() => {
              // find current qty to compute delta
              const k = state.kitchens.find((x) => x.id === kid);
              if (!k) return value;
              for (const loc of LOCS) {
                const it = k[loc].find((x) => x.id === itemId);
                if (it) return value - it.quantity;
              }
              return value;
            })()
          : value;
        dispatch({ type: "STOCK_ADJUST", kitchenId: kid, batchId: itemId, delta, memberId, memberName: memberName() });
      },

      removeFreezerItem: (itemId) => {
        if (!kid) return;
        dispatch({ type: "ITEM_REMOVE", kitchenId: kid, itemId });
      },

      setFreezerParLevel: (itemId, parLevel) => {
        if (!kid) return;
        dispatch({ type: "ITEM_SET_PAR", kitchenId: kid, itemId, parLevel });
      },

      moveStock: (itemId, qty, to, reason) => {
        if (!kid) return;
        dispatch({ type: "STOCK_MOVE", kitchenId: kid, payload: { batchId: itemId, toLocation: to, qty, reason }, memberId, memberName: memberName() });
      },

      // ── Shopping ────────────────────────────────────────────────────────

      shopAdd: (name, quantity, unit, category, notes) => {
        if (!kid) return;
        dispatch({ type: "SHOP_ADD", kitchenId: kid, name, quantity, unit, category, notes });
      },
      shopToggle: (itemId) => {
        if (!kid) return;
        dispatch({ type: "SHOP_TOGGLE", kitchenId: kid, itemId });
      },
      shopRemove: (itemId) => {
        if (!kid) return;
        dispatch({ type: "SHOP_REMOVE", kitchenId: kid, itemId });
      },
      shopClearChecked: () => {
        if (!kid) return;
        dispatch({ type: "SHOP_CLEAR_CHECKED", kitchenId: kid });
      },
    };
  }, [state]);

  return <Ctx.Provider value={store}>{children}</Ctx.Provider>;
}

export function useKitchen() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useKitchen must be used within KitchenProvider");
  return ctx;
}
