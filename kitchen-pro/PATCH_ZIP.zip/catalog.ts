/**
 * catalog.ts
 * ──────────────────────────────────────────────────────────
 * Unica fonte di verità per il catalogo prodotti.
 *
 * LAYOUT:
 *   catalog.user.json  ← dati editabili senza toccare TS
 *   catalog.ts         ← esporta tipi, mappe, array unificato
 *
 * Per aggiungere prodotti: modifica SOLO catalog.user.json.
 * Per aggiungere categorie: aggiungi la chiave in CategoryKey
 *   e popola CATEGORY_LABELS / CATEGORY_PAR_PZ.
 */

import type { Location } from "../types/freezer";
import rawUser from "./catalog.user.json";

// ── Tipi ───────────────────────────────────────────────────

export type CategoryKey =
  | "proteine"
  | "pesce"
  | "verdure"
  | "erbe"
  | "latticini"
  | "cereali"
  | "grassi"
  | "fermentati"
  | "spezie"
  | "fondi"
  | "cantina"
  | "consumabili"
  | "default";

export type CatalogItem = {
  id: string;
  name: string;
  categoryKey: CategoryKey;
  defaultLocation: Location;
};

// ── Mappe UI ───────────────────────────────────────────────

/** Label italiano per ogni categoria */
export const CATEGORY_LABELS: Record<CategoryKey, string> = {
  proteine:     "Proteine animali",
  pesce:        "Pesce & molluschi",
  verdure:      "Verdure & radici",
  erbe:         "Erbe & fiori",
  latticini:    "Latticini & uova",
  cereali:      "Farine & cereali",
  grassi:       "Grassi & salumi",
  fermentati:   "Acidi & fermentati",
  spezie:       "Spezie & aromi",
  fondi:        "Fondi & riduzioni",
  cantina:      "Cantina & beverage",
  consumabili:  "Consumabili & additivi",
  default:      "Altro",
};

/**
 * Par level Michelin (unità: pz).
 * Usato come fallback quando kitchen.parByCategory[key] non è impostato.
 * Valori sono quantità minime da avere sempre in casa.
 */
export const CATEGORY_PAR_PZ: Record<CategoryKey, number> = {
  proteine:    6,
  pesce:       4,
  verdure:     8,
  erbe:        12,
  latticini:   6,
  cereali:     3,
  grassi:      4,
  fermentati:  6,
  spezie:      10,
  fondi:       4,
  cantina:     6,
  consumabili: 5,
  default:     5,
};

/** Tutte le chiavi categoria in ordine logico (per UI) */
export const CATEGORY_KEYS: CategoryKey[] = [
  "proteine",
  "pesce",
  "verdure",
  "erbe",
  "latticini",
  "cereali",
  "grassi",
  "fermentati",
  "spezie",
  "fondi",
  "cantina",
  "consumabili",
  "default",
];

// ── Helper: normalizza un raw record ───────────────────────

const VALID_KEYS = new Set<string>(CATEGORY_KEYS);

function normKey(raw: string): CategoryKey {
  return VALID_KEYS.has(raw) ? (raw as CategoryKey) : "default";
}

function normItem(x: unknown): CatalogItem | null {
  if (!x || typeof x !== "object") return null;
  const o = x as Record<string, unknown>;
  const id   = typeof o.id   === "string" ? o.id.trim()   : "";
  const name = typeof o.name === "string" ? o.name.trim() : "";
  if (!id || !name) return null;

  const categoryKey = normKey(typeof o.categoryKey === "string" ? o.categoryKey : "default");
  const dl = typeof o.defaultLocation === "string" ? o.defaultLocation : "fridge";
  const defaultLocation: Location =
    dl === "freezer" || dl === "fridge" || dl === "dry" || dl === "counter"
      ? (dl as Location)
      : "fridge";

  return { id, name, categoryKey, defaultLocation };
}

// ── Catalogo unificato ─────────────────────────────────────

/**
 * CATALOG — array definitivo, user.json + eventuali fallback built-in.
 *
 * Regole di merge:
 *  - user.json viene caricato a runtime da Vite (JSON import)
 *  - gli item con id duplicato: l'ultimo vince (user sovrascrive built-in)
 *  - gli item con name/id vuoti vengono scartati silenziosamente
 */

const _builtIn: CatalogItem[] = [
  // Fallback minimo: se user.json è vuoto il form di StockIntake
  // non rimane senza opzioni.
  { id: "__fallback-prot", name: "Proteina generica",  categoryKey: "proteine",   defaultLocation: "fridge"  },
  { id: "__fallback-pesce", name: "Pesce generico",    categoryKey: "pesce",      defaultLocation: "fridge"  },
  { id: "__fallback-verd",  name: "Verdura generica",  categoryKey: "verdure",    defaultLocation: "fridge"  },
  { id: "__fallback-erbe",  name: "Erba generica",     categoryKey: "erbe",       defaultLocation: "fridge"  },
  { id: "__fallback-latt",  name: "Latticino generico","categoryKey": "latticini", defaultLocation: "fridge"  },
  { id: "__fallback-cer",   name: "Cereale generico",  categoryKey: "cereali",    defaultLocation: "dry"     },
  { id: "__fallback-grass", name: "Grasso generico",   categoryKey: "grassi",     defaultLocation: "dry"     },
  { id: "__fallback-ferm",  name: "Fermentato generico","categoryKey":"fermentati",defaultLocation: "dry"     },
  { id: "__fallback-spez",  name: "Spezia generica",   categoryKey: "spezie",     defaultLocation: "dry"     },
  { id: "__fallback-fond",  name: "Fondo generico",    categoryKey: "fondi",      defaultLocation: "fridge"  },
  { id: "__fallback-cant",  name: "Bevanda generica",  categoryKey: "cantina",    defaultLocation: "dry"     },
  { id: "__fallback-cons",  name: "Consumabile generico","categoryKey":"consumabili","defaultLocation":"dry"  },
];

function buildCatalog(): CatalogItem[] {
  const map = new Map<string, CatalogItem>();

  // 1. built-in come base
  for (const item of _builtIn) {
    map.set(item.id, item);
  }

  // 2. user.json sovrascrive (id collision → user wins)
  for (const raw of rawUser as unknown[]) {
    const item = normItem(raw);
    if (item) map.set(item.id, item);
  }

  // 3. ordine: by categoryKey (CATEGORY_KEYS order), poi name
  const order = new Map(CATEGORY_KEYS.map((k, i) => [k, i]));
  return Array.from(map.values()).sort((a, b) => {
    const oa = order.get(a.categoryKey) ?? 99;
    const ob = order.get(b.categoryKey) ?? 99;
    if (oa !== ob) return oa - ob;
    return a.name.localeCompare(b.name, "it");
  });
}

export const CATALOG: CatalogItem[] = buildCatalog();

// ── Lookup helpers ─────────────────────────────────────────

/** Tutti gli item di una categoria */
export function catalogByCategory(key: CategoryKey): CatalogItem[] {
  return CATALOG.filter((x) => x.categoryKey === key);
}

/** Item per id */
export function catalogById(id: string): CatalogItem | undefined {
  return CATALOG.find((x) => x.id === id);
}

/** Par pz: prima da kitchen.parByCategory, poi preset */
export function resolveParPz(
  categoryKey: CategoryKey,
  kitchenPar: Record<string, number> | undefined
): number {
  return kitchenPar?.[categoryKey] ?? CATEGORY_PAR_PZ[categoryKey] ?? 5;
}
