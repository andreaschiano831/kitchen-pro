/**
 * ledger.ts
 * Utilities for reading and exporting the immutable stock ledger.
 */

import type { Kitchen, LedgerRow } from "../store/kitchenStore";

// ── CSV export ─────────────────────────────────────────────────────────────────

function esc(v: unknown): string {
  const s = String(v ?? "").replace(/"/g, '""');
  return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s}"` : s;
}

const CSV_HEADERS = [
  "Data",
  "Ora",
  "Azione",
  "Prodotto",
  "Lotto",
  "Quantità",
  "Unità",
  "Da",
  "A",
  "Operatore",
  "Motivo",
  "BatchId",
  "CatalogId",
];

export function exportLedgerCSV(kitchen: Kitchen): void {
  const rows = kitchen.ledger;
  if (rows.length === 0) {
    alert("Ledger vuoto — nessun movimento da esportare.");
    return;
  }

  const lines: string[] = [CSV_HEADERS.join(",")];

  for (const r of rows) {
    const d = new Date(r.at);
    const date = d.toISOString().slice(0, 10);
    const time = d.toISOString().slice(11, 19);
    lines.push(
      [
        esc(date),
        esc(time),
        esc(r.action),
        esc(r.name),
        esc(r.lot),
        esc(r.qty),
        esc(r.unit),
        esc(r.fromLocation ?? "—"),
        esc(r.toLocation   ?? "—"),
        esc(r.memberName),
        esc(r.reason ?? ""),
        esc(r.batchId),
        esc(r.catalogId ?? ""),
      ].join(",")
    );
  }

  const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8;" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  const today = new Date().toISOString().slice(0, 10);
  a.href     = url;
  a.download = `ledger-${kitchen.name.replace(/\s+/g, "-")}-${today}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ── Filter helpers ─────────────────────────────────────────────────────────────

export type LedgerFilter = {
  action?:   LedgerRow["action"];
  dateFrom?: string;  // YYYY-MM-DD
  dateTo?:   string;
  name?:     string;  // case-insensitive contains
  lot?:      string;
  memberId?: string;
};

export function filterLedger(rows: LedgerRow[], f: LedgerFilter): LedgerRow[] {
  return rows.filter((r) => {
    if (f.action   && r.action !== f.action) return false;
    if (f.dateFrom && r.at.slice(0, 10) < f.dateFrom) return false;
    if (f.dateTo   && r.at.slice(0, 10) > f.dateTo)   return false;
    if (f.name     && !r.name.toLowerCase().includes(f.name.toLowerCase())) return false;
    if (f.lot      && !r.lot.toLowerCase().includes(f.lot.toLowerCase()))   return false;
    if (f.memberId && r.memberId !== f.memberId) return false;
    return true;
  });
}

// ── Summary helpers ────────────────────────────────────────────────────────────

export type LedgerSummaryRow = {
  name: string;
  totalAdded:   number;
  totalMoved:   number;
  totalAdjusted: number;
  unit: string;
};

/** Aggregate by product name */
export function summariseLedger(rows: LedgerRow[]): LedgerSummaryRow[] {
  const map = new Map<string, LedgerSummaryRow>();
  for (const r of rows) {
    const key = r.name.toLowerCase();
    if (!map.has(key)) {
      map.set(key, { name: r.name, totalAdded: 0, totalMoved: 0, totalAdjusted: 0, unit: r.unit });
    }
    const s = map.get(key)!;
    if (r.action === "ADD")    s.totalAdded    += r.qty;
    if (r.action === "MOVE" || r.action === "MERGE") s.totalMoved   += r.qty;
    if (r.action === "ADJUST") s.totalAdjusted += r.qty;
  }
  return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, "it"));
}
