/**
 * StockIntake — componente "da stellato" per il carico giacenze.
 *
 * Feature:
 *  - Dropdown Categoria → Prodotto (filtrato dal catalogo)
 *  - Location auto dal catalogo; se lockLocation=true, campo nascosto
 *  - Data carico preimpostata a oggi, editabile
 *  - Lotto obbligatorio — il bottone è disabilitato finché vuoto
 *  - Expires opzionale ma con date picker
 *  - Sezione "Partite già presenti" per il prodotto selezionato
 *    (match per catalogId o name), con qty totale e quick-adjust (+/-)
 *  - Quick-adjust usa stockAdjust(batchId, delta)
 */

import { useEffect, useMemo, useState } from "react";
import { useKitchen } from "../store/kitchenStore";
import type { Location, Unit, FreezerItem } from "../types/freezer";
import {
  CATALOG,
  CATEGORY_KEYS,
  CATEGORY_LABELS,
  resolveParPz,
  type CatalogItem,
  type CategoryKey,
} from "../data/catalog";

// ── Props ──────────────────────────────────────────────────────────────────────

export type StockIntakeProps = {
  defaultLocation?: Location;
  /** When true, location selector is hidden and defaultLocation is enforced */
  lockLocation?: boolean;
  /** Called after a successful stockAdd (e.g. to close a modal) */
  onSaved?: () => void;
};

// ── Constants ──────────────────────────────────────────────────────────────────

const UNITS: Unit[] = ["pz", "g", "kg", "ml", "l", "vac", "busta", "brik", "latta", "box", "vasch"];
const LOCS: { value: Location; label: string }[] = [
  { value: "freezer", label: "❄️ Freezer" },
  { value: "fridge",  label: "🌡️ Frigo"   },
  { value: "dry",     label: "📦 Dispensa" },
  { value: "counter", label: "🔪 Banco"    },
];

const today = () => new Date().toISOString().slice(0, 10);

// ── Existing batches sub-component ─────────────────────────────────────────────

function ExistingBatches({
  batches,
  onAdjust,
}: {
  batches: FreezerItem[];
  onAdjust: (batchId: string, delta: number) => void;
}) {
  const [deltaMap, setDeltaMap] = useState<Record<string, number>>({});

  const total = batches.reduce((s, b) => s + b.quantity, 0);
  const unit  = batches[0]?.unit ?? "pz";

  const isExpired = (b: FreezerItem) =>
    b.expiresAt != null && b.expiresAt < today();

  const isNearExpiry = (b: FreezerItem) => {
    if (!b.expiresAt) return false;
    const diff = (new Date(b.expiresAt).getTime() - Date.now()) / 86_400_000;
    return diff >= 0 && diff <= 3;
  };

  return (
    <div className="space-y-2">
      {/* totale */}
      <div className="flex items-center justify-between px-1">
        <div className="text-xs font-semibold p-muted">
          {batches.length} {batches.length === 1 ? "partita" : "partite"} in magazzino
        </div>
        <div className="text-xs font-bold">
          Totale: {total} {unit}
        </div>
      </div>

      {batches.map((b) => {
        const expired   = isExpired(b);
        const nearExp   = isNearExpiry(b);
        const delta     = deltaMap[b.id] ?? 0;
        const canApply  = delta !== 0;

        return (
          <div
            key={b.id}
            className={
              "rounded-xl border px-3 py-2 space-y-2 " +
              (expired   ? "border-red-300 bg-red-50"    :
               nearExp   ? "border-amber-300 bg-amber-50" :
                           "bg-white")
            }
            style={expired || nearExp ? {} : { borderColor: "var(--line)" }}
          >
            {/* batch info */}
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-semibold">
                  {b.quantity} {b.unit}
                  <span className="ml-2 text-xs font-normal p-muted">{b.location}</span>
                </div>
                <div className="text-[11px] p-muted space-x-2 mt-0.5">
                  {b.lot && <span>lotto {b.lot}</span>}
                  {b.insertedDate && <span>carico {b.insertedDate}</span>}
                  {b.expiresAt && (
                    <span className={expired ? "text-red-600 font-semibold" : nearExp ? "text-amber-600 font-semibold" : ""}>
                      scad. {b.expiresAt}
                      {expired  ? " ⚠️ SCADUTO"   : ""}
                      {nearExp  ? " ⚠️ in scadenza" : ""}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* quick adjust */}
            <div className="flex items-center gap-2">
              <button
                className="btn btn-ghost px-2 py-1 text-xs"
                onClick={() => setDeltaMap((p) => ({ ...p, [b.id]: (p[b.id] ?? 0) - 1 }))}
              >−</button>
              <input
                className="input w-20 text-center text-sm"
                type="number"
                step={b.unit === "g" || b.unit === "ml" ? 100 : 1}
                value={delta}
                onChange={(e) =>
                  setDeltaMap((p) => ({ ...p, [b.id]: Number(e.target.value) }))
                }
              />
              <button
                className="btn btn-ghost px-2 py-1 text-xs"
                onClick={() => setDeltaMap((p) => ({ ...p, [b.id]: (p[b.id] ?? 0) + 1 }))}
              >+</button>
              <span className="text-xs p-muted">{b.unit}</span>
              <button
                className={"btn text-xs ml-auto " + (canApply ? "btn-primary" : "btn-ghost opacity-40")}
                disabled={!canApply}
                onClick={() => {
                  if (!canApply) return;
                  onAdjust(b.id, delta);
                  setDeltaMap((p) => { const n = { ...p }; delete n[b.id]; return n; });
                }}
              >
                Applica rettifica
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────────

export default function StockIntake({ defaultLocation, lockLocation, onSaved }: StockIntakeProps) {
  const { stockAdd, stockAdjust, state } = useKitchen();

  const currentKitchen = useMemo(
    () => state.kitchens.find((k) => k.id === state.currentKitchenId),
    [state.kitchens, state.currentKitchenId]
  );

  // ── Category ─────────────────────────────────────────────────────────────────

  const [categoryKey, setCategoryKey] = useState<CategoryKey>(CATEGORY_KEYS[0]);

  const itemsInCategory = useMemo<CatalogItem[]>(
    () => CATALOG.filter((x) => x.categoryKey === categoryKey),
    [categoryKey]
  );

  // ── Selected catalog item ─────────────────────────────────────────────────────

  const [catalogId, setCatalogId] = useState<string>(itemsInCategory[0]?.id ?? "");

  // keep catalogId valid when category changes
  useEffect(() => {
    if (!itemsInCategory.some((x) => x.id === catalogId)) {
      setCatalogId(itemsInCategory[0]?.id ?? "");
    }
  }, [itemsInCategory, catalogId]);

  const selected = useMemo<CatalogItem | null>(
    () => CATALOG.find((x) => x.id === catalogId) ?? null,
    [catalogId]
  );

  // ── Form fields ───────────────────────────────────────────────────────────────

  const [name,         setName]         = useState<string>(selected?.name ?? "");
  const [qty,          setQty]          = useState<number>(1);
  const [unit,         setUnit]         = useState<Unit>("pz");
  const [location,     setLocation]     = useState<Location>(
    defaultLocation ?? selected?.defaultLocation ?? "fridge"
  );
  const [insertedDate, setInsertedDate] = useState<string>(today());
  const [expiresAt,    setExpiresAt]    = useState<string>("");
  const [lot,          setLot]          = useState<string>("");
  const [notes,        setNotes]        = useState<string>("");

  // sync name when product selected
  useEffect(() => { setName(selected?.name ?? ""); }, [selected?.id]);

  // sync location: locked > defaultLocation > catalog default
  useEffect(() => {
    if (lockLocation && defaultLocation) { setLocation(defaultLocation); return; }
    if (defaultLocation)                 { setLocation(defaultLocation); return; }
    if (selected?.defaultLocation)       { setLocation(selected.defaultLocation); }
  }, [lockLocation, defaultLocation, selected?.defaultLocation]);

  // ── Existing batches for selected product ─────────────────────────────────────

  const existingBatches = useMemo<FreezerItem[]>(() => {
    if (!currentKitchen || !selected) return [];
    const allItems = [
      ...currentKitchen.freezer,
      ...currentKitchen.fridge,
      ...currentKitchen.dry,
      ...currentKitchen.counter,
    ];
    const nameLower = selected.name.toLowerCase();
    return allItems
      .filter((x) =>
        (x.catalogId && x.catalogId === selected.id) ||
        x.name.toLowerCase() === nameLower
      )
      .sort((a, b) => (a.insertedAt ?? "").localeCompare(b.insertedAt ?? ""));
  }, [currentKitchen, selected?.id]);

  // ── Validation ─────────────────────────────────────────────────────────────────

  const lotMissing   = lot.trim().length === 0;
  const nameMissing  = name.trim().length === 0;
  const qtyInvalid   = !Number.isFinite(Number(qty)) || Number(qty) <= 0;
  const canSave      = !lotMissing && !nameMissing && !qtyInvalid;

  // ── Submit ─────────────────────────────────────────────────────────────────────

  function submit() {
    if (!canSave) return;
    const parLevel = unit === "pz"
      ? resolveParPz(categoryKey, currentKitchen?.parByCategory)
      : undefined;

    stockAdd({
      name:         name.trim(),
      quantity:     Number(qty),
      unit,
      location,
      insertedAt:   new Date().toISOString(),
      insertedDate: insertedDate || today(),
      expiresAt:    expiresAt.trim() || undefined,
      lot:          lot.trim(),
      notes:        notes.trim() || undefined,
      catalogId:    selected?.id,
      category:     categoryKey,
      parLevel,
    });

    // reset — keep category + location + unit for fast multi-batch entry
    setQty(1);
    setExpiresAt("");
    setLot("");
    setNotes("");
    onSaved?.();
  }

  // ── Render ─────────────────────────────────────────────────────────────────────

  return (
    <div className="space-y-4">

      {/* ── Selection: Categoria → Prodotto ─────────────────────────────── */}
      <div className="card p-4 space-y-3">
        <div className="h2">Seleziona prodotto</div>

        <div className="grid gap-2 md:grid-cols-2">
          <div>
            <label className="text-xs p-muted block mb-1">Categoria</label>
            <select
              className="input w-full"
              value={categoryKey}
              onChange={(e) => setCategoryKey(e.target.value as CategoryKey)}
            >
              {CATEGORY_KEYS.map((k) => (
                <option key={k} value={k}>{CATEGORY_LABELS[k]}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs p-muted block mb-1">Prodotto</label>
            <select
              className="input w-full"
              value={catalogId}
              onChange={(e) => setCatalogId(e.target.value)}
            >
              {itemsInCategory.map((x) => (
                <option key={x.id} value={x.id}>{x.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* nome editabile */}
        <div>
          <label className="text-xs p-muted block mb-1">Nome (modifica se serve)</label>
          <input
            className="input w-full"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="es. Wagyu A5 lombo taglio corto"
          />
        </div>
      </div>

      {/* ── Partite già presenti ─────────────────────────────────────────── */}
      {existingBatches.length > 0 && (
        <div className="card p-4 space-y-3">
          <div className="h2">Partite in magazzino</div>
          <ExistingBatches
            batches={existingBatches}
            onAdjust={(batchId, delta) => stockAdjust(batchId, delta, "Rettifica manuale StockIntake")}
          />
        </div>
      )}

      {/* ── Nuovo carico ─────────────────────────────────────────────────── */}
      <div className="card p-4 space-y-3">
        <div className="h2">Nuovo carico</div>

        <div className="grid gap-2 md:grid-cols-2">

          {/* qty + unit */}
          <div>
            <label className="text-xs p-muted block mb-1">Quantità</label>
            <input
              className="input w-full"
              type="number"
              min={0}
              step={unit === "g" || unit === "ml" ? 100 : 1}
              value={qty}
              onChange={(e) => setQty(Number(e.target.value || 0))}
            />
          </div>
          <div>
            <label className="text-xs p-muted block mb-1">Unità</label>
            <select
              className="input w-full"
              value={unit}
              onChange={(e) => setUnit(e.target.value as Unit)}
            >
              {UNITS.map((u) => <option key={u} value={u}>{u}</option>)}
            </select>
          </div>

          {/* location */}
          {lockLocation ? (
            <div className="md:col-span-2">
              <label className="text-xs p-muted block mb-1">Location (bloccata)</label>
              <div className="input w-full bg-neutral-100 text-neutral-500 select-none cursor-not-allowed">
                {LOCS.find((l) => l.value === location)?.label ?? location}
              </div>
            </div>
          ) : (
            <div>
              <label className="text-xs p-muted block mb-1">Location</label>
              <select
                className="input w-full"
                value={location}
                onChange={(e) => setLocation(e.target.value as Location)}
              >
                {LOCS.map((l) => (
                  <option key={l.value} value={l.value}>{l.label}</option>
                ))}
              </select>
            </div>
          )}

          {/* data carico */}
          <div>
            <label className="text-xs p-muted block mb-1">Data carico</label>
            <input
              className="input w-full"
              type="date"
              value={insertedDate}
              onChange={(e) => setInsertedDate(e.target.value)}
            />
          </div>

          {/* scadenza */}
          <div>
            <label className="text-xs p-muted block mb-1">Scadenza (opzionale)</label>
            <input
              className="input w-full"
              type="date"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
              min={today()}
            />
          </div>

          {/* lotto — obbligatorio */}
          <div>
            <label className="text-xs p-muted block mb-1">
              Lotto <span className="text-red-500">*</span>
            </label>
            <input
              className={"input w-full " + (lotMissing && lot !== "" ? "border-red-400" : "")}
              value={lot}
              onChange={(e) => setLot(e.target.value)}
              placeholder="LOT-2026-02-25"
            />
            {lotMissing && lot !== "" && (
              <div className="text-[11px] text-red-500 mt-1">Il lotto è obbligatorio.</div>
            )}
          </div>

          {/* note */}
          <div>
            <label className="text-xs p-muted block mb-1">Note</label>
            <input
              className="input w-full"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="fornitore / DDT / qualità…"
            />
          </div>
        </div>

        {/* CTA */}
        <button
          className={"btn btn-primary w-full " + (!canSave ? "opacity-40 cursor-not-allowed" : "")}
          disabled={!canSave}
          onClick={submit}
        >
          ✅ Carica nuova partita
        </button>

        {/* validation summary */}
        {!canSave && (
          <ul className="text-[11px] text-red-500 space-y-0.5 list-disc list-inside">
            {nameMissing  && <li>Nome prodotto obbligatorio</li>}
            {qtyInvalid   && <li>Quantità deve essere maggiore di 0</li>}
            {lotMissing   && <li>Lotto obbligatorio (HACCP)</li>}
          </ul>
        )}
      </div>
    </div>
  );
}
