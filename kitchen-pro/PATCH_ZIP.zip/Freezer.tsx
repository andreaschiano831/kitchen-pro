import { useMemo, useState } from "react";
import { useKitchen } from "../store/kitchenStore";
import type { Location, Unit } from "../types/freezer";
import StockIntake from "../components/StockIntake";
function stepForUnit(u: Unit) {
  if (u === "pz") return [1, 5];
  if (u === "g" || u === "ml") return [100, 500];
  if (u === "kg" || u === "l") return [1, 2];
  return [1, 5];
}

export default function Freezer() {
  const {
    state,
    adjustFreezerItem,
    removeFreezerItem,
    setFreezerParLevel,
    getCurrentRole,
  } = useKitchen();

  const role = getCurrentRole();
  const canEdit = role === "admin" || role === "chef" || role === "sous-chef" || role === "capo-partita";

  const [loc, setLoc] = useState<Location>("freezer");
  const [q, setQ] = useState("");

  const kitchen = useMemo(
    () => state.kitchens.find((k) => k.id === state.currentKitchenId),
    [state.kitchens, state.currentKitchenId]
  );

  const items = useMemo(() => {
    if (!kitchen) return [];
    const term = q.trim().toLowerCase();
    // Each item lives in its own location array (kitchen.freezer, kitchen.fridge, etc.)
    const arr = (kitchen[loc] as import("../types/freezer").FreezerItem[]) ?? [];
    return arr
      .filter((x) => !term || x.name.toLowerCase().includes(term) || (x.lot ?? "").toLowerCase().includes(term))
      .slice()
      .sort((a, b) => (a.expiresAt ?? "").localeCompare(b.expiresAt ?? ""));
  }, [kitchen, loc, q]);

  function minForItem(x: any) {
    if (x.unit !== "pz") return null;
    const v = x.parLevel;
    if (v === null) return null;
    if (typeof v === "number") return v;
    return 5;
  }

  return (
    <div className="space-y-4">
      {/* CARICO: location bloccata sul filtro attivo */}
      <StockIntake defaultLocation={loc} lockLocation />

      <div className="card p-4">
        <div className="flex flex-wrap gap-2 items-center justify-between">
          <div>
            <div className="h2">Giacenze</div>
            <div className="p-muted text-sm mt-1">Filtro location + ricerca per nome/lotto.</div>
          </div>

          <div className="flex gap-2">
            {(["freezer","fridge","dry","counter"] as Location[]).map((l) => (
              <button
                key={l}
                className={loc === l ? "btn btn-primary" : "btn btn-ghost"}
                onClick={() => setLoc(l)}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3 flex gap-2">
          <input className="input w-full" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cerca (nome o lotto)..." />
        </div>

        <div className="mt-4 space-y-2">
          {!kitchen ? (
            <div className="text-sm text-neutral-500">Seleziona una kitchen.</div>
          ) : items.length === 0 ? (
            <div className="text-sm text-neutral-500">Nessun prodotto in {loc}.</div>
          ) : (
            items.map((x) => {
              const [a, b] = stepForUnit(x.unit);
              const min = minForItem(x);
              const low = min !== null && x.quantity < min;

              return (
                <div key={x.id} className="rounded-xl border border-neutral-200 bg-white px-4 py-3 shadow-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold">
                        {x.name}{" "}
                        {low ? <span className="badge-role border border-red-300 bg-red-50 text-red-700 ml-2">LOW</span> : null}
                      </div>
                      <div className="text-xs text-neutral-500 mt-1">
                        {x.location} • lotto {x.lot ?? "—"} • carico {x.insertedDate ?? x.insertedAt?.slice(0,10)}
                        {x.expiresAt ? " • exp " + x.expiresAt.slice(0, 10) : ""}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-lg font-bold">{x.quantity} {x.unit}</div>
                      {x.unit === "pz" ? (
                        <div className="text-xs text-neutral-500">
                          MIN: {min === null ? "off" : min}
                        </div>
                      ) : null}
                    </div>
                  </div>

                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <button className="btn btn-ghost text-xs" disabled={!canEdit} onClick={() => adjustFreezerItem(x.id, -a)}>-{a}</button>
                    <button className="btn btn-ghost text-xs" disabled={!canEdit} onClick={() => adjustFreezerItem(x.id, +a)}>+{a}</button>
                    <button className="btn btn-ghost text-xs" disabled={!canEdit} onClick={() => adjustFreezerItem(x.id, -b)}>-{b}</button>
                    <button className="btn btn-ghost text-xs" disabled={!canEdit} onClick={() => adjustFreezerItem(x.id, +b)}>+{b}</button>

                    {x.unit === "pz" ? (
                      <button
                        className="btn btn-gold text-xs"
                        disabled={!canEdit}
                        onClick={() => {
                          const cur = (x.parLevel ?? 5);
                          const v = prompt("Imposta MIN (pz). Vuoto=default 5. 'off' per disabilitare", String(cur));
                          if (v === null) return;
                          if (v.trim().toLowerCase() === "off") return setFreezerParLevel(x.id, undefined);
                          const n = Number(v || "5");
                          if (Number.isFinite(n) && n > 0) setFreezerParLevel(x.id, Math.floor(n));
                        }}
                      >
                        MIN
                      </button>
                    ) : null}

                    <button className="btn btn-ghost text-xs ml-auto" disabled={!canEdit} onClick={() => removeFreezerItem(x.id)}>
                      Rimuovi
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}