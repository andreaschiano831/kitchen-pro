import { useMemo, useState } from "react";
import { useKitchen } from "../store/kitchenStore";
import { CATEGORY_KEYS, CATEGORY_LABELS, CATEGORY_PAR_PZ } from "../data/catalog";
import type { CategoryKey } from "../data/catalog";

export default function Kitchen() {
  const { state, createKitchen, selectKitchen, setParCategory } = useKitchen();
  const [name, setName] = useState("");
  const ownerName = "Admin";

  const currentKitchen = useMemo(
    () => state.kitchens.find((k) => k.id === state.currentKitchenId),
    [state.kitchens, state.currentKitchenId]
  );

  const parMap: Record<string, number> = (currentKitchen as any)?.parByCategory ?? {};

  function onCreate() {
    const trimmed = name.trim();
    if (!trimmed) return;
    createKitchen(trimmed, ownerName);
    setName("");
  }

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <div className="h2">Kitchen Management</div>
        <div className="p-muted text-xs mt-1">Seleziona o crea una cucina e gestisci soglie MIN (pz).</div>

        <div className="mt-3 flex gap-2">
          <input
            className="input flex-1"
            placeholder="Nome cucina (es. Cucina Principale)"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <button className="btn btn-primary" onClick={onCreate}>Crea</button>
        </div>

        <div className="mt-4 space-y-2">
          {state.kitchens.length === 0 ? (
            <div className="p-muted text-sm">Nessuna kitchen. Creane una.</div>
          ) : (
            state.kitchens.map((k) => (
              <button
                key={k.id}
                className={"row w-full " + (k.id === state.currentKitchenId ? "ring-1 ring-black/10" : "")}
                onClick={() => selectKitchen(k.id)}
              >
                <div className="min-w-0">
                  <div className="font-semibold truncate">{k.name}</div>
                  <div className="p-muted text-xs truncate">{k.id}</div>
                </div>
                <span className="badge">{k.id === state.currentKitchenId ? "Attiva" : "Apri"}</span>
              </button>
            ))
          )}
        </div>
      </div>

      <div className="card p-4">
        <div className="h2">Par Levels — Michelin preset (pz)</div>
        <div className="p-muted text-xs mt-1">
          Sotto MIN: flag rosso in dashboard. I valori preset sono standard Michelin.
        </div>

        {!currentKitchen ? (
          <div className="p-muted text-sm mt-3">Seleziona una kitchen per modificare i Par Levels.</div>
        ) : (
          <div className="mt-3 space-y-2">
            {CATEGORY_KEYS.filter((k): k is CategoryKey => k !== "default").map((key) => {
              const preset = CATEGORY_PAR_PZ[key];
              const cur = Number(parMap[key] ?? preset);
              return (
                <div key={key} className="row">
                  <div className="min-w-0">
                    <div className="font-semibold">{CATEGORY_LABELS[key]}</div>
                    <div className="p-muted text-xs">preset Michelin: {preset} pz</div>
                  </div>
                  <input
                    className="input w-20 text-center"
                    type="number"
                    min={0}
                    step={1}
                    defaultValue={cur}
                    onBlur={(e) => {
                      const v = Math.max(0, Math.floor(Number(e.target.value || cur)));
                      setParCategory(key, v);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                    }}
                  />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
