import { createContext, useContext, useEffect, useMemo, useReducer } from "react";
import type { ReactNode } from "react";
import { v4 as uuid } from "uuid";
import type { FreezerItem, Location, Unit } from "../types/freezer";
import { CATEGORY_PAR_PZ } from "../data/catalog";

export type Role =
  | "admin" | "chef" | "sous-chef" | "capo-partita"
  | "commis" | "stagista" | "staff" | "fb" | "mm";

export type Member = { id: string; name: string; role: Role; joinedAt: string };

export type ShoppingCategory = "economato" | "giornaliero" | "settimanale" | "altro";

export type ShoppingItem = {
  id: string; name: string; quantity: number; unit: Unit;
  category: ShoppingCategory; notes?: string; checked: boolean; createdAt: string;
};

export type StockLedgerRow = {
  id: string; at: string; itemId: string; name: string;
  qty: number; unit: Unit; from?: Location; to?: Location; reason?: string; lot?: string;
};

export type Kitchen = {
  id: string; name: string; ownerName: string; createdAt: string;
  members: Member[];
  freezer: FreezerItem[]; fridge: FreezerItem[]; dry: FreezerItem[]; counter: FreezerItem[];
  parByCategory: Record<string, number>;
  shopping: ShoppingItem[];
  ledger: StockLedgerRow[];
};

export type KitchenState = {
  kitchens: Kitchen[];
  selectedKitchenId?: string;
  selectedMemberId?: string;
};

type Action =
  | { type: "KITCHEN_CREATE"; kitchen: Kitchen }
  | { type: "KITCHEN_SELECT"; kitchenId: string }
  | { type: "MEMBER_SELECT"; memberId: string }
  | { type: "MEMBER_ADD"; kitchenId: string; member: Member }
  | { type: "MEMBER_ROLE_UPDATE"; kitchenId: string; memberId: string; role: Role }
  | { type: "MEMBER_REMOVE"; kitchenId: string; memberId: string }
  | { type: "PAR_SET_CATEGORY"; kitchenId: string; categoryKey: string; par: number }
  | { type: "STOCK_ADD"; kitchenId: string; item: FreezerItem }
  | { type: "ITEM_ADJUST"; kitchenId: string; itemId: string; delta: number }
  | { type: "ITEM_REMOVE"; kitchenId: string; itemId: string }
  | { type: "ITEM_SET_PAR"; kitchenId: string; itemId: string; parLevel: number | null }
  | { type: "STOCK_MOVE"; kitchenId: string; itemId: string; qty: number; to: Location; reason?: string }
  | { type: "SHOP_ADD"; kitchenId: string; item: ShoppingItem }
  | { type: "SHOP_TOGGLE"; kitchenId: string; itemId: string }
  | { type: "SHOP_REMOVE"; kitchenId: string; itemId: string }
  | { type: "SHOP_CLEAR_CHECKED"; kitchenId: string; category?: ShoppingCategory };

const STORAGE_KEY = "kitchen-pro-state-v3";

const nowISO = () => new Date().toISOString();
const todayDate = () => new Date().toISOString().slice(0, 10);
const defaultParByCategory = (): Record<string, number> => ({ ...CATEGORY_PAR_PZ });

function mapStock(k: Kitchen, loc: Location): FreezerItem[] {
  if (loc === "freezer") return k.freezer;
  if (loc === "fridge")  return k.fridge;
  if (loc === "dry")     return k.dry;
  return k.counter;
}

function setStock(k: Kitchen, loc: Location, next: FreezerItem[]): Kitchen {
  if (loc === "freezer") return { ...k, freezer: next };
  if (loc === "fridge")  return { ...k, fridge: next };
  if (loc === "dry")     return { ...k, dry: next };
  return { ...k, counter: next };
}

function findItemLocation(k: Kitchen, itemId: string): Location | null {
  if (k.freezer.some(x => x.id === itemId)) return "freezer";
  if (k.fridge.some(x => x.id === itemId))  return "fridge";
  if (k.dry.some(x => x.id === itemId))     return "dry";
  if (k.counter.some(x => x.id === itemId)) return "counter";
  return null;
}

function reducer(state: KitchenState, action: Action): KitchenState {
  switch (action.type) {
    case "KITCHEN_CREATE": {
      const next = [...state.kitchens, action.kitchen];
      return { ...state, kitchens: next, selectedKitchenId: action.kitchen.id, selectedMemberId: action.kitchen.members[0]?.id };
    }
    case "KITCHEN_SELECT":  return { ...state, selectedKitchenId: action.kitchenId };
    case "MEMBER_SELECT":   return { ...state, selectedMemberId: action.memberId };

    case "MEMBER_ADD":
      return { ...state, kitchens: state.kitchens.map(k => k.id !== action.kitchenId ? k : { ...k, members: [...k.members, action.member] }) };

    case "MEMBER_ROLE_UPDATE":
      return { ...state, kitchens: state.kitchens.map(k => k.id !== action.kitchenId ? k : { ...k, members: k.members.map(m => m.id !== action.memberId ? m : { ...m, role: action.role }) }) };

    case "MEMBER_REMOVE": {
      const next = state.kitchens.map(k => k.id !== action.kitchenId ? k : { ...k, members: k.members.filter(m => m.id !== action.memberId) });
      const selectedMemberId = state.selectedMemberId === action.memberId ? undefined : state.selectedMemberId;
      return { ...state, kitchens: next, selectedMemberId };
    }

    case "PAR_SET_CATEGORY":
      return { ...state, kitchens: state.kitchens.map(k => k.id !== action.kitchenId ? k : { ...k, parByCategory: { ...k.parByCategory, [action.categoryKey]: action.par } }) };

    case "STOCK_ADD":
      return { ...state, kitchens: state.kitchens.map(k => { if (k.id !== action.kitchenId) return k; const loc = action.item.location; return setStock(k, loc, [action.item, ...mapStock(k, loc)]); }) };

    case "ITEM_ADJUST":
      return { ...state, kitchens: state.kitchens.map(k => { if (k.id !== action.kitchenId) return k; const loc = findItemLocation(k, action.itemId); if (!loc) return k; const list = mapStock(k, loc).map(x => x.id !== action.itemId ? x : { ...x, quantity: Math.max(0, (Number(x.quantity) || 0) + action.delta) }).filter(x => x.quantity > 0); return setStock(k, loc, list); }) };

    case "ITEM_REMOVE":
      return { ...state, kitchens: state.kitchens.map(k => { if (k.id !== action.kitchenId) return k; const loc = findItemLocation(k, action.itemId); if (!loc) return k; return setStock(k, loc, mapStock(k, loc).filter(x => x.id !== action.itemId)); }) };

    case "ITEM_SET_PAR":
      return { ...state, kitchens: state.kitchens.map(k => { if (k.id !== action.kitchenId) return k; const loc = findItemLocation(k, action.itemId); if (!loc) return k; return setStock(k, loc, mapStock(k, loc).map(x => x.id !== action.itemId ? x : { ...x, parLevel: action.parLevel })); }) };

    case "STOCK_MOVE": {
      const next = state.kitchens.map(k => {
        if (k.id !== action.kitchenId) return k;
        const fromLoc = findItemLocation(k, action.itemId); if (!fromLoc) return k;
        const fromList = mapStock(k, fromLoc);
        const src = fromList.find(x => x.id === action.itemId); if (!src) return k;
        const qty = Math.max(0, Number(action.qty) || 0); if (qty <= 0) return k;
        const remaining = (Number(src.quantity) || 0) - qty;
        const nextFrom = fromList.map(x => x.id !== action.itemId ? x : { ...x, quantity: remaining }).filter(x => x.quantity > 0);
        const moved: FreezerItem = { ...src, id: uuid(), location: action.to, quantity: qty, insertedAt: nowISO(), insertedDate: todayDate() };
        const ledgerRow: StockLedgerRow = { id: uuid(), at: nowISO(), itemId: src.id, name: src.name, qty, unit: src.unit, from: fromLoc, to: action.to, reason: action.reason, lot: src.lot };
        let upd = setStock(k, fromLoc, nextFrom);
        upd = setStock(upd, action.to, [moved, ...mapStock(upd, action.to)]);
        return { ...upd, ledger: [ledgerRow, ...upd.ledger] };
      });
      return { ...state, kitchens: next };
    }

    case "SHOP_ADD":
      return { ...state, kitchens: state.kitchens.map(k => k.id !== action.kitchenId ? k : { ...k, shopping: [action.item, ...k.shopping] }) };
    case "SHOP_TOGGLE":
      return { ...state, kitchens: state.kitchens.map(k => k.id !== action.kitchenId ? k : { ...k, shopping: k.shopping.map(x => x.id !== action.itemId ? x : { ...x, checked: !x.checked }) }) };
    case "SHOP_REMOVE":
      return { ...state, kitchens: state.kitchens.map(k => k.id !== action.kitchenId ? k : { ...k, shopping: k.shopping.filter(x => x.id !== action.itemId) }) };
    case "SHOP_CLEAR_CHECKED": {
      const cat = action.category;
      return { ...state, kitchens: state.kitchens.map(k => k.id !== action.kitchenId ? k : { ...k, shopping: k.shopping.filter(x => !x.checked || (cat !== undefined && x.category !== cat)) }) };
    }
    default: return state;
  }
}

function loadInitial(): KitchenState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { kitchens: [] };
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.kitchens)) return { kitchens: [] };
    // migrate: ensure ledger exists on each kitchen
    parsed.kitchens = parsed.kitchens.map((k: any) => ({ ledger: [], ...k }));
    return parsed as KitchenState;
  } catch { return { kitchens: [] }; }
}

export type KitchenStore = {
  state: KitchenState;
  createKitchen: (name: string, ownerName?: string) => void;
  selectKitchen: (kitchenId: string) => void;
  selectMember: (memberId: string) => void;
  addMember: (...args: any[]) => void;
  updateMemberRole: (...args: any[]) => void;
  removeMember: (...args: any[]) => void;
  getCurrentRole: () => Role;
  setParCategory: (categoryKey: string, par: number) => void;
  stockAdd: (item: Partial<FreezerItem> & { name: string; quantity: number; unit: Unit; location: Location }) => void;
  addFreezerItem: (item: Partial<FreezerItem> & { name: string; quantity: number; unit: Unit }) => void;
  adjustFreezerItem: (itemId: string, delta: number) => void;
  removeFreezerItem: (itemId: string) => void;
  setFreezerParLevel: (itemId: string, parLevel: number | null) => void;
  moveStock: (itemId: string, qty: number, to: Location, reason?: string) => void;
  shopAdd: (name: string, quantity: number, unit: Unit, category: ShoppingCategory, notes?: string) => void;
  shopToggle: (itemId: string) => void;
  shopRemove: (itemId: string) => void;
  shopClearChecked: (category?: ShoppingCategory) => void;
};

const KitchenCtx = createContext<KitchenStore | null>(null);

export function KitchenProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined as any, loadInitial);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
  }, [state]);

  const api = useMemo<KitchenStore>(() => {
    const kid = () => state.selectedKitchenId || state.kitchens[0]?.id;

    const createKitchen = (name: string, ownerName?: string) => {
      const n = (name || "").trim(); if (!n) return;
      const owner = (ownerName || "Admin").trim() || "Admin";
      const ownerMember: Member = { id: uuid(), name: owner, role: "admin", joinedAt: nowISO() };
      dispatch({ type: "KITCHEN_CREATE", kitchen: { id: uuid(), name: n, ownerName: owner, createdAt: nowISO(), members: [ownerMember], freezer: [], fridge: [], dry: [], counter: [], parByCategory: defaultParByCategory(), shopping: [], ledger: [] } });
    };

    const selectKitchen = (id: string) => dispatch({ type: "KITCHEN_SELECT", kitchenId: id });
    const selectMember  = (id: string) => dispatch({ type: "MEMBER_SELECT", memberId: id });

    const addMember = (...args: any[]) => {
      const kId  = args.length >= 3 ? String(args[0]) : (kid() || "");
      const name = args.length >= 3 ? String(args[1]) : String(args[0] || "");
      const role = (args.length >= 3 ? args[2] : args[1] ?? "staff") as Role;
      if (!kId || !(name || "").trim()) return;
      dispatch({ type: "MEMBER_ADD", kitchenId: kId, member: { id: uuid(), name: name.trim(), role, joinedAt: nowISO() } });
    };

    const updateMemberRole = (...args: any[]) => {
      const kitchenId = args.length >= 3 ? String(args[0]) : (kid() || "");
      const memberId  = args.length >= 3 ? String(args[1]) : String(args[0] || "");
      const role      = (args.length >= 3 ? args[2] : args[1]) as Role;
      if (!kitchenId || !memberId || !role) return;
      dispatch({ type: "MEMBER_ROLE_UPDATE", kitchenId, memberId, role });
    };

    const removeMember = (...args: any[]) => {
      const kitchenId = args.length >= 2 ? String(args[0]) : (kid() || "");
      const memberId  = args.length >= 2 ? String(args[1]) : String(args[0] || "");
      if (!kitchenId || !memberId) return;
      dispatch({ type: "MEMBER_REMOVE", kitchenId, memberId });
    };

    const getCurrentRole = (): Role => {
      const k = state.kitchens.find(x => x.id === kid());
      if (!k) return "admin";
      const m = k.members.find(x => x.id === state.selectedMemberId) || k.members[0];
      return m?.role || "admin";
    };

    const setParCategory = (categoryKey: string, par: number) => {
      const k = kid(); if (!k) return;
      const p = Number(par); if (!Number.isFinite(p) || p < 0) return;
      dispatch({ type: "PAR_SET_CATEGORY", kitchenId: k, categoryKey, par: p });
    };

    const stockAdd = (item: Partial<FreezerItem> & { name: string; quantity: number; unit: Unit; location: Location }) => {
      const k = kid(); if (!k) return;
      const name = (item.name || "").trim();
      const qty = Number(item.quantity);
      if (!name || !Number.isFinite(qty) || qty <= 0) return;
      dispatch({ type: "STOCK_ADD", kitchenId: k, item: { id: item.id || uuid(), name, quantity: qty, unit: item.unit, location: item.location, insertedAt: item.insertedAt || nowISO(), insertedDate: item.insertedDate || todayDate(), expiresAt: item.expiresAt, lot: item.lot, notes: item.notes, section: item.section, category: item.category, catalogId: item.catalogId, parLevel: item.parLevel ?? undefined } });
    };

    const addFreezerItem = (item: Partial<FreezerItem> & { name: string; quantity: number; unit: Unit }) =>
      stockAdd({ ...item, location: item.location || "freezer" });

    const adjustFreezerItem = (itemId: string, delta: number) => {
      const k = kid(); if (!k) return;
      const d = Number(delta); if (!Number.isFinite(d) || d === 0) return;
      dispatch({ type: "ITEM_ADJUST", kitchenId: k, itemId, delta: d });
    };

    const removeFreezerItem = (itemId: string) => {
      const k = kid(); if (!k) return;
      dispatch({ type: "ITEM_REMOVE", kitchenId: k, itemId });
    };

    const setFreezerParLevel = (itemId: string, parLevel: number | null) => {
      const k = kid(); if (!k) return;
      if (parLevel !== null) { const p = Number(parLevel); if (!Number.isFinite(p) || p < 0) return; }
      dispatch({ type: "ITEM_SET_PAR", kitchenId: k, itemId, parLevel });
    };

    const moveStock = (itemId: string, qty: number, to: Location, reason?: string) => {
      const k = kid(); if (!k) return;
      const q = Number(qty); if (!Number.isFinite(q) || q <= 0) return;
      dispatch({ type: "STOCK_MOVE", kitchenId: k, itemId, qty: q, to, reason });
    };

    const shopAdd = (name: string, quantity: number, unit: Unit, category: ShoppingCategory, notes?: string) => {
      const k = kid(); if (!k) return;
      const n = (name || "").trim(); const q = Number(quantity);
      if (!n || !Number.isFinite(q) || q <= 0) return;
      dispatch({ type: "SHOP_ADD", kitchenId: k, item: { id: uuid(), name: n, quantity: q, unit, category, notes: (notes || "").trim() || undefined, checked: false, createdAt: nowISO() } });
    };

    const shopToggle       = (itemId: string) => { const k = kid(); if (k) dispatch({ type: "SHOP_TOGGLE", kitchenId: k, itemId }); };
    const shopRemove       = (itemId: string) => { const k = kid(); if (k) dispatch({ type: "SHOP_REMOVE", kitchenId: k, itemId }); };
    const shopClearChecked = (category?: ShoppingCategory) => { const k = kid(); if (k) dispatch({ type: "SHOP_CLEAR_CHECKED", kitchenId: k, category }); };

    return { state, createKitchen, selectKitchen, selectMember, addMember, updateMemberRole, removeMember, getCurrentRole, setParCategory, stockAdd, addFreezerItem, adjustFreezerItem, removeFreezerItem, setFreezerParLevel, moveStock, shopAdd, shopToggle, shopRemove, shopClearChecked };
  }, [state]);

  return <KitchenCtx.Provider value={api}>{children}</KitchenCtx.Provider>;
}

export function useKitchen(): KitchenStore {
  const ctx = useContext(KitchenCtx);
  if (!ctx) throw new Error("useKitchen must be used inside <KitchenProvider />");
  return ctx;
}
