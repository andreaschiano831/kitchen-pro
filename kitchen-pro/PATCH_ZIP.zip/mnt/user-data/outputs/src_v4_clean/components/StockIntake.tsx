import { useEffect, useMemo, useState } from "react";
import { useKitchen } from "../store/kitchenStore";
import type { Location, Unit } from "../types/freezer";
import { CATALOG, CATEGORY_LABELS, CATEGORY_PAR_PZ } from "../data/catalog";
import type { CategoryKey } from "../data/catalog";

type Props = {
  defaultLocation?: Location;
  lockLocation?: boolean;
};

const UNITS: Unit[] = ["pz", "g", "kg", "ml", "l", "vac", "busta", "brik", "latta", "box", "vasch"];

const todayISO = () => new Date().toISOString().slice(0, 10);

export default function StockIntake({ defaultLocation, lockLocation }: Props) {
  const { stockAdd, state } = useKitchen();

  // ── Category & catalog selection ──────────────────────────────────────────
  const categoryKeys = useMemo<string[]>(() => {
    const seen = new Set<string>();
    CATALOG.forEach(x => seen.add(String(x.categoryKey)));
    return Array.from(seen).sort();
  }, []);

  const [categoryKey, setCategoryKey] = useState<string>(categoryKeys[0] ?? "proteine");

  const itemsInCategory = useMemo(
    () => CATALOG.filter(x => String(x.categoryKey) === categoryKey),
    [categoryKey]
  );

  const [catalogId, setCatalogId] = useState<string>(itemsInCategory[0]?.id ?? "");

  useEffect(() => {
    if (!itemsInCategory.some(x => x.id === catalogId)) {
      setCatalogId(itemsInCategory[0]?.id ?? "");
    }
  }, [itemsInCategory, catalogId]);

  const selected = useMemo(
    () => itemsInCategory.find(x => x.id === catalogId) ?? null,
    [itemsInCategory, catalogId]
  );

  // ── Location ──────────────────────────────────────────────────────────────
  const [location, setLocation] = useState<Location>(
    defaultLocation ?? selected?.defaultLocation ?? "fridge"
  );

  useEffect(() => {
    setLocation(defaultLocation ?? selected?.defaultLocation ?? "fridge");
  }, [defaultLocation, selected]);

  // ── Form fields ───────────────────────────────────────────────────────────
  const [qty,          setQty]          = useState<number>(1);
  const [unit,         setUnit]         = useState<Unit>("pz");
  const [insertedDate, setInsertedDate] = useState<string>(todayISO());
  const [expiresAt,    setExpiresAt]    = useState<string>("");
  const [lot,          setLot]          = useState<string>("");

  // ── Existing lots (same product already in stock) ────────────────────────
  const existingLots = useMemo(() => {
    const kitchenId = state.selectedKitchenId ?? state.kitchens[0]?.id;
    const k = state.kitchens.find(x => x.id === kitchenId);
    if (!k || !selected) return [];
    return [...k.freezer, ...k.fridge, ...k.dry, ...k.counter]
      .filter(x =>
        (x.catalogId && x.catalogId === selected.id) ||
        x.name.toLowerCase() === selected.name.toLowerCase()
      )
      .map(x => ({
        id:       x.id,
        loc:      x.location,
        qty:      x.quantity,
        unit:     x.unit,
        lot:      x.lot ?? "",
        inserted: (x.insertedDate ?? x.insertedAt ?? "").slice(0, 10),
        exp:      x.expiresAt ? x.expiresAt.slice(0, 10) : "",
      }));
  }, [state, selected]);

  // ── Submit ────────────────────────────────────────────────────────────────
  const canSubmit = !!selected && Number.isFinite(qty) && qty > 0 && lot.trim().length > 0;

  function submit() {
    if (!canSubmit || !selected) return;

    stockAdd({
      name:         selected.name,
      quantity:     qty,
      unit,
      location:     lockLocation ? (defaultLocation ?? location) : location,
      insertedAt:   insertedDate ? new Date(insertedDate).toISOString() : new Date().toISOString(),
      insertedDate: insertedDate || todayISO(),
      expiresAt:    expiresAt ? new Date(expiresAt).toISOString() : undefined,
      lot:          lot.trim(),
      category:     String(selected.categoryKey),
      catalogId:    selected.id,
    });

    // reset volatile fields only
    setQty(1);
    setLot("");
  }

  // ── Derived labels ────────────────────────────────────────────────────────
  const parPreset = CATEGORY_PAR_PZ[categoryKey as CategoryKey];
  const catLabel  = CATEGORY_LABELS[categoryKey as CategoryKey] ?? categoryKey;

  // ── UI ────────────────────────────────────────────────────────────────────
  return (
    <div className="card p-4 space-y-4">
      {/* Header */}
      <div>
        <div className="text-sm font-semibold">Carico giacenza</div>
        <div className="text-xs opacity-60 mt-0.5">
          Par preset: <strong>{parPreset ?? "—"}</strong> pz &bull; {catLabel}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Categoria */}
        <div>
          <label className="text-xs opacity-60 block mb-1">Categoria</label>
          <select
            className="select w-full"
            value={categoryKey}
            onChange={e => setCategoryKey(e.target.value)}
          >
            {categoryKeys.map(k => (
              <option key={k} value={k}>
                {CATEGORY_LABELS[k as CategoryKey] ?? k}
              </option>
            ))}
          </select>
        </div>

        {/* Prodotto */}
        <div>
          <label className="text-xs opacity-60 block mb-1">Prodotto</label>
          <select
            className="select w-full"
            value={catalogId}
            onChange={e => setCatalogId(e.target.value)}
          >
            {itemsInCategory.map(x => (
              <option key={x.id} value={x.id}>{x.name}</option>
            ))}
          </select>
        </div>

        {/* Ubicazione */}
        <div>
          <label className="text-xs opacity-60 block mb-1">Ubicazione</label>
          <select
            className="select w-full"
            value={location}
            disabled={!!lockLocation}
            onChange={e => setLocation(e.target.value as Location)}
          >
            <option value="fridge">Frigo</option>
            <option value="freezer">Congelatore</option>
            <option value="dry">Dispensa</option>
            <option value="counter">Banco</option>
          </select>
          {lockLocation && (
            <p className="text-[10px] opacity-50 mt-1">Bloccata (route corrente).</p>
          )}
        </div>

        {/* Qty + Unit */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs opacity-60 block mb-1">Quantità</label>
            <input
              className="input w-full"
              type="number"
              min="0"
              step="1"
              value={qty}
              onChange={e => setQty(Number(e.target.value || "0"))}
            />
          </div>
          <div>
            <label className="text-xs opacity-60 block mb-1">Unità</label>
            <select
              className="select w-full"
              value={unit}
              onChange={e => setUnit(e.target.value as Unit)}
            >
              {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
            </select>
          </div>
        </div>

        {/* Date carico */}
        <div>
          <label className="text-xs opacity-60 block mb-1">Data carico</label>
          <input
            className="input w-full"
            type="date"
            value={insertedDate}
            onChange={e => setInsertedDate(e.target.value)}
          />
        </div>

        {/* Scadenza */}
        <div>
          <label className="text-xs opacity-60 block mb-1">Scadenza (opz.)</label>
          <input
            className="input w-full"
            type="date"
            value={expiresAt}
            onChange={e => setExpiresAt(e.target.value)}
          />
        </div>

        {/* Lotto */}
        <div className="md:col-span-2">
          <label className="text-xs opacity-60 block mb-1">
            Lotto <span className="text-red-500">*</span>
          </label>
          <input
            className="input w-full"
            placeholder="LOT-2502-A · DDT · Fornitore"
            value={lot}
            onChange={e => setLot(e.target.value)}
          />
          {!lot.trim() && (
            <p className="text-[10px] text-red-500 mt-1">
              Inserisci il lotto per la tracciabilità HACCP.
            </p>
          )}
        </div>
      </div>

      {/* Submit */}
      <button
        className="btn btn-primary w-full"
        disabled={!canSubmit}
        onClick={submit}
      >
        Carica
      </button>

      {/* Existing lots */}
      {existingLots.length > 0 && (
        <div className="pt-1 border-t border-base-200">
          <div className="text-xs opacity-50 mb-2">
            Già in magazzino (stesso prodotto)
          </div>
          <div className="space-y-1">
            {existingLots.slice(0, 8).map(x => (
              <div key={x.id} className="text-xs opacity-70 leading-snug">
                <span className="font-medium">{x.loc}</span>
                {" "}&bull; {x.qty} {x.unit}
                {x.lot ? ` &bull; lotto ${x.lot}` : ""}
                {" "}&bull; {x.inserted}
                {x.exp ? ` &bull; exp ${x.exp}` : ""}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
