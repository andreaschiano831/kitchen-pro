import type { Location } from "../types/freezer";
import userCatalog from "./catalog.user.json";

export type CategoryKey =
  | "proteine"
  | "pesce"
  | "verdure"
  | "erbe"
  | "dairy"
  | "cereali"
  | "grassi"
  | "acidi"
  | "spezie"
  | "fondi"
  | "beverage"
  | "secco";

export const CATEGORY_LABELS: Record<CategoryKey, string> = {
  proteine: "Proteine animali",
  pesce:    "Pesce & molluschi",
  verdure:  "Verdure & radici",
  erbe:     "Erbe & fiori",
  dairy:    "Latticini & uova",
  cereali:  "Farine & cereali",
  grassi:   "Grassi & oli",
  acidi:    "Acidi & fermentati",
  spezie:   "Spezie & aromi secchi",
  fondi:    "Fondi & riduzioni",
  beverage: "Cantina & beverage",
  secco:    "Consumabili & secco",
};

export const CATEGORY_PAR_PZ: Record<CategoryKey, number> = {
  proteine: 6,
  pesce:    4,
  verdure:  8,
  erbe:     12,
  dairy:    6,
  cereali:  3,
  grassi:   4,
  acidi:    6,
  spezie:   10,
  fondi:    4,
  beverage: 6,
  secco:    5,
};

export type CatalogItem = {
  id: string;
  name: string;
  categoryKey: CategoryKey;
  defaultLocation: Location;
};

function isCatalogItem(x: unknown): x is CatalogItem {
  if (!x || typeof x !== "object") return false;
  const o = x as Record<string, unknown>;
  return (
    typeof o.id === "string" &&
    typeof o.name === "string" &&
    typeof o.categoryKey === "string" &&
    typeof o.defaultLocation === "string"
  );
}

const fromUser = Array.isArray(userCatalog)
  ? (userCatalog as unknown[]).filter(isCatalogItem)
  : [];

const FALLBACK: CatalogItem[] = [
  { id: "demo-piccione",   name: "Piccione (demo)",   categoryKey: "proteine", defaultLocation: "freezer" },
  { id: "demo-rombo",      name: "Rombo (demo)",       categoryKey: "pesce",    defaultLocation: "fridge"  },
  { id: "demo-topinambur", name: "Topinambur (demo)",  categoryKey: "verdure",  defaultLocation: "dry"     },
];

export const CATALOG: CatalogItem[] = fromUser.length > 0 ? fromUser : FALLBACK;
