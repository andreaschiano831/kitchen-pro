import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  type ReactNode,
} from "react";
import { v4 as uuid } from "uuid";
import type { FreezerItem, Location, Unit } from "../types/freezer";

export type Role =
  | "admin"
  | "chef"
  | "sous-chef"
  | "capo-partita"
  | "commis"
  | "stagista"
  | "staff";

export type Member = {
  id: string;
  name: string;
  role: Role;
  joinedAt: string;
};

export type ShoppingCategory = "economato" | "giornaliero" | "settimanale" | "altro";

export type ShoppingItem = {
  id: string;
  name: string;
  quantity: number;
  unit: Unit;
  category: ShoppingCategory;
  notes?: string;
  checked: boolean;
  createdAt: string;
};

export type StockMovement = {
  id: string;
  at: string;
  itemId: string;
  name: string;
  from: Location | null;
  to: Location | null;
  quantity: number;
  unit: Unit;
  reason?: string;
};

export type Kitchen = {
  id: string;
  name: string;
  ownerName: string;
  members: Member[];
  freezer: FreezerItem[];
  fridge: FreezerItem[];
  dry: FreezerItem[];
  counter: FreezerItem[];
  shopping: ShoppingItem[];
  movements: StockMovement[];
  parByCategory: Record<string, number>;
  createdAt: string;
  updatedAt: string;
};

export type KitchenState = {
  kitchens: Kitchen[];
  currentKitchenId: string | null;
  currentMemberId: string | null;
  theme: string;
};

type Action =
  | { type: "SET_THEME"; theme: string }
  | { type: "KITCHEN_CREATE"; name: string; ownerName?: string }
  | { type: "KITCHEN_SELECT"; kitchenId: string }
  | { type: "MEMBER_ADD"; kitchenId: string; name: string; role?: Role }
  | { type: "MEMBER_ROLE_UPDATE"; kitchenId: string; memberId: string; role: Role }
  | { type: "MEMBER_REMOVE"; kitchenId: string; memberId: string }
  | { type: "CURRENT_MEMBER_SET"; memberId: string }
  | { type: "PAR_SET_CATEGORY"; kitchenId: string; categoryKey: string; par: number }
  | { type: "ITEM_ADD"; kitchenId: string; item: Omit<FreezerItem, "id"> & { id?: string } }
  | { type: "ITEM_ADJUST"; kitchenId: string; itemId: string; value: number; mode: "delta" | "set" }
  | { type: "ITEM_REMOVE"; kitchenId: string; itemId: string }
  | { type: "ITEM_SET_PAR"; kitchenId: string; itemId: string; parLevel?: number }
  | { type: "STOCK_MOVE"; kitchenId: string; itemId: string; qty: number; to: Location; reason?: string }
  | { type: "SHOP_ADD"; kitchenId: string; name: string; quantity: number; unit: Unit; category: ShoppingCategory; notes?: string }
  | { type: "SHOP_TOGGLE"; kitchenId: string; itemId: string }
  | { type: "SHOP_REMOVE"; kitchenId: string; itemId: string }
  | { type: "SHOP_CLEAR_CHECKED"; kitchenId: string };

const STORAGE_KEY = "kitchen-pro/v2";
const LOCS: Location[] = ["freezer", "fridge", "dry", "counter"];

const nowIso = () => new Date().toISOString();
const today = () => new Date().toISOString().slice(0, 10);

function safeLoad(): KitchenState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return null;
    return parsed as KitchenState;
  } catch {
    return null;
  }
}

function ensureKitchenShape(k: any): Kitchen {
  return {
    id: String(k?.id ?? uuid()),
    name: String(k?.name ?? "Kitchen"),
    ownerName: String(k?.ownerName ?? "Admin"),
    members: Array.isArray(k?.members) ? k.members : [],
    freezer: Array.isArray(k?.freezer) ? k.freezer : [],
    fridge: Array.isArray(k?.fridge) ? k.fridge : [],
    dry: Array.isArray(k?.dry) ? k.dry : [],
    counter: Array.isArray(k?.counter) ? k.counter : [],
    shopping: Array.isArray(k?.shopping) ? k.shopping : [],
    movements: Array.isArray(k?.movements) ? k.movements : [],
    parByCategory: k?.parByCategory && typeof k.parByCategory === "object" ? k.parByCategory : {},
    createdAt: String(k?.createdAt ?? nowIso()),
    updatedAt: String(k?.updatedAt ?? nowIso()),
  };
}

function normalizeState(s: any): KitchenState {
  const kitchens = Array.isArray(s?.kitchens) ? s.kitchens.map(ensureKitchenShape) : [];
  return {
    kitchens,
    theme: s?.theme ?? "light",
    currentKitchenId: s?.currentKitchenId ? String(s.currentKitchenId) : (kitchens[0]?.id ?? null),
    currentMemberId: s?.currentMemberId ? String(s.currentMemberId) : null,
  };
}

const SEED: KitchenState = {
  kitchens: [],
  currentKitchenId: null,
  currentMemberId: null,
  theme: "light",
};

function getKitchenId(state: KitchenState, kitchenId?: string) {
  return kitchenId ?? state.currentKitchenId ?? state.kitchens[0]?.id ?? null;
}

function updateKitchen(
  state: KitchenState,
  kitchenId: string,
  fn: (k: Kitchen) => Kitchen
): KitchenState {
  return {
    ...state,
    kitchens: state.kitchens.map((k) => {
      if (k.id !== kitchenId) return k;
      const next = fn(k);
      return { ...next, updatedAt: nowIso() };
    }),
  };
}

function findItem(
  k: Kitchen,
  itemId: string
): { loc: Location; idx: number; item: FreezerItem } | null {
  for (const loc of LOCS) {
    const arr = k[loc];
    const idx = arr.findIndex((x) => x.id === itemId);
    if (idx >= 0) return { loc, idx, item: arr[idx] };
  }
  return null;
}

function reducer(state: KitchenState, action: Action): KitchenState {
  switch (action.type) {
    case "SET_THEME":
      return { ...state, theme: action.theme };

    case "KITCHEN_CREATE": {
      const name = action.name.trim();
      const ownerName = (action.ownerName ?? "Admin").trim() || "Admin";
      const ownerMember: Member = {
        id: uuid(), name: ownerName, role: "admin", joinedAt: nowIso(),
      };
      const k: Kitchen = {
        id: uuid(), name: name || "Kitchen", ownerName,
        members: [ownerMember],
        freezer: [], fridge: [], dry: [], counter: [],
        shopping: [], movements: [], parByCategory: {},
        createdAt: nowIso(), updatedAt: nowIso(),
      };
      return {
        ...state,
        kitchens: [...state.kitchens, k],
        currentKitchenId: k.id,
        currentMemberId: ownerMember.id,
      };
    }

    case "KITCHEN_SELECT":
      return { ...state, currentKitchenId: action.kitchenId };

    case "CURRENT_MEMBER_SET":
      return { ...state, currentMemberId: action.memberId };

    case "MEMBER_ADD":
      return updateKitchen(state, action.kitchenId, (k) => {
        const name = action.name.trim();
        if (!name) return k;
        const m: Member = { id: uuid(), name, role: action.role ?? "commis", joinedAt: nowIso() };
        return { ...k, members: [...k.members, m] };
      });

    case "MEMBER_ROLE_UPDATE":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        members: k.members.map((m) =>
          m.id === action.memberId ? { ...m, role: action.role } : m
        ),
      }));

    case "MEMBER_REMOVE":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        members: k.members.filter((m) => m.id !== action.memberId),
      }));

    case "PAR_SET_CATEGORY":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        parByCategory: { ...k.parByCategory, [action.categoryKey]: action.par },
      }));

    case "ITEM_ADD":
      return updateKitchen(state, action.kitchenId, (k) => {
        const it = action.item;
        const loc: Location = (it.location as Location) ?? "fridge";
        const item: FreezerItem = {
          id: it.id ?? uuid(),
          name: String(it.name ?? "").trim(),
          quantity: Number(it.quantity ?? 0),
          unit: (it.unit as Unit) ?? "pz",
          location: loc,
          insertedAt: String(it.insertedAt ?? nowIso()),
          insertedDate: String(it.insertedDate ?? today()),
          expiresAt: it.expiresAt,
          lot: it.lot,
          notes: it.notes,
          section: it.section,
          category: it.category,
          catalogId: it.catalogId,
          parLevel: it.parLevel,
        };
        // FIX: single guard, no duplicate
        if (!item.name || !Number.isFinite(item.quantity) || item.quantity <= 0) return k;
        return { ...k, [loc]: [...k[loc], item] };
      });

    case "ITEM_ADJUST":
      return updateKitchen(state, action.kitchenId, (k) => {
        const found = findItem(k, action.itemId);
        if (!found) return k;
        const { loc, idx, item } = found;
        const nextQty =
          action.mode === "set" ? action.value : item.quantity + action.value;
        const arr = [...k[loc]];
        if (nextQty <= 0) arr.splice(idx, 1);
        else arr[idx] = { ...item, quantity: nextQty };
        return { ...k, [loc]: arr };
      });

    case "ITEM_REMOVE":
      return updateKitchen(state, action.kitchenId, (k) => {
        const next = { ...k };
        for (const loc of LOCS) next[loc] = next[loc].filter((x) => x.id !== action.itemId);
        return next;
      });

    case "ITEM_SET_PAR":
      return updateKitchen(state, action.kitchenId, (k) => {
        const found = findItem(k, action.itemId);
        if (!found) return k;
        const { loc, idx, item } = found;
        const arr = [...k[loc]];
        arr[idx] = { ...item, parLevel: action.parLevel };
        return { ...k, [loc]: arr };
      });

    case "STOCK_MOVE":
      return updateKitchen(state, action.kitchenId, (k) => {
        const found = findItem(k, action.itemId);
        if (!found) return k;
        const { loc: fromLoc, idx, item } = found;
        const qty = Math.max(0, Math.min(item.quantity, action.qty));
        if (qty <= 0) return k;
        const fromArr = [...k[fromLoc]];
        const remaining = item.quantity - qty;
        if (remaining <= 0) fromArr.splice(idx, 1);
        else fromArr[idx] = { ...item, quantity: remaining };
        const toLoc = action.to;
        const toArr = [...k[toLoc]];
        const mergeIdx = toArr.findIndex(
          (x) =>
            x.name.toLowerCase() === item.name.toLowerCase() &&
            x.unit === item.unit &&
            String(x.lot ?? "") === String(item.lot ?? "")
        );
        if (mergeIdx >= 0) {
          toArr[mergeIdx] = { ...toArr[mergeIdx], quantity: toArr[mergeIdx].quantity + qty };
        } else {
          toArr.push({
            ...item, id: uuid(), location: toLoc, quantity: qty,
            insertedAt: nowIso(), insertedDate: today(),
          });
        }
        const mv: StockMovement = {
          id: uuid(), at: nowIso(), itemId: action.itemId, name: item.name,
          from: fromLoc, to: toLoc, quantity: qty, unit: item.unit, reason: action.reason,
        };
        return { ...k, [fromLoc]: fromArr, [toLoc]: toArr, movements: [mv, ...k.movements] };
      });

    case "SHOP_ADD":
      return updateKitchen(state, action.kitchenId, (k) => {
        const name = action.name.trim();
        if (!name) return k;
        const it: ShoppingItem = {
          id: uuid(), name,
          quantity: Math.max(1, Number(action.quantity || 1)),
          unit: action.unit, category: action.category,
          notes: action.notes?.trim() || undefined,
          checked: false, createdAt: nowIso(),
        };
        return { ...k, shopping: [it, ...k.shopping] };
      });

    case "SHOP_TOGGLE":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        shopping: k.shopping.map((x) =>
          x.id === action.itemId ? { ...x, checked: !x.checked } : x
        ),
      }));

    case "SHOP_REMOVE":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        shopping: k.shopping.filter((x) => x.id !== action.itemId),
      }));

    case "SHOP_CLEAR_CHECKED":
      return updateKitchen(state, action.kitchenId, (k) => ({
        ...k,
        shopping: k.shopping.filter((x) => !x.checked),
      }));

    default:
      return state;
  }
}

export type KitchenStore = {
  state: KitchenState;
  createKitchen: (name: string, ownerName?: string) => void;
  selectKitchen: (kitchenId: string) => void;
  addMember: (kitchenId: string, name: string, role?: Role) => void;
  // FIX: both now require kitchenId as first param
  updateMemberRole: (kitchenId: string, memberId: string, role: Role) => void;
  removeMember: (kitchenId: string, memberId: string) => void;
  setCurrentMember: (memberId: string) => void;
  getCurrentRole: () => Role;
  setTheme: (theme: string) => void;
  setParCategory: (categoryKey: string, par: number) => void;
  addFreezerItem: (item: Omit<FreezerItem, "id"> & { id?: string }) => void;
  // FIX: stockAdd properly aliased (was missing, caused crash in StockIntake)
  stockAdd: (item: Omit<FreezerItem, "id"> & { id?: string }) => void;
  adjustFreezerItem: (itemId: string, value: number, mode?: "delta" | "set") => void;
  removeFreezerItem: (itemId: string) => void;
  setFreezerParLevel: (itemId: string, parLevel?: number) => void;
  moveStock: (itemId: string, qty: number, to: Location, reason?: string) => void;
  shopAdd: (name: string, quantity: number, unit: Unit, category: ShoppingCategory, notes?: string) => void;
  shopToggle: (itemId: string) => void;
  shopRemove: (itemId: string) => void;
  shopClearChecked: () => void;
};

const Ctx = createContext<KitchenStore | null>(null);

export function KitchenProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, SEED, () => {
    const loaded = safeLoad();
    return loaded ? normalizeState(loaded) : SEED;
  });

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
  }, [state]);

  const store = useMemo<KitchenStore>(() => {
    // FIX: removed unused _kitchenId variable (was causing TS/lint warning)
    const kid = (): string => getKitchenId(state) ?? "";

    return {
      state,
      setTheme: (theme) => dispatch({ type: "SET_THEME", theme }),
      createKitchen: (name, ownerName) => dispatch({ type: "KITCHEN_CREATE", name, ownerName }),
      selectKitchen: (kitchenId) => dispatch({ type: "KITCHEN_SELECT", kitchenId }),
      addMember: (kitchenId, name, role) => dispatch({ type: "MEMBER_ADD", kitchenId, name, role }),
      updateMemberRole: (kitchenId, memberId, role) =>
        dispatch({ type: "MEMBER_ROLE_UPDATE", kitchenId, memberId, role }),
      removeMember: (kitchenId, memberId) =>
        dispatch({ type: "MEMBER_REMOVE", kitchenId, memberId }),
      setCurrentMember: (memberId) => dispatch({ type: "CURRENT_MEMBER_SET", memberId }),
      getCurrentRole: () => {
        const k = state.kitchens.find((x) => x.id === (state.currentKitchenId ?? "")) ?? state.kitchens[0];
        if (!k) return "admin";
        const m = k.members.find((mm) => mm.id === state.currentMemberId);
        return m?.role ?? "admin";
      },
      setParCategory: (categoryKey, par) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "PAR_SET_CATEGORY", kitchenId: k, categoryKey, par });
      },
      addFreezerItem: (item) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "ITEM_ADD", kitchenId: k, item });
      },
      // FIX: stockAdd is now a proper alias for addFreezerItem
      stockAdd: (item) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "ITEM_ADD", kitchenId: k, item });
      },
      adjustFreezerItem: (itemId, value, mode = "delta") => {
        const k = kid(); if (!k) return;
        dispatch({ type: "ITEM_ADJUST", kitchenId: k, itemId, value, mode });
      },
      removeFreezerItem: (itemId) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "ITEM_REMOVE", kitchenId: k, itemId });
      },
      setFreezerParLevel: (itemId, parLevel) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "ITEM_SET_PAR", kitchenId: k, itemId, parLevel });
      },
      moveStock: (itemId, qty, to, reason) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "STOCK_MOVE", kitchenId: k, itemId, qty, to, reason });
      },
      shopAdd: (name, quantity, unit, category, notes) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "SHOP_ADD", kitchenId: k, name, quantity, unit, category, notes });
      },
      shopToggle: (itemId) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "SHOP_TOGGLE", kitchenId: k, itemId });
      },
      shopRemove: (itemId) => {
        const k = kid(); if (!k) return;
        dispatch({ type: "SHOP_REMOVE", kitchenId: k, itemId });
      },
      shopClearChecked: () => {
        const k = kid(); if (!k) return;
        dispatch({ type: "SHOP_CLEAR_CHECKED", kitchenId: k });
      },
    };
  }, [state]);

  return <Ctx.Provider value={store}>{children}</Ctx.Provider>;
}

export function useKitchen() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useKitchen must be used within KitchenProvider");
  return ctx;
}
