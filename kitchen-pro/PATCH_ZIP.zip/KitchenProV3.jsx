import { useState, useEffect, useReducer, useContext, createContext,
         useMemo, useRef, useCallback } from "react";

/* ═══════════════════════════════════════════════════════════════════════════
   KITCHEN PRO — Aged Paper × Deep Luxury
   Palette + animation system from kitchen-v3.jsx
   All CRUD features: Inventory, MEP, Orders, Members, Settings, AI
   ═══════════════════════════════════════════════════════════════════════════ */

// ─── PALETTE ─────────────────────────────────────────────────────────────────
const P = {
  bg: "#F2EDE4", bgWarm: "#EDE6D8", bgCool: "#F7F4EF",
  white: "#FFFFFF", whiteGlass: "rgba(255,255,255,0.65)",
  ink: "#151210", inkSoft: "#3D3530", inkMuted: "#7A7168", inkFaint: "#B0A899", inkGhost: "#D5CFC6",
  red: "#8B1E2F", redDeep: "#6A1525", redLight: "#A63245",
  redGlow: "rgba(139,30,47,0.12)", redSoft: "rgba(139,30,47,0.06)",
  navy: "#182040", navyDeep: "#0F1530", navyLight: "#243060", navyGlow: "rgba(24,32,64,0.10)",
  gold: "#C19A3E", goldBright: "#D9B44A", goldDim: "rgba(193,154,62,0.35)",
  goldFaint: "rgba(193,154,62,0.08)", goldLine: "rgba(193,154,62,0.18)",
  success: "#3D7A4A", successGlow: "rgba(61,122,74,0.15)",
  div: "rgba(21,18,16,0.07)", divStrong: "rgba(21,18,16,0.13)",
};

// ─── GLOBAL CSS (injected once) ───────────────────────────────────────────────
const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500&family=JetBrains+Mono:wght@300;400;500;600&display=swap');
  :root { --serif: 'Playfair Display', Georgia, serif; --mono: 'JetBrains Mono', monospace; }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { height: 100%; }
  body { background: ${P.bg}; font-family: var(--serif); color: ${P.ink}; -webkit-font-smoothing: antialiased; }
  .mono { font-family: var(--mono); }

  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.25} }
  @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.2} }
  @keyframes ringPulse { 0%{transform:scale(1);opacity:0.6} 100%{transform:scale(1.25);opacity:0} }
  @keyframes cardIn { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
  @keyframes heroIn { from{opacity:0;transform:translateY(-20px)} to{opacity:1;transform:translateY(0)} }
  @keyframes fadeIn { from{opacity:0} to{opacity:1} }
  @keyframes slideUp { from{opacity:0;transform:translateY(30px)} to{opacity:1;transform:translateY(0)} }
  @keyframes borderGold { 0%{border-color:rgba(193,154,62,0.1)} 50%{border-color:rgba(193,154,62,0.35)} 100%{border-color:rgba(193,154,62,0.1)} }
  @keyframes toastIn { from{opacity:0;transform:translateX(30px)} to{opacity:1;transform:none} }

  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: ${P.goldDim}; border-radius: 2px; }

  .btn-action:hover { transform: translateY(-1px); filter: brightness(1.08); }
  .btn-action:active { transform: translateY(0); filter: brightness(0.95); }

  .tab-pill {
    padding: 8px 22px; border: none; border-radius: 100px;
    font-family: var(--mono); font-size: 9px; letter-spacing: 0.12em;
    cursor: pointer; transition: all 0.35s cubic-bezier(0.4,0,0.2,1);
    text-transform: uppercase; position: relative; overflow: hidden;
  }
  .tab-pill.active {
    background: linear-gradient(135deg, ${P.navy}, ${P.navyDeep});
    color: ${P.white}; box-shadow: 0 4px 16px rgba(24,32,64,0.25);
  }
  .tab-pill.inactive { background: transparent; color: ${P.inkFaint}; border: 1px solid ${P.div}; }
  .tab-pill.inactive:hover { color: ${P.inkSoft}; border-color: ${P.divStrong}; }

  .loc-chip {
    padding: 5px 14px; border-radius: 100px; font-family: var(--mono); font-size: 9px;
    font-weight: 500; letter-spacing: 0.12em; text-transform: uppercase;
    cursor: pointer; border: 1px solid ${P.div}; background: transparent;
    color: ${P.inkFaint}; transition: all 0.25s;
  }
  .loc-chip:hover { color: ${P.inkSoft}; border-color: ${P.divStrong}; }
  .loc-chip.active { background: ${P.navy}; color: ${P.white}; border-color: ${P.navy}; box-shadow: 0 2px 10px rgba(24,32,64,0.25); }

  .lux-input {
    width: 100%; padding: 10px 14px; border-radius: 8px;
    border: 1px solid ${P.div}; background: ${P.white}; color: ${P.ink};
    font-family: var(--mono); font-size: 11px; letter-spacing: 0.02em;
    outline: none; transition: border-color 0.2s, box-shadow 0.2s;
  }
  .lux-input:focus { border-color: ${P.gold}; box-shadow: 0 0 0 3px ${P.goldFaint}; }
  .lux-input::placeholder { color: ${P.inkGhost}; }

  .lux-btn {
    display: inline-flex; align-items: center; justify-content: center; gap: 6px;
    padding: 9px 20px; border-radius: 8px; border: none; cursor: pointer;
    font-family: var(--mono); font-size: 9px; letter-spacing: 0.12em; font-weight: 500;
    text-transform: uppercase; transition: all 0.2s;
  }
  .lux-btn:active { transform: translateY(1px); }
  .lux-btn:disabled { opacity: 0.4; cursor: not-allowed; transform: none !important; }
  .lux-btn-primary { background: linear-gradient(135deg, ${P.navy}, ${P.navyDeep}); color: ${P.white}; box-shadow: 0 3px 12px rgba(24,32,64,0.25); }
  .lux-btn-primary:hover:not(:disabled) { filter: brightness(1.08); }
  .lux-btn-gold { background: linear-gradient(135deg, ${P.gold}, ${P.goldBright}); color: ${P.ink}; box-shadow: 0 3px 12px ${P.goldDim}; }
  .lux-btn-gold:hover:not(:disabled) { filter: brightness(1.06); }
  .lux-btn-ghost { background: ${P.white}; color: ${P.inkSoft}; border: 1px solid ${P.div}; }
  .lux-btn-ghost:hover:not(:disabled) { background: ${P.bgCool}; border-color: ${P.divStrong}; }
  .lux-btn-danger { background: linear-gradient(135deg, ${P.red}, ${P.redDeep}); color: ${P.white}; box-shadow: 0 3px 12px ${P.redGlow}; }
  .lux-btn-danger:hover:not(:disabled) { filter: brightness(1.08); }

  .card-lux {
    background: ${P.white}; border-radius: 14px; overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.04), 0 0 0 1px rgba(0,0,0,0.03);
    transition: box-shadow 0.3s, transform 0.25s;
  }
  .card-lux:hover { box-shadow: 0 6px 24px rgba(0,0,0,0.07), 0 0 0 1px rgba(0,0,0,0.03); }

  .toast-stack { position: fixed; top: 16px; right: 16px; z-index: 9999; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
  .toast-item {
    background: ${P.white}; border: 1px solid ${P.div}; border-radius: 10px;
    padding: 10px 16px; font-family: var(--mono); font-size: 10px; letter-spacing: 0.04em;
    box-shadow: 0 4px 20px rgba(0,0,0,0.10); animation: toastIn 0.2s ease;
    border-left: 3px solid ${P.gold};
  }
  .toast-item.success { border-left-color: ${P.success}; }
  .toast-item.error { border-left-color: ${P.red}; }

  .row-lux {
    display: flex; align-items: center; justify-content: space-between; gap: 12px;
    padding: 12px 16px; border-radius: 10px; border: 1px solid ${P.div}; background: ${P.white};
    transition: background 0.15s;
  }
  .row-lux:hover { background: ${P.bgCool}; }

  .ai-panel {
    position: fixed; bottom: 72px; right: 0; left: 0; z-index: 200;
    max-width: 480px; margin: 0 auto;
    background: ${P.white}; border: 1px solid ${P.div};
    border-radius: 14px 14px 0 0;
    box-shadow: 0 -8px 32px rgba(0,0,0,0.10);
    display: flex; flex-direction: column; max-height: 52vh; overflow: hidden;
  }
  @media (min-width: 640px) {
    .ai-panel { right: 20px; left: auto; border-radius: 14px; bottom: 80px; }
  }

  .bottom-nav {
    position: fixed; bottom: 0; left: 0; right: 0; z-index: 100;
    background: rgba(242,237,228,0.92); border-top: 1px solid ${P.div};
    backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
    display: flex; justify-content: space-around;
  }
  .nav-item {
    display: flex; flex-direction: column; align-items: center; gap: 2px;
    padding: 10px 4px 8px; font-family: var(--mono); font-size: 7px;
    font-weight: 500; letter-spacing: 0.12em; text-transform: uppercase;
    color: ${P.inkFaint}; text-decoration: none; flex: 1;
    border: none; background: none; cursor: pointer; transition: color 0.15s;
  }
  .nav-item:hover, .nav-item.active { color: ${P.red}; }
  .nav-icon { font-size: 1.1rem; line-height: 1.4; }

  .ai-fab {
    position: fixed; bottom: 82px; right: 20px; z-index: 150;
    width: 50px; height: 50px; border-radius: 50%;
    background: linear-gradient(135deg, ${P.red}, ${P.redDeep});
    color: ${P.white}; border: none; cursor: pointer; font-size: 1.3rem;
    box-shadow: 0 4px 20px ${P.redGlow};
    display: flex; align-items: center; justify-content: center;
    transition: transform 0.2s, box-shadow 0.2s;
  }
  .ai-fab:hover { transform: scale(1.08); }

  @media (min-width: 768px) {
    .ai-fab { bottom: 90px; }
  }

  .section-title {
    font-family: var(--mono); font-size: 8px; letter-spacing: 0.2em;
    text-transform: uppercase; color: ${P.inkFaint);
  }

  .badge-lux {
    display: inline-flex; align-items: center; padding: 3px 10px; border-radius: 4px;
    font-family: var(--mono); font-size: 8px; font-weight: 500; letter-spacing: 0.12em;
    text-transform: uppercase;
  }
  .badge-red { background: ${P.redSoft}; color: ${P.red}; border: 1px solid ${P.redGlow}; }
  .badge-gold { background: ${P.goldFaint}; color: ${P.gold}; border: 1px solid ${P.goldLine}; }
  .badge-navy { background: ${P.navyGlow}; color: ${P.navy}; border: 1px solid rgba(24,32,64,0.15); }
  .badge-green { background: ${P.successGlow}; color: ${P.success}; border: 1px solid rgba(61,122,74,0.2); }
  .badge-ghost { background: ${P.bgWarm}; color: ${P.inkMuted}; border: 1px solid ${P.div}; }

  .item-card {
    background: ${P.white}; border-radius: 12px; overflow: hidden;
    box-shadow: 0 2px 10px rgba(0,0,0,0.04), 0 0 0 1px rgba(0,0,0,0.03);
    transition: box-shadow 0.25s, transform 0.2s;
  }
  .item-card:hover { box-shadow: 0 6px 24px rgba(0,0,0,0.07); transform: translateY(-1px); }
`;

// ─── INJECT CSS ───────────────────────────────────────────────────────────────
if (!document.getElementById("kp-global-css")) {
  const s = document.createElement("style");
  s.id = "kp-global-css";
  s.textContent = GLOBAL_CSS;
  document.head.appendChild(s);
}

// ─── TOAST CONTEXT ─────────────────────────────────────────────────────────────
const ToastCtx = createContext(null);
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const show = useCallback((msg, type = "info") => {
    const id = Math.random().toString(36).slice(2);
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3000);
  }, []);
  return (
    <ToastCtx.Provider value={show}>
      {children}
      <div className="toast-stack">
        {toasts.map(t => (
          <div key={t.id} className={`toast-item ${t.type}`}>{t.msg}</div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
const useToast = () => useContext(ToastCtx);

// ─── STORE ────────────────────────────────────────────────────────────────────
const STORAGE_KEY = "kitchen-pro/v3";
const LOCS = ["freezer", "fridge", "dry", "counter"];
const nowIso = () => new Date().toISOString();
const today = () => new Date().toISOString().slice(0, 10);
const genId = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

function safeLoad() {
  try { const r = localStorage.getItem(STORAGE_KEY); return r ? JSON.parse(r) : null; }
  catch { return null; }
}
function ensureK(k) {
  return {
    id: k?.id ?? genId(), name: k?.name ?? "Kitchen", ownerName: k?.ownerName ?? "Admin",
    members: Array.isArray(k?.members) ? k.members : [],
    freezer: Array.isArray(k?.freezer) ? k.freezer : [],
    fridge: Array.isArray(k?.fridge) ? k.fridge : [],
    dry: Array.isArray(k?.dry) ? k.dry : [],
    counter: Array.isArray(k?.counter) ? k.counter : [],
    shopping: Array.isArray(k?.shopping) ? k.shopping : [],
    movements: Array.isArray(k?.movements) ? k.movements : [],
    parByCategory: (k?.parByCategory && typeof k.parByCategory === "object") ? k.parByCategory : {},
    createdAt: k?.createdAt ?? nowIso(), updatedAt: k?.updatedAt ?? nowIso(),
  };
}
function normalizeState(s) {
  const kitchens = Array.isArray(s?.kitchens) ? s.kitchens.map(ensureK) : [];
  return {
    kitchens,
    currentKitchenId: s?.currentKitchenId ?? kitchens[0]?.id ?? null,
    currentMemberId: s?.currentMemberId ?? null,
  };
}
const SEED = { kitchens: [], currentKitchenId: null, currentMemberId: null };

function findItem(k, id) {
  for (const loc of LOCS) {
    const idx = k[loc].findIndex(x => x.id === id);
    if (idx >= 0) return { loc, idx, item: k[loc][idx] };
  }
  return null;
}
function upK(state, kid, fn) {
  return { ...state, kitchens: state.kitchens.map(k => k.id !== kid ? k : { ...fn(k), updatedAt: nowIso() }) };
}

function reducer(state, action) {
  const k0 = () => state.currentKitchenId ?? state.kitchens[0]?.id ?? "";
  switch (action.type) {
    case "KITCHEN_CREATE": {
      const owner = { id: genId(), name: (action.ownerName || "Admin").trim(), role: "admin", joinedAt: nowIso() };
      const k = { id: genId(), name: action.name.trim() || "Kitchen", ownerName: owner.name, members: [owner], freezer: [], fridge: [], dry: [], counter: [], shopping: [], movements: [], parByCategory: {}, createdAt: nowIso(), updatedAt: nowIso() };
      return { ...state, kitchens: [...state.kitchens, k], currentKitchenId: k.id, currentMemberId: owner.id };
    }
    case "KITCHEN_SELECT": return { ...state, currentKitchenId: action.kitchenId };
    case "CURRENT_MEMBER_SET": return { ...state, currentMemberId: action.memberId };
    case "MEMBER_ADD": return upK(state, action.kitchenId, k => {
      const name = action.name.trim(); if (!name) return k;
      return { ...k, members: [...k.members, { id: genId(), name, role: action.role ?? "commis", joinedAt: nowIso() }] };
    });
    case "MEMBER_ROLE_UPDATE": return upK(state, action.kitchenId, k => ({
      ...k, members: k.members.map(m => m.id === action.memberId ? { ...m, role: action.role } : m),
    }));
    case "MEMBER_REMOVE": return upK(state, action.kitchenId, k => ({
      ...k, members: k.members.filter(m => m.id !== action.memberId),
    }));
    case "PAR_SET": return upK(state, action.kitchenId, k => ({
      ...k, parByCategory: { ...k.parByCategory, [action.key]: action.par },
    }));
    case "ITEM_ADD": return upK(state, k0(), k => {
      const it = action.item; const loc = it.location ?? "fridge";
      const item = { id: it.id ?? genId(), name: String(it.name ?? "").trim(), quantity: Number(it.quantity ?? 0), unit: it.unit ?? "pz", location: loc, insertedAt: it.insertedAt ?? nowIso(), insertedDate: it.insertedDate ?? today(), expiresAt: it.expiresAt, lot: it.lot, notes: it.notes, category: it.category, parLevel: it.parLevel };
      if (!item.name || !Number.isFinite(item.quantity) || item.quantity <= 0) return k;
      return { ...k, [loc]: [...k[loc], item] };
    });
    case "ITEM_ADJUST": return upK(state, k0(), k => {
      const f = findItem(k, action.itemId); if (!f) return k;
      const { loc, idx, item } = f;
      const nq = action.mode === "set" ? action.value : item.quantity + action.value;
      const arr = [...k[loc]];
      if (nq <= 0) arr.splice(idx, 1); else arr[idx] = { ...item, quantity: nq };
      return { ...k, [loc]: arr };
    });
    case "ITEM_REMOVE": return upK(state, k0(), k => {
      const next = { ...k };
      for (const loc of LOCS) next[loc] = next[loc].filter(x => x.id !== action.itemId);
      return next;
    });
    case "ITEM_SET_PAR": return upK(state, k0(), k => {
      const f = findItem(k, action.itemId); if (!f) return k;
      const { loc, idx, item } = f; const arr = [...k[loc]]; arr[idx] = { ...item, parLevel: action.parLevel };
      return { ...k, [loc]: arr };
    });
    case "SHOP_ADD": return upK(state, k0(), k => {
      const name = action.name.trim(); if (!name) return k;
      return { ...k, shopping: [{ id: genId(), name, quantity: Math.max(1, action.quantity), unit: action.unit, category: action.category, notes: action.notes, checked: false, createdAt: nowIso() }, ...k.shopping] };
    });
    case "SHOP_TOGGLE": return upK(state, k0(), k => ({ ...k, shopping: k.shopping.map(x => x.id === action.itemId ? { ...x, checked: !x.checked } : x) }));
    case "SHOP_REMOVE": return upK(state, k0(), k => ({ ...k, shopping: k.shopping.filter(x => x.id !== action.itemId) }));
    case "SHOP_CLEAR": return upK(state, k0(), k => ({ ...k, shopping: k.shopping.filter(x => !x.checked) }));
    default: return state;
  }
}

const KCtx = createContext(null);
function KitchenProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, SEED, () => {
    const l = safeLoad(); return l ? normalizeState(l) : SEED;
  });
  useEffect(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {} }, [state]);

  const store = useMemo(() => {
    const kid = () => state.currentKitchenId ?? state.kitchens[0]?.id ?? "";
    const getCurrentRole = () => {
      const k = state.kitchens.find(x => x.id === state.currentKitchenId) ?? state.kitchens[0];
      if (!k) return "admin";
      const m = k.members.find(m => m.id === state.currentMemberId);
      return m?.role ?? "admin";
    };
    return {
      state, getCurrentRole,
      createKitchen: (name, ownerName) => dispatch({ type: "KITCHEN_CREATE", name, ownerName }),
      selectKitchen: id => dispatch({ type: "KITCHEN_SELECT", kitchenId: id }),
      addMember: (kid2, name, role) => dispatch({ type: "MEMBER_ADD", kitchenId: kid2, name, role }),
      updateMemberRole: (kid2, memberId, role) => dispatch({ type: "MEMBER_ROLE_UPDATE", kitchenId: kid2, memberId, role }),
      removeMember: (kid2, memberId) => dispatch({ type: "MEMBER_REMOVE", kitchenId: kid2, memberId }),
      setCurrentMember: memberId => dispatch({ type: "CURRENT_MEMBER_SET", memberId }),
      setParCategory: (key, par) => { const k = kid(); if (k) dispatch({ type: "PAR_SET", kitchenId: k, key, par }); },
      stockAdd: item => dispatch({ type: "ITEM_ADD", item }),
      adjustItem: (itemId, value, mode = "delta") => dispatch({ type: "ITEM_ADJUST", itemId, value, mode }),
      removeItem: itemId => dispatch({ type: "ITEM_REMOVE", itemId }),
      setParLevel: (itemId, parLevel) => dispatch({ type: "ITEM_SET_PAR", itemId, parLevel }),
      shopAdd: (name, quantity, unit, category, notes) => dispatch({ type: "SHOP_ADD", name, quantity, unit, category, notes }),
      shopToggle: itemId => dispatch({ type: "SHOP_TOGGLE", itemId }),
      shopRemove: itemId => dispatch({ type: "SHOP_REMOVE", itemId }),
      shopClear: () => dispatch({ type: "SHOP_CLEAR" }),
    };
  }, [state]);

  return <KCtx.Provider value={store}>{children}</KCtx.Provider>;
}
const useKitchen = () => { const c = useContext(KCtx); if (!c) throw new Error("Need KitchenProvider"); return c; };

// ─── useSpeech ────────────────────────────────────────────────────────────────
function useSpeech() {
  const recRef = useRef(null);
  const [status, setStatus] = useState("idle");
  const [transcript, setTranscript] = useState("");
  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setStatus("unsupported"); return; }
    const rec = new SR(); rec.lang = "it-IT"; rec.interimResults = false; rec.continuous = false;
    rec.onstart = () => setStatus("listening");
    rec.onend = () => setStatus("idle");
    rec.onresult = e => { try { setTranscript(e.results[0][0].transcript); } catch {} };
    rec.onerror = () => setStatus("idle");
    recRef.current = rec;
    return () => { try { rec.abort(); } catch {} };
  }, []);
  const start = useCallback(() => { if (recRef.current && status !== "listening") { setTranscript(""); recRef.current.start(); } }, [status]);
  const stop = useCallback(() => { recRef.current?.stop(); }, []);
  return { transcript, status, start, stop, setTranscript };
}

// ─── UTILITY ──────────────────────────────────────────────────────────────────
const fmt = s => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
function hoursUntil(iso) {
  if (!iso) return null;
  const t = Date.parse(iso); if (isNaN(t)) return null;
  return (t - Date.now()) / 3_600_000;
}
function expiryBadge(iso) {
  const h = hoursUntil(iso);
  if (h === null) return null;
  if (h <= 0) return { label: "SCADUTO", cls: "badge-red" };
  if (h <= 24) return { label: "≤24h", cls: "badge-red" };
  if (h <= 72) return { label: "≤72h", cls: "badge-gold" };
  return { label: "OK", cls: "badge-green" };
}
function stepFor(u) {
  if (u === "pz") return [1, 5];
  if (u === "g" || u === "ml") return [100, 500];
  return [1, 2];
}

// ─── VISUAL PRIMITIVES from v3 ────────────────────────────────────────────────
function LiveClock() {
  const [t, setT] = useState(new Date());
  useEffect(() => { const i = setInterval(() => setT(new Date()), 1000); return () => clearInterval(i); }, []);
  const h = t.getHours().toString().padStart(2, "0");
  const m = t.getMinutes().toString().padStart(2, "0");
  const s = t.getSeconds().toString().padStart(2, "0");
  return (
    <div style={{ display: "flex", alignItems: "baseline", gap: 2 }}>
      <span className="mono" style={{ fontSize: 26, fontWeight: 400, color: P.ink, letterSpacing: "0.04em" }}>{h}</span>
      <span className="mono" style={{ fontSize: 26, color: P.gold, animation: "blink 1s step-end infinite" }}>:</span>
      <span className="mono" style={{ fontSize: 26, fontWeight: 400, color: P.ink, letterSpacing: "0.04em" }}>{m}</span>
      <span className="mono" style={{ fontSize: 12, color: P.inkFaint, marginLeft: 3 }}>{s}</span>
    </div>
  );
}

function KitchenPulse() {
  const canvasRef = useRef(null);
  const frameRef = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width = 200; const h = canvas.height = 40;
    let t = 0;
    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      ctx.beginPath(); ctx.strokeStyle = P.goldDim; ctx.lineWidth = 1;
      for (let x = 0; x < w; x++) {
        const y = h / 2 + Math.sin((x + t) * 0.04) * 7 + Math.sin((x + t) * 0.08) * 3 + Math.sin((x + t * 1.5) * 0.02) * 5;
        x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.beginPath(); ctx.strokeStyle = P.gold; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.65;
      for (let x = 0; x < w; x++) {
        const y = h / 2 + Math.sin((x + t) * 0.04) * 7 + Math.sin((x + t) * 0.08) * 3 + Math.sin((x + t * 1.5) * 0.02) * 5;
        x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke(); ctx.globalAlpha = 1;
      t += 1.2; frameRef.current = requestAnimationFrame(draw);
    };
    draw(); return () => cancelAnimationFrame(frameRef.current);
  }, []);
  return <canvas ref={canvasRef} style={{ display: "block", opacity: 0.55 }} />;
}

function ArcGauge({ value, size = 48, stroke = 3, color = P.gold }) {
  const r = (size - stroke * 2) / 2;
  const circ = Math.PI * r;
  const off = circ - (value / 100) * circ;
  return (
    <svg width={size} height={size / 2 + stroke} viewBox={`0 0 ${size} ${size / 2 + stroke}`}>
      <path d={`M ${stroke} ${size / 2} A ${r} ${r} 0 0 1 ${size - stroke} ${size / 2}`} fill="none" stroke={P.div} strokeWidth={stroke} strokeLinecap="round" />
      <path d={`M ${stroke} ${size / 2} A ${r} ${r} 0 0 1 ${size - stroke} ${size / 2}`} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={off} style={{ transition: "stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)" }} />
    </svg>
  );
}

// ─── BACKGROUND LAYERS ────────────────────────────────────────────────────────
function BgLayers() {
  return (
    <>
      <div style={{ position: "fixed", inset: 0, zIndex: 0, background: `radial-gradient(ellipse at 15% 0%, rgba(237,230,216,0.7) 0%, transparent 50%), radial-gradient(ellipse at 85% 100%, rgba(230,222,210,0.5) 0%, transparent 45%), ${P.bg}` }} />
      <div style={{ position: "fixed", inset: "-50%", width: "200%", height: "200%", zIndex: 0, opacity: 0.25, pointerEvents: "none", backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='5' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.07'/%3E%3C/svg%3E")` }} />
      <div style={{ position: "fixed", top: "5%", right: "15%", width: 350, height: 350, borderRadius: "50%", background: "radial-gradient(circle, rgba(193,154,62,0.03) 0%, transparent 70%)", zIndex: 0, pointerEvents: "none" }} />
    </>
  );
}

// ─── TOP BAR (from v3 hero header) ────────────────────────────────────────────
function TopBar({ serviceTime }) {
  const { state } = useKitchen();
  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const inv = kitchen ? LOCS.flatMap(l => kitchen[l]) : [];
  const fireCount = inv.filter(x => { const h = hoursUntil(x.expiresAt); return h !== null && h <= 24 && h > 0; }).length;

  return (
    <header style={{
      padding: "20px 24px 16px",
      animation: "heroIn 0.7s cubic-bezier(0.4,0,0.2,1) both",
      display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center",
      borderBottom: `1px solid ${P.div}`,
      background: "rgba(242,237,228,0.88)", backdropFilter: "blur(20px)",
      position: "sticky", top: 0, zIndex: 40,
    }}>
      {/* LEFT: brand */}
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ width: 44, height: 44, borderRadius: "50%", background: `linear-gradient(135deg, ${P.navy}, ${P.navyDeep})`, border: `2px solid ${P.gold}`, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 4px 16px rgba(24,32,64,0.3), 0 0 0 4px ${P.goldFaint}` }}>
          <span className="mono" style={{ fontSize: 8, color: P.goldBright, fontWeight: 600 }}>★★★</span>
        </div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "var(--serif)" }}>
            {kitchen?.name ?? "La Maison"}
          </div>
          <div className="mono" style={{ fontSize: 7, letterSpacing: "0.28em", color: P.inkFaint, marginTop: 1 }}>KITCHEN PRO</div>
        </div>
      </div>

      {/* CENTER: clock + pulse */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
        <LiveClock />
        <KitchenPulse />
        <div className="mono" style={{ fontSize: 7, letterSpacing: "0.2em", color: P.inkFaint }}>
          SERVIZIO · {fmt(serviceTime)}
        </div>
      </div>

      {/* RIGHT: indicators */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "5px 12px", borderRadius: 7, background: P.bgCool, border: `1px solid ${P.div}` }}>
          <div style={{ width: 6, height: 6, borderRadius: "50%", background: P.success, animation: "pulse 2.5s ease-in-out infinite", boxShadow: "0 0 8px rgba(61,122,74,0.4)" }} />
          <span className="mono" style={{ fontSize: 8, letterSpacing: "0.08em", color: P.inkMuted }}>
            {kitchen?.members.length ?? 0} BRIGATA
          </span>
        </div>
        <div style={{ width: 1, height: 28, background: `linear-gradient(180deg, transparent, ${P.goldLine}, transparent)` }} />
        {fireCount > 0 && (
          <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 14px", borderRadius: 8, background: `linear-gradient(135deg, ${P.red}, ${P.redDeep})`, boxShadow: `0 4px 16px rgba(139,30,47,0.3)` }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: P.white, animation: "pulse 1s ease-in-out infinite" }} />
            <span className="mono" style={{ fontSize: 9, color: P.white, fontWeight: 600 }}>{fireCount}</span>
            <span className="mono" style={{ fontSize: 8, color: "rgba(255,255,255,0.7)" }}>URGENTI</span>
          </div>
        )}
      </div>
    </header>
  );
}

// ─── BOTTOM NAV ───────────────────────────────────────────────────────────────
const NAV_ITEMS = [
  { path: "/", icon: "◆", label: "Home" },
  { path: "/inventory", icon: "▤", label: "Giacenze" },
  { path: "/mep", icon: "◻", label: "MEP" },
  { path: "/orders", icon: "◷", label: "Spesa" },
  { path: "/members", icon: "★", label: "Brigata" },
  { path: "/settings", icon: "⊞", label: "Config" },
];
function BottomNav({ route }) {
  return (
    <div className="bottom-nav">
      {NAV_ITEMS.map(n => (
        <a key={n.path} href={`#${n.path}`} className={`nav-item ${route === n.path ? "active" : ""}`}>
          <span className="nav-icon">{n.icon}</span>
          {n.label}
        </a>
      ))}
    </div>
  );
}

// ─── AI ASSISTANT ─────────────────────────────────────────────────────────────
function parseLocalIntent(text, store) {
  const t = text.toLowerCase().trim();
  const addM = t.match(/(?:aggiungi|carica)\s+(\d+(?:[.,]\d+)?)\s*(pz|kg|g|ml|l)?\s+(?:di\s+)?(.+?)(?:\s+(?:al|nel|in|a)\s+(frigo|freezer|dispensa|bancone))?$/i);
  if (addM) {
    const qty = parseFloat(addM[1].replace(",", "."));
    const unit = addM[2] ?? "pz";
    const name = addM[3].trim();
    const locMap = { frigo: "fridge", freezer: "freezer", dispensa: "dry", bancone: "counter" };
    const location = locMap[addM[4]] ?? "fridge";
    store.stockAdd({ name, quantity: qty, unit, location, insertedAt: nowIso(), insertedDate: today(), lot: `AI-${today()}` });
    return `✅ Aggiunto: ${qty} ${unit} di ${name} → ${location}`;
  }
  const remM = t.match(/rimuovi\s+(?:il\s+|la\s+|lo\s+)?(.+)/i);
  if (remM) {
    const name = remM[1].trim();
    const k = store.state.kitchens.find(x => x.id === store.state.currentKitchenId);
    if (k) {
      for (const loc of LOCS) {
        const item = k[loc].find(x => x.name.toLowerCase().includes(name));
        if (item) { store.removeItem(item.id); return `🗑️ Rimosso: ${item.name} (${loc})`; }
      }
    }
    return `❌ "${name}" non trovato.`;
  }
  if (t.includes("scadenz") || t.includes("urgenti")) {
    const k = store.state.kitchens.find(x => x.id === store.state.currentKitchenId);
    if (!k) return "Nessuna kitchen.";
    const inv = LOCS.flatMap(l => k[l]);
    const urg = inv.filter(x => { if (!x.expiresAt) return false; return hoursUntil(x.expiresAt) <= 72; });
    if (!urg.length) return "✅ Nessun prodotto in scadenza entro 72h.";
    return "⚠️ In scadenza:\n" + urg.map(x => `• ${x.name} (${x.expiresAt?.slice(0, 10)})`).join("\n");
  }
  if (t.includes("low") || t.includes("stock basso")) {
    const k = store.state.kitchens.find(x => x.id === store.state.currentKitchenId);
    if (!k) return "Nessuna kitchen.";
    const low = LOCS.flatMap(l => k[l]).filter(x => x.unit === "pz" && x.parLevel != null && x.quantity < x.parLevel);
    if (!low.length) return "✅ Tutto ok — nessun prodotto sotto par.";
    return `🔴 Low (${low.length}):\n` + low.map(x => `• ${x.name}: ${x.quantity}/${x.parLevel}`).join("\n");
  }
  return null;
}

function AIPanel({ onClose }) {
  const store = useKitchen();
  const { transcript, status, start, stop, setTranscript } = useSpeech();
  const [msgs, setMsgs] = useState([{ role: "ai", text: "Ciao Chef! Dimmi cosa vuoi fare:\n«Aggiungi 3 pz di piccione al frigo» · «Scadenze urgenti» · «Stock basso?»" }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);
  useEffect(() => { if (transcript) { setInput(transcript); setTranscript(""); } }, [transcript]);

  async function send(text) {
    const msg = text.trim(); if (!msg) return;
    setMsgs(p => [...p, { role: "user", text: msg }]); setInput(""); setLoading(true);
    const local = parseLocalIntent(msg, store);
    if (local) { setMsgs(p => [...p, { role: "ai", text: local }]); setLoading(false); return; }
    const k = store.state.kitchens.find(x => x.id === store.state.currentKitchenId);
    const inv = k ? LOCS.flatMap(l => k[l].map(i => `${i.name} ${i.quantity}${i.unit}(${l})`)).slice(0, 40).join(", ") : "vuoto";
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 400, system: `Sei l'assistente AI di una cucina stellata Michelin. Rispondi in italiano, conciso. Inventario: ${inv}.`, messages: [{ role: "user", content: msg }] }),
      });
      const data = await res.json();
      setMsgs(p => [...p, { role: "ai", text: data.content?.[0]?.text ?? "Nessuna risposta." }]);
    } catch { setMsgs(p => [...p, { role: "ai", text: "⚠️ Errore connessione." }]); }
    setLoading(false);
  }

  return (
    <div className="ai-panel">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", borderBottom: `1px solid ${P.div}` }}>
        <div className="mono" style={{ fontSize: 9, letterSpacing: "0.15em", color: P.red, fontWeight: 600 }}>🤖 AI KITCHEN ASSISTANT</div>
        <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: P.inkFaint, fontSize: "1rem", padding: "2px 6px" }}>✕</button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: 14, display: "flex", flexDirection: "column", gap: 8 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ padding: "8px 12px", borderRadius: 10, fontSize: 11, maxWidth: "85%", lineHeight: 1.5, whiteSpace: "pre-line", alignSelf: m.role === "user" ? "flex-end" : "flex-start", fontFamily: "var(--mono)", background: m.role === "user" ? `linear-gradient(135deg, ${P.navy}, ${P.navyDeep})` : P.bgCool, color: m.role === "user" ? P.white : P.inkSoft }}>
            {m.text}
          </div>
        ))}
        {loading && <div style={{ padding: "8px 12px", borderRadius: 10, fontSize: 11, fontFamily: "var(--mono)", background: P.bgCool, color: P.inkFaint, alignSelf: "flex-start", animation: "pulse 1s infinite" }}>…</div>}
        <div ref={endRef} />
      </div>
      {status === "listening" && <div className="mono" style={{ fontSize: 9, color: P.red, padding: "0 14px 4px", animation: "pulse 1s infinite" }}>🎙️ IN ASCOLTO…</div>}
      <div style={{ display: "flex", gap: 8, padding: "10px 12px", borderTop: `1px solid ${P.div}` }}>
        <input className="lux-input" style={{ flex: 1 }} placeholder="Scrivi o parla…" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter") send(input); }} />
        <button className={`lux-btn ${status === "listening" ? "lux-btn-danger" : "lux-btn-ghost"}`} onClick={status === "listening" ? stop : start} style={{ padding: "8px 12px", flexShrink: 0 }}>🎙️</button>
        <button className="lux-btn lux-btn-primary" onClick={() => send(input)} disabled={!input.trim() || loading} style={{ flexShrink: 0 }}>➤</button>
      </div>
    </div>
  );
}

// ─── STOCK INTAKE ─────────────────────────────────────────────────────────────
const UNITS = ["pz", "g", "kg", "ml", "l", "vac", "busta", "brik", "latta", "box", "vasch"];
const CATALOG_CATS = ["proteine", "pesce", "verdure", "erbe", "latticini", "cereali", "grassi", "fermentati", "spezie", "fondi", "cantina", "consumabili"];

function StockIntake({ defaultLocation = "fridge", lockLocation = false }) {
  const { stockAdd, state } = useKitchen();
  const toast = useToast();
  const { transcript, status, start, stop, setTranscript } = useSpeech();
  const [name, setName] = useState(""); const [qty, setQty] = useState(1); const [unit, setUnit] = useState("pz");
  const [location, setLocation] = useState(defaultLocation);
  const [expiresAt, setExpiresAt] = useState(""); const [lot, setLot] = useState(""); const [notes, setNotes] = useState("");
  const [cat, setCat] = useState("proteine");

  useEffect(() => { if (defaultLocation) setLocation(defaultLocation); }, [defaultLocation]);
  useEffect(() => {
    if (!transcript) return;
    const m = transcript.match(/(?:aggiungi|carica)\s+(\d+)\s*(pz|kg|g|ml|l)?\s+(?:di\s+)?(.+)/i);
    if (m) { setQty(parseInt(m[1])); if (m[2]) setUnit(m[2]); setName(m[3].trim()); }
    setTranscript("");
  }, [transcript]);

  const canSave = name.trim().length > 0 && qty > 0 && lot.trim().length > 0;

  function submit() {
    if (!canSave) return;
    const k = state.kitchens.find(k => k.id === state.currentKitchenId);
    const par = unit === "pz" ? (k?.parByCategory?.[cat] ?? k?.parByCategory?.default ?? 5) : undefined;
    stockAdd({ name: name.trim(), quantity: Number(qty), unit, location, insertedDate: today(), expiresAt: expiresAt || undefined, lot: lot.trim(), notes: notes.trim() || undefined, category: cat, parLevel: par });
    setName(""); setQty(1); setUnit("pz"); setExpiresAt(""); setLot(""); setNotes("");
    toast("✅ Carico salvato: " + name, "success");
  }

  const Section = ({ label }) => (
    <div className="mono" style={{ fontSize: 8, letterSpacing: "0.15em", color: P.inkFaint, textTransform: "uppercase", marginBottom: 6 }}>{label}</div>
  );

  return (
    <div className="card-lux" style={{ padding: 20 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <div>
          <div className="mono" style={{ fontSize: 8, letterSpacing: "0.2em", color: P.inkFaint, textTransform: "uppercase" }}>Carico Giacenza</div>
          <div style={{ fontFamily: "var(--serif)", fontSize: 18, fontWeight: 500, color: P.ink, marginTop: 2, fontStyle: "italic" }}>Registra prodotto</div>
        </div>
        <button className={`lux-btn ${status === "listening" ? "lux-btn-danger" : "lux-btn-ghost"}`} style={{ padding: "8px 14px" }} onClick={status === "listening" ? stop : start}>
          🎙️ {status === "listening" ? "Stop" : "Voce"}
        </button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <div style={{ gridColumn: "1/-1" }}>
          <Section label="Categoria" />
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {CATALOG_CATS.slice(0, 6).map(c => (
              <button key={c} className={`loc-chip ${cat === c ? "active" : ""}`} onClick={() => setCat(c)} style={{ padding: "4px 10px", fontSize: 8 }}>{c}</button>
            ))}
          </div>
        </div>
        <div style={{ gridColumn: "1/-1" }}>
          <Section label="Nome prodotto" />
          <input className="lux-input" value={name} onChange={e => setName(e.target.value)} placeholder="es. Piccione, Rombo, Wagyu…" />
        </div>
        <div>
          <Section label="Quantità" />
          <input className="lux-input" type="number" min={0} value={qty} onChange={e => setQty(Number(e.target.value))} />
        </div>
        <div>
          <Section label="Unità" />
          <select className="lux-input" value={unit} onChange={e => setUnit(e.target.value)}>
            {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
          </select>
        </div>
        {!lockLocation && (
          <div>
            <Section label="Location" />
            <select className="lux-input" value={location} onChange={e => setLocation(e.target.value)}>
              {LOCS.map(l => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
        )}
        <div>
          <Section label="Scadenza" />
          <input className="lux-input" type="date" value={expiresAt} onChange={e => setExpiresAt(e.target.value)} />
        </div>
        <div>
          <Section label="Lotto *" />
          <input className="lux-input" value={lot} onChange={e => setLot(e.target.value)} placeholder="LOT-2026-…" />
        </div>
        <div style={{ gridColumn: "1/-1" }}>
          <Section label="Note / fornitore" />
          <input className="lux-input" value={notes} onChange={e => setNotes(e.target.value)} placeholder="DDT, fornitore, qualità…" />
        </div>
      </div>
      <div style={{ marginTop: 16, display: "flex", gap: 8 }}>
        <button className="lux-btn lux-btn-primary" style={{ flex: 1, opacity: canSave ? 1 : 0.4, pointerEvents: canSave ? "auto" : "none" }} onClick={submit}>
          Salva carico
        </button>
      </div>
      {!canSave && (
        <div className="mono" style={{ fontSize: 9, color: P.inkFaint, marginTop: 8 }}>
          ⚠ Nome + Quantità + Lotto obbligatori
        </div>
      )}
    </div>
  );
}

// ─── PAGES ────────────────────────────────────────────────────────────────────

function Dashboard() {
  const { state } = useKitchen();
  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);

  const stats = useMemo(() => {
    if (!kitchen) return null;
    const inv = LOCS.flatMap(l => kitchen[l]);
    const expired = inv.filter(x => { const h = hoursUntil(x.expiresAt); return h !== null && h <= 0; });
    const urg24 = inv.filter(x => { const h = hoursUntil(x.expiresAt); return h !== null && h > 0 && h <= 24; });
    const urg72 = inv.filter(x => { const h = hoursUntil(x.expiresAt); return h !== null && h > 24 && h <= 72; });
    const low = inv.filter(x => x.unit === "pz" && x.parLevel != null && x.quantity < x.parLevel);
    const toBuy = (kitchen.shopping || []).filter(x => !x.checked);
    return { total: inv.length, expired: expired.length, urg24: urg24.length, urg72: urg72.length, low: low.length, toBuy: toBuy.length, members: kitchen.members.length };
  }, [kitchen]);

  if (!kitchen || !stats) return (
    <div className="card-lux" style={{ padding: 32, textAlign: "center" }}>
      <div style={{ fontFamily: "var(--serif)", fontSize: 28, fontStyle: "italic", color: P.ink }}>Benvenuto in Kitchen Pro</div>
      <div className="mono" style={{ fontSize: 10, color: P.inkFaint, marginTop: 8, letterSpacing: "0.12em" }}>CREA UNA KITCHEN PER INIZIARE</div>
      <a href="#/settings" className="lux-btn lux-btn-primary" style={{ marginTop: 20, display: "inline-flex" }}>Crea Kitchen</a>
    </div>
  );

  const kpiData = [
    { label: "INVENTARIO", val: stats.total, sub: "tutti i reparti", color: P.ink, accent: false },
    { label: "SCADUTI", val: stats.expired, sub: "azione immediata", color: P.red, accent: stats.expired > 0 },
    { label: "URGENTI ≤72H", val: stats.urg24 + stats.urg72, sub: `${stats.urg24} oggi · ${stats.urg72} entro 72h`, color: stats.urg24 > 0 ? P.red : P.gold, accent: stats.urg24 > 0 },
    { label: "LOW STOCK", val: stats.low, sub: "sotto par (pz)", color: P.red, accent: stats.low > 0 },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20, animation: "slideUp 0.5s ease both" }}>
      {/* KPI ribbon */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 0, borderRadius: 14, overflow: "hidden", border: `1px solid ${P.div}`, background: P.white }}>
        {kpiData.map((k, i) => (
          <div key={k.label} style={{ padding: "20px 22px", borderRight: i < 3 ? `1px solid ${P.div}` : "none", background: i % 2 === 0 ? "rgba(255,255,255,0.5)" : "rgba(245,241,235,0.4)" }}>
            <div className="mono" style={{ fontSize: 7, letterSpacing: "0.18em", color: P.inkFaint, marginBottom: 6 }}>{k.label}</div>
            <div style={{ fontFamily: "var(--serif)", fontSize: 36, fontWeight: 400, color: k.color, lineHeight: 1 }}>{k.val}</div>
            <div className="mono" style={{ fontSize: 8, color: P.inkFaint, marginTop: 4 }}>{k.sub}</div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div className="card-lux" style={{ padding: 20 }}>
          <div className="mono" style={{ fontSize: 8, letterSpacing: "0.15em", color: P.inkFaint, marginBottom: 12 }}>AZIONI RAPIDE</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[["▤ Giacenze", "/inventory"], ["◻ MEP", "/mep"], ["◷ Spesa", "/orders"], ["★ Brigata", "/members"]].map(([label, path]) => (
              <a key={path} href={`#${path}`} className="lux-btn lux-btn-ghost" style={{ justifyContent: "flex-start", padding: "10px 14px" }}>{label}</a>
            ))}
          </div>
        </div>
        <div className="card-lux" style={{ padding: 20 }}>
          <div className="mono" style={{ fontSize: 8, letterSpacing: "0.15em", color: P.inkFaint, marginBottom: 12 }}>LISTA SPESA</div>
          <div style={{ fontFamily: "var(--serif)", fontSize: 48, fontWeight: 400, color: P.ink, lineHeight: 1 }}>{stats.toBuy}</div>
          <div className="mono" style={{ fontSize: 9, color: P.inkFaint, marginTop: 4 }}>articoli da acquistare</div>
          <a href="#/orders" className="lux-btn lux-btn-gold" style={{ marginTop: 16, display: "inline-flex" }}>Apri lista</a>
        </div>
      </div>

      {/* Urgent items preview */}
      {(stats.urg24 > 0 || stats.expired > 0) && (() => {
        const urgItems = LOCS.flatMap(l => kitchen[l]).filter(x => { const h = hoursUntil(x.expiresAt); return h !== null && h <= 24; }).slice(0, 4);
        return (
          <div className="card-lux" style={{ padding: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: P.red, animation: "pulse 1.5s infinite" }} />
              <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.red }}>ATTENZIONE IMMEDIATA</div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {urgItems.map(x => {
                const badge = expiryBadge(x.expiresAt);
                return (
                  <div key={x.id} className="row-lux">
                    <div>
                      <div style={{ fontFamily: "var(--serif)", fontSize: 15, fontStyle: "italic" }}>{x.name}</div>
                      <div className="mono" style={{ fontSize: 8, color: P.inkFaint }}>{x.location} · {x.quantity} {x.unit}</div>
                    </div>
                    {badge && <span className={`badge-lux ${badge.cls}`}>{badge.label}</span>}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })()}
    </div>
  );
}

function Inventory() {
  const { state, adjustItem, removeItem, setParLevel, getCurrentRole } = useKitchen();
  const toast = useToast();
  const canEdit = ["admin", "chef", "sous-chef", "capo-partita"].includes(getCurrentRole());
  const [loc, setLoc] = useState("fridge");
  const [q, setQ] = useState("");

  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const items = useMemo(() => {
    if (!kitchen) return [];
    const term = q.trim().toLowerCase();
    return kitchen[loc]
      .filter(x => !term || x.name.toLowerCase().includes(term) || (x.lot ?? "").toLowerCase().includes(term))
      .slice().sort((a, b) => (a.expiresAt ?? "").localeCompare(b.expiresAt ?? ""));
  }, [kitchen, loc, q]);

  const locIcons = { freezer: "🧊", fridge: "❄️", dry: "📦", counter: "🍽️" };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20, animation: "slideUp 0.5s ease both" }}>
      <StockIntake defaultLocation={loc} lockLocation />
      <div className="card-lux" style={{ padding: 20 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 16 }}>
          <div>
            <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.inkFaint }}>GIACENZE</div>
            <div style={{ fontFamily: "var(--serif)", fontSize: 20, fontStyle: "italic", marginTop: 2 }}>Inventario {locIcons[loc]}</div>
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {LOCS.map(l => (
              <button key={l} className={`loc-chip ${loc === l ? "active" : ""}`} onClick={() => setLoc(l)}>
                {locIcons[l]} {l}
              </button>
            ))}
          </div>
        </div>
        <input className="lux-input" value={q} onChange={e => setQ(e.target.value)} placeholder="🔍 Cerca nome o lotto…" style={{ marginBottom: 16 }} />

        {!kitchen && <div className="mono" style={{ fontSize: 10, color: P.inkFaint }}>Seleziona una kitchen.</div>}
        {kitchen && items.length === 0 && (
          <div style={{ textAlign: "center", padding: "32px 0" }}>
            <div style={{ fontFamily: "var(--serif)", fontSize: 20, fontStyle: "italic", color: P.inkFaint }}>Nessun prodotto in {loc}</div>
          </div>
        )}
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {items.map((x, i) => {
            const badge = expiryBadge(x.expiresAt);
            const isLow = x.unit === "pz" && x.parLevel != null && x.quantity < x.parLevel;
            const [a, b] = stepFor(x.unit);
            const pct = Math.min(100, x.expiresAt ? Math.max(0, 100 - ((hoursUntil(x.expiresAt) || 999) / 168) * 100) : 0);
            return (
              <div key={x.id} className="item-card" style={{ animation: `cardIn 0.4s ease ${i * 0.04}s both` }}>
                {/* time bar */}
                {x.expiresAt && (
                  <div style={{ height: 3, background: P.bgWarm }}>
                    <div style={{ height: "100%", width: `${pct}%`, background: pct > 85 ? `linear-gradient(90deg,${P.red},${P.redLight})` : pct > 60 ? `linear-gradient(90deg,${P.gold},${P.goldBright})` : `linear-gradient(90deg,${P.success},#2E6438)`, transition: "width 1s" }} />
                  </div>
                )}
                <div style={{ padding: "14px 18px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 4 }}>
                        <span style={{ fontFamily: "var(--serif)", fontSize: 16, fontStyle: "italic" }}>{x.name}</span>
                        {isLow && <span className="badge-lux badge-red">LOW</span>}
                        {badge && <span className={`badge-lux ${badge.cls}`}>{badge.label}</span>}
                      </div>
                      <div className="mono" style={{ fontSize: 9, color: P.inkFaint }}>
                        {x.location} · lotto {x.lot ?? "—"} · carico {x.insertedDate ?? x.insertedAt?.slice(0, 10)}
                        {x.expiresAt ? " · exp " + x.expiresAt.slice(0, 10) : ""}
                      </div>
                    </div>
                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                      <div className="mono" style={{ fontSize: 22, fontWeight: 300, color: P.ink }}>{x.quantity}</div>
                      <div className="mono" style={{ fontSize: 9, color: P.inkFaint }}>{x.unit}{x.unit === "pz" ? ` / MIN ${x.parLevel ?? "—"}` : ""}</div>
                    </div>
                  </div>
                  <div style={{ marginTop: 12, display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {[[-a, `-${a}`], [+a, `+${a}`], [-b, `-${b}`], [+b, `+${b}`]].map(([d, lbl]) => (
                      <button key={lbl} className="lux-btn lux-btn-ghost" style={{ padding: "5px 12px", fontSize: 9 }} disabled={!canEdit} onClick={() => adjustItem(x.id, d)}>{lbl}</button>
                    ))}
                    {x.unit === "pz" && (
                      <button className="lux-btn lux-btn-gold" style={{ padding: "5px 12px", fontSize: 9 }} disabled={!canEdit} onClick={() => {
                        const v = prompt("MIN (pz). 'off' per disabilitare", String(x.parLevel ?? 5));
                        if (v === null) return;
                        if (v.trim().toLowerCase() === "off") return setParLevel(x.id, undefined);
                        const n = Math.floor(Number(v || "5"));
                        if (Number.isFinite(n) && n > 0) setParLevel(x.id, n);
                      }}>MIN</button>
                    )}
                    <button className="lux-btn lux-btn-ghost" style={{ marginLeft: "auto", padding: "5px 12px", fontSize: 9 }} disabled={!canEdit} onClick={() => { removeItem(x.id); toast(`🗑️ ${x.name}`, "info"); }}>Rimuovi</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function MEP() {
  const { state, getCurrentRole, stockAdd } = useKitchen();
  const toast = useToast();
  const canEdit = ["admin", "chef", "sous-chef", "capo-partita"].includes(getCurrentRole());
  const kitchenId = state.currentKitchenId;
  const MEP_KEY = kitchenId ? `kp-mep/${kitchenId}` : null;
  const { transcript, status, start, stop, setTranscript } = useSpeech();

  const [tasks, setTasks] = useState(() => {
    if (!MEP_KEY) return [];
    try { return JSON.parse(localStorage.getItem(MEP_KEY) || "[]"); } catch { return []; }
  });
  const [title, setTitle] = useState("");
  const [modal, setModal] = useState(null);

  useEffect(() => { if (MEP_KEY) localStorage.setItem(MEP_KEY, JSON.stringify(tasks)); }, [tasks, MEP_KEY]);
  useEffect(() => { if (transcript) { setTitle(transcript); setTranscript(""); } }, [transcript]);

  function addTask() {
    if (!canEdit || !title.trim()) return;
    setTasks(p => [{ id: genId(), title: title.trim(), done: false, createdAt: nowIso() }, ...p]);
    setTitle(""); toast("✅ Preparazione aggiunta", "success");
  }

  function toggle(id) {
    setTasks(p => p.map(t => t.id === id ? { ...t, done: !t.done, doneAt: !t.done ? nowIso() : undefined } : t));
  }

  function confirmComplete(task, qty, location) {
    stockAdd({ name: task.title, quantity: Math.max(1, qty), unit: "pz", location, insertedAt: nowIso(), lot: `MEP-${today()}` });
    toggle(task.id); setModal(null); toast(`✅ ${task.title} → ${location}`, "success");
  }

  if (!kitchenId) return <div className="card-lux" style={{ padding: 32, textAlign: "center", fontFamily: "var(--serif)", fontStyle: "italic", color: P.inkFaint }}>Seleziona una Kitchen.</div>;

  const todo = tasks.filter(t => !t.done);
  const done = tasks.filter(t => t.done);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20, animation: "slideUp 0.5s ease both" }}>
      <div className="card-lux" style={{ padding: 20 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div>
            <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.inkFaint }}>MEP GIORNALIERO</div>
            <div style={{ fontFamily: "var(--serif)", fontSize: 22, fontStyle: "italic", marginTop: 2 }}>Preparazioni</div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <span className="badge-lux badge-navy">{todo.length} da fare</span>
            <span className="badge-lux badge-green">{done.length} ok</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <input className="lux-input" style={{ flex: 1 }} placeholder="Nuova preparazione…" value={title} onChange={e => setTitle(e.target.value)} disabled={!canEdit} onKeyDown={e => { if (e.key === "Enter") addTask(); }} />
          <button className={`lux-btn ${status === "listening" ? "lux-btn-danger" : "lux-btn-ghost"}`} onClick={status === "listening" ? stop : start} style={{ padding: "8px 12px" }}>🎙️</button>
          <button className="lux-btn lux-btn-primary" onClick={addTask} disabled={!canEdit}>Aggiungi</button>
        </div>
      </div>

      {todo.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.inkFaint, paddingLeft: 4 }}>DA COMPLETARE</div>
          {todo.map((task, i) => (
            <div key={task.id} className="card-lux" style={{ padding: "14px 18px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, animation: `cardIn 0.35s ease ${i * 0.05}s both` }}>
              <div style={{ fontFamily: "var(--serif)", fontSize: 16, fontStyle: "italic" }}>{task.title}</div>
              <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                {canEdit && <button className="lux-btn lux-btn-gold" style={{ fontSize: 9 }} onClick={() => setModal({ task, qty: 1, location: "fridge" })}>Completa + Carica</button>}
                <button className="lux-btn lux-btn-ghost" style={{ fontSize: 9 }} onClick={() => toggle(task.id)}>✓</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {done.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.inkFaint, paddingLeft: 4 }}>COMPLETATE</div>
          {done.map(task => (
            <div key={task.id} className="card-lux" style={{ padding: "12px 18px", display: "flex", alignItems: "center", justifyContent: "space-between", opacity: 0.55 }}>
              <div style={{ fontFamily: "var(--serif)", fontSize: 15, fontStyle: "italic", textDecoration: "line-through" }}>{task.title}</div>
              <button className="lux-btn lux-btn-ghost" style={{ fontSize: 9 }} onClick={() => toggle(task.id)}>Ripristina</button>
            </div>
          ))}
        </div>
      )}

      {modal && (
        <div style={{ position: "fixed", inset: 0, zIndex: 300, background: "rgba(21,18,16,0.5)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16, backdropFilter: "blur(4px)" }}>
          <div className="card-lux" style={{ width: "100%", maxWidth: 380, padding: 24 }}>
            <div style={{ fontFamily: "var(--serif)", fontSize: 18, fontStyle: "italic", marginBottom: 4 }}>Completa preparazione</div>
            <div className="mono" style={{ fontSize: 9, color: P.inkFaint, marginBottom: 20 }}>{modal.task.title}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <div><div className="mono" style={{ fontSize: 8, color: P.inkFaint, marginBottom: 5 }}>QUANTITÀ (pz)</div><input className="lux-input" type="number" min={1} value={modal.qty} onChange={e => setModal(m => ({ ...m, qty: Number(e.target.value) }))} /></div>
              <div><div className="mono" style={{ fontSize: 8, color: P.inkFaint, marginBottom: 5 }}>DESTINAZIONE</div>
                <select className="lux-input" value={modal.location} onChange={e => setModal(m => ({ ...m, location: e.target.value }))}>
                  <option value="fridge">Frigo</option><option value="freezer">Freezer</option><option value="dry">Dispensa</option>
                </select>
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
                <button className="lux-btn lux-btn-ghost" style={{ flex: 1 }} onClick={() => setModal(null)}>Annulla</button>
                <button className="lux-btn lux-btn-primary" style={{ flex: 1 }} onClick={() => confirmComplete(modal.task, modal.qty, modal.location)}>Conferma</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Orders() {
  const { state, getCurrentRole, shopAdd, shopToggle, shopRemove, shopClear } = useKitchen();
  const toast = useToast();
  const canEdit = ["admin", "chef", "sous-chef", "capo-partita"].includes(getCurrentRole());
  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const { transcript, status, start, stop, setTranscript } = useSpeech();

  const CATS = [{ key: "economato", label: "Economato" }, { key: "giornaliero", label: "Giornaliera" }, { key: "settimanale", label: "Settimanale" }];
  const [cat, setCat] = useState("economato");
  const [name, setName] = useState(""); const [qty, setQty] = useState(1); const [unit, setUnit] = useState("pz"); const [notes, setNotes] = useState("");

  useEffect(() => { if (transcript) { setName(transcript); setTranscript(""); } }, [transcript]);

  const items = useMemo(() => {
    const list = (kitchen?.shopping || []).filter(x => x.category === cat);
    return list.slice().sort((a, b) => a.checked !== b.checked ? (a.checked ? 1 : -1) : a.name.localeCompare(b.name));
  }, [kitchen, cat]);

  function add() {
    if (!kitchen || !canEdit || !name.trim()) return;
    shopAdd(name.trim(), Math.max(1, qty), unit, cat, notes.trim() || undefined);
    setName(""); setQty(1); setUnit("pz"); setNotes(""); toast("✅ Aggiunto alla lista", "success");
  }

  if (!kitchen) return <div className="card-lux" style={{ padding: 32, textAlign: "center", fontFamily: "var(--serif)", fontStyle: "italic", color: P.inkFaint }}>Seleziona una Kitchen.</div>;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20, animation: "slideUp 0.5s ease both" }}>
      <div className="card-lux" style={{ padding: 20 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16, flexWrap: "wrap", gap: 12 }}>
          <div>
            <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.inkFaint }}>LISTA SPESA</div>
            <div style={{ fontFamily: "var(--serif)", fontSize: 22, fontStyle: "italic", marginTop: 2 }}>Ordini & Acquisti</div>
          </div>
          <button className="lux-btn lux-btn-ghost" style={{ fontSize: 9 }} onClick={() => { shopClear(); toast("🧹 Spuntati rimossi", "info"); }} disabled={!canEdit}>Pulisci spuntati</button>
        </div>

        <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
          {CATS.map(c => <button key={c.key} className={`loc-chip ${cat === c.key ? "active" : ""}`} onClick={() => setCat(c.key)}>{c.label}</button>)}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr auto auto 1fr auto auto", gap: 8, alignItems: "end" }}>
          <div style={{ gridColumn: "1/3" }}>
            <div className="mono" style={{ fontSize: 8, color: P.inkFaint, marginBottom: 4 }}>ARTICOLO</div>
            <div style={{ display: "flex", gap: 6 }}>
              <input className="lux-input" style={{ flex: 1 }} placeholder="Nome…" value={name} onChange={e => setName(e.target.value)} disabled={!canEdit} onKeyDown={e => { if (e.key === "Enter") add(); }} />
              <button className={`lux-btn ${status === "listening" ? "lux-btn-danger" : "lux-btn-ghost"}`} style={{ padding: "8px 12px" }} onClick={status === "listening" ? stop : start}>🎙️</button>
            </div>
          </div>
          <div><div className="mono" style={{ fontSize: 8, color: P.inkFaint, marginBottom: 4 }}>QTÀ</div><input className="lux-input" type="number" min={1} value={qty} onChange={e => setQty(Number(e.target.value))} disabled={!canEdit} style={{ width: 70 }} /></div>
          <div><div className="mono" style={{ fontSize: 8, color: P.inkFaint, marginBottom: 4 }}>UNITÀ</div><select className="lux-input" value={unit} onChange={e => setUnit(e.target.value)} disabled={!canEdit} style={{ width: 80 }}>{UNITS.map(u => <option key={u} value={u}>{u}</option>)}</select></div>
          <div style={{ gridColumn: "5/7" }}>
            <div className="mono" style={{ fontSize: 8, color: P.inkFaint, marginBottom: 4 }}>NOTE</div>
            <div style={{ display: "flex", gap: 6 }}>
              <input className="lux-input" style={{ flex: 1 }} placeholder="Note opzionali…" value={notes} onChange={e => setNotes(e.target.value)} disabled={!canEdit} />
              <button className="lux-btn lux-btn-primary" onClick={add} disabled={!canEdit}>+</button>
            </div>
          </div>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {items.length === 0 && (
          <div className="card-lux" style={{ padding: 28, textAlign: "center" }}>
            <div style={{ fontFamily: "var(--serif)", fontSize: 18, fontStyle: "italic", color: P.inkFaint }}>Nessun elemento in {cat}</div>
          </div>
        )}
        {items.map((x, i) => (
          <div key={x.id} className="card-lux" style={{ padding: "14px 18px", display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, opacity: x.checked ? 0.55 : 1, animation: `cardIn 0.35s ease ${i * 0.04}s both` }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 12, minWidth: 0, flex: 1 }}>
              <input type="checkbox" checked={x.checked} onChange={() => shopToggle(x.id)} disabled={!canEdit} style={{ marginTop: 3, accentColor: P.navy, width: 14, height: 14, flexShrink: 0, cursor: "pointer" }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: "var(--serif)", fontSize: 16, fontStyle: "italic", textDecoration: x.checked ? "line-through" : "none" }}>{x.name}</div>
                <div className="mono" style={{ fontSize: 9, color: P.inkFaint, marginTop: 2 }}>{x.quantity} {x.unit}{x.notes ? ` · ${x.notes}` : ""}</div>
              </div>
            </div>
            {canEdit && <button className="lux-btn lux-btn-ghost" style={{ padding: "5px 10px", fontSize: 10, flexShrink: 0 }} onClick={() => { shopRemove(x.id); toast(`🗑️ ${x.name}`, "info"); }}>✕</button>}
          </div>
        ))}
      </div>
    </div>
  );
}

const ROLES = ["admin", "chef", "sous-chef", "capo-partita", "commis", "stagista", "staff"];

function Members() {
  const { state, getCurrentRole, addMember, updateMemberRole, removeMember } = useKitchen();
  const toast = useToast();
  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const isAdmin = getCurrentRole() === "admin";
  const [newName, setNewName] = useState(""); const [newRole, setNewRole] = useState("commis");

  if (!kitchen) return <div className="card-lux" style={{ padding: 32, textAlign: "center", fontFamily: "var(--serif)", fontStyle: "italic", color: P.inkFaint }}>Seleziona una Kitchen.</div>;

  const roleBadgeCls = r => r === "admin" ? "badge-gold" : ["chef", "sous-chef", "capo-partita"].includes(r) ? "badge-red" : "badge-ghost";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20, animation: "slideUp 0.5s ease both" }}>
      <div className="card-lux" style={{ padding: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
          <div>
            <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.inkFaint }}>BRIGATA</div>
            <div style={{ fontFamily: "var(--serif)", fontSize: 22, fontStyle: "italic", marginTop: 2 }}>{kitchen.name}</div>
            <div className="mono" style={{ fontSize: 9, color: P.inkFaint, marginTop: 4 }}>{kitchen.members.length} membri</div>
          </div>
          <span className={`badge-lux ${roleBadgeCls(getCurrentRole())}`}>{getCurrentRole()}</span>
        </div>
        {isAdmin && (
          <div style={{ marginTop: 16, display: "flex", gap: 8, flexWrap: "wrap" }}>
            <input className="lux-input" style={{ flex: 1 }} placeholder="Nome nuovo membro…" value={newName} onChange={e => setNewName(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && newName.trim()) { addMember(kitchen.id, newName.trim(), newRole); setNewName(""); toast("✅ Membro aggiunto", "success"); } }} />
            <select className="lux-input" value={newRole} onChange={e => setNewRole(e.target.value)} style={{ width: 140 }}>
              {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
            <button className="lux-btn lux-btn-primary" onClick={() => { if (newName.trim()) { addMember(kitchen.id, newName.trim(), newRole); setNewName(""); toast("✅ Membro aggiunto", "success"); } }}>Aggiungi</button>
          </div>
        )}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {kitchen.members.map((m, i) => (
          <div key={m.id} className="card-lux" style={{ padding: "14px 18px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, animation: `cardIn 0.35s ease ${i * 0.05}s both` }}>
            <div>
              <div style={{ fontFamily: "var(--serif)", fontSize: 16, fontStyle: "italic" }}>{m.name}</div>
              <div style={{ marginTop: 4 }}><span className={`badge-lux ${roleBadgeCls(m.role)}`}>{m.role}</span></div>
            </div>
            {isAdmin && (
              <div style={{ display: "flex", gap: 8 }}>
                <select className="lux-input" value={m.role} style={{ width: 130 }} onChange={e => updateMemberRole(kitchen.id, m.id, e.target.value)}>
                  {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
                <button className="lux-btn lux-btn-ghost" style={{ fontSize: 12 }} onClick={() => { if (confirm(`Rimuovere ${m.name}?`)) { removeMember(kitchen.id, m.id); toast(`🗑️ ${m.name} rimosso`, "info"); } }}>✕</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

const PAR_ROWS = [
  { key: "proteine", label: "Proteine animali", ex: "piccione, astice, wagyu", def: 6 },
  { key: "pesce", label: "Pesce & molluschi", ex: "rombo, capesante, ricci", def: 4 },
  { key: "verdure", label: "Verdure & radici", ex: "topinambur, scorzonera", def: 8 },
  { key: "erbe", label: "Erbe & fiori", ex: "acetosella, borragine", def: 12 },
  { key: "latticini", label: "Latticini & uova", ex: "burro Bordier, uova", def: 6 },
  { key: "cereali", label: "Farine & cereali", ex: "farro, semola", def: 3 },
  { key: "grassi", label: "Grassi & oli", ex: "EVO, burro chiarificato", def: 4 },
  { key: "fermentati", label: "Acidi & fermentati", ex: "koji, miso, kombucha", def: 6 },
  { key: "spezie", label: "Spezie & aromi", ex: "pepe lungo, sumac", def: 10 },
  { key: "fondi", label: "Fondi & riduzioni", ex: "fondo bruno, dashi, bisque", def: 4 },
  { key: "cantina", label: "Cantina & beverage", ex: "vini, sake", def: 6 },
  { key: "consumabili", label: "Consumabili", ex: "agar, lecitina", def: 5 },
  { key: "default", label: "Default (fallback)", ex: "—", def: 5 },
];

function Settings() {
  const { state, createKitchen, selectKitchen, setParCategory } = useKitchen();
  const toast = useToast();
  const [name, setName] = useState(""); const [owner, setOwner] = useState("Admin");
  const currentK = state.kitchens.find(k => k.id === state.currentKitchenId);
  const parMap = currentK?.parByCategory ?? {};

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20, animation: "slideUp 0.5s ease both" }}>
      {/* Kitchen management */}
      <div className="card-lux" style={{ padding: 20 }}>
        <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.inkFaint, marginBottom: 4 }}>GESTIONE KITCHEN</div>
        <div style={{ fontFamily: "var(--serif)", fontSize: 22, fontStyle: "italic", marginBottom: 16 }}>Kitchen Management</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr auto auto", gap: 8, marginBottom: 16 }}>
          <input className="lux-input" placeholder="Nome cucina…" value={name} onChange={e => setName(e.target.value)} />
          <input className="lux-input" placeholder="Owner" value={owner} onChange={e => setOwner(e.target.value)} style={{ width: 120 }} />
          <button className="lux-btn lux-btn-primary" onClick={() => { const t = name.trim(); if (!t) return; createKitchen(t, owner.trim() || "Admin"); setName(""); toast("✅ Kitchen creata", "success"); }}>Crea</button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {state.kitchens.length === 0 && <div className="mono" style={{ fontSize: 10, color: P.inkFaint }}>Nessuna kitchen — creane una.</div>}
          {state.kitchens.map(k => (
            <button key={k.id} className="row-lux" style={{ width: "100%", background: k.id === state.currentKitchenId ? P.bgWarm : P.white, border: k.id === state.currentKitchenId ? `1px solid ${P.goldLine}` : `1px solid ${P.div}`, cursor: "pointer" }} onClick={() => selectKitchen(k.id)}>
              <div style={{ minWidth: 0, textAlign: "left" }}>
                <div style={{ fontFamily: "var(--serif)", fontSize: 15, fontStyle: "italic" }}>{k.name}</div>
                <div className="mono" style={{ fontSize: 8, color: P.inkFaint }}>{k.id}</div>
              </div>
              <span className={`badge-lux ${k.id === state.currentKitchenId ? "badge-gold" : "badge-ghost"}`}>{k.id === state.currentKitchenId ? "Attiva" : "Seleziona"}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Par levels */}
      <div className="card-lux" style={{ padding: 20 }}>
        <div className="mono" style={{ fontSize: 8, letterSpacing: "0.18em", color: P.inkFaint, marginBottom: 4 }}>MICHELIN PAR LEVELS</div>
        <div style={{ fontFamily: "var(--serif)", fontSize: 22, fontStyle: "italic", marginBottom: 16 }}>Soglie Minime</div>
        {!currentK ? (
          <div className="mono" style={{ fontSize: 10, color: P.inkFaint }}>Seleziona una kitchen.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {PAR_ROWS.map(r => {
              const cur = Number(parMap[r.key] ?? r.def);
              return (
                <div key={r.key} className="row-lux">
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontFamily: "var(--serif)", fontSize: 14, fontStyle: "italic" }}>{r.label}</div>
                    <div className="mono" style={{ fontSize: 8, color: P.inkFaint }}>{r.ex}</div>
                  </div>
                  <input className="lux-input" type="number" min={0} step={1} defaultValue={cur} style={{ width: 72, textAlign: "center" }}
                    onBlur={e => setParCategory(r.key, Math.max(0, Math.floor(Number(e.target.value || cur))))}
                    onKeyDown={e => { if (e.key === "Enter") e.target.blur(); }} />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ROUTING ──────────────────────────────────────────────────────────────────
function useRoute() {
  const [route, setRoute] = useState(() => window.location.hash.slice(1) || "/");
  useEffect(() => {
    const h = () => setRoute(window.location.hash.slice(1) || "/");
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  return route;
}

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const route = useRoute();
  const [aiOpen, setAiOpen] = useState(false);
  const [serviceTime, setServiceTime] = useState(0);
  useEffect(() => { const i = setInterval(() => setServiceTime(p => p + 1), 1000); return () => clearInterval(i); }, []);

  const pages = { "/": Dashboard, "/inventory": Inventory, "/mep": MEP, "/orders": Orders, "/members": Members, "/settings": Settings };
  const Page = pages[route] ?? Dashboard;

  return (
    <KitchenProvider>
      <ToastProvider>
        <div style={{ minHeight: "100vh", position: "relative" }}>
          <BgLayers />
          <div style={{ position: "relative", zIndex: 2 }}>
            <TopBar serviceTime={serviceTime} />
            <main style={{ maxWidth: 1100, margin: "0 auto", padding: "24px 20px 100px" }}>
              <Page />
            </main>
            <BottomNav route={route} />
            <button className="ai-fab" onClick={() => setAiOpen(p => !p)} title="AI Assistant">
              {aiOpen ? "✕" : "🤖"}
            </button>
            {aiOpen && <AIPanel onClose={() => setAiOpen(false)} />}
          </div>
        </div>
      </ToastProvider>
    </KitchenProvider>
  );
}
