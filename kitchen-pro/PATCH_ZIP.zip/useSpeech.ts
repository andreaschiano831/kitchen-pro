import { useCallback, useEffect, useRef, useState } from "react";

type SpeechStatus = "idle" | "listening" | "unsupported";

export function useSpeech() {
  const recognitionRef = useRef<any>(null);
  const [status, setStatus] = useState<SpeechStatus>("idle");
  const [transcript, setTranscript] = useState("");

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setStatus("unsupported");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "it-IT";
    recognition.interimResults = false;
    recognition.continuous = false;

    recognition.onstart = () => setStatus("listening");
    recognition.onend = () => setStatus("idle");

    // FIX: added try/catch to prevent crash on malformed result
    recognition.onresult = (event: any) => {
      try {
        const text = event.results[0][0].transcript;
        setTranscript(text);
      } catch {
        // ignore parse errors
      }
    };

    // FIX: added onerror handler
    recognition.onerror = () => setStatus("idle");

    recognitionRef.current = recognition;

    // FIX: abort on unmount to prevent memory leak / state update on unmounted
    return () => {
      try { recognitionRef.current?.abort(); } catch {}
    };
  }, []);

  const start = useCallback(() => {
    if (recognitionRef.current && status !== "listening") {
      setTranscript("");
      recognitionRef.current.start();
    }
  }, [status]);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
  }, []);

  return { transcript, status, start, stop, setTranscript };
}
