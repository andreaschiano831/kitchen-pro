import { useMemo, useState } from "react";
import { useKitchen, type Role } from "../store/kitchenStore";

const ROLES: Role[] = [
  "admin", "chef", "sous-chef", "capo-partita", "commis", "stagista", "staff",
];

function roleBadge(role: Role) {
  if (role === "admin")
    return "inline-flex items-center rounded-full border border-[#C6A75E] bg-[#fff7e6] text-[#6b4f12] px-2 py-0.5 text-xs font-semibold";
  if (["chef", "sous-chef", "capo-partita"].includes(role))
    return "inline-flex items-center rounded-full border border-[#8B0000] bg-[#fff1f1] text-[#8B0000] px-2 py-0.5 text-xs font-semibold";
  return "inline-flex items-center rounded-full border border-neutral-200 bg-neutral-100 text-neutral-700 px-2 py-0.5 text-xs font-semibold";
}

export default function Members() {
  const { state, getCurrentRole, addMember, updateMemberRole, removeMember } = useKitchen();
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState<Role>("commis");

  const kitchen = useMemo(
    () => state.kitchens.find((k) => k.id === state.currentKitchenId),
    [state.kitchens, state.currentKitchenId]
  );

  const currentRole = getCurrentRole();
  const isAdmin = currentRole === "admin";

  if (!kitchen) {
    return (
      <div className="card p-6">
        <h2 className="text-xl font-semibold">Members</h2>
        <p className="text-sm text-neutral-600 mt-2">Seleziona una kitchen prima.</p>
      </div>
    );
  }

  function handleAddMember() {
    const trimmed = newName.trim();
    if (!trimmed) return;
    addMember(kitchen!.id, trimmed, newRole);
    setNewName("");
  }

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <h2 className="text-xl font-semibold tracking-tight">Team</h2>
            <p className="text-sm text-neutral-600 truncate">{kitchen.name}</p>
          </div>
          <div className="text-right">
            <div className="text-xs text-neutral-500">Ruolo corrente</div>
            <div className="mt-1">
              <span className={roleBadge(currentRole)}>{currentRole ?? "—"}</span>
            </div>
          </div>
        </div>

        {isAdmin && (
          <div className="mt-4 flex gap-2 flex-wrap">
            <input
              className="input flex-1"
              placeholder="Nome nuovo membro…"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") handleAddMember(); }}
            />
            <select
              className="input w-36"
              value={newRole}
              onChange={(e) => setNewRole(e.target.value as Role)}
            >
              {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
            <button className="btn btn-primary" onClick={handleAddMember}>
              Aggiungi
            </button>
          </div>
        )}

        {!isAdmin && (
          <div className="mt-3 rounded-lg border border-neutral-200 bg-[#fff7e6] p-3 text-sm">
            <span className="font-medium">Nota:</span> solo{" "}
            <span className="font-medium">Admin</span> può modificare ruoli o rimuovere membri.
          </div>
        )}
      </div>

      <div className="space-y-3">
        {kitchen.members.map((m) => (
          <div key={m.id} className="card p-5">
            <div className="flex items-center justify-between gap-4">
              <div className="min-w-0">
                <div className="text-base font-semibold truncate">{m.name}</div>
                <div className="mt-2">
                  <span className={roleBadge(m.role)}>{m.role}</span>
                </div>
              </div>

              {isAdmin ? (
                <div className="flex items-center gap-2">
                  <select
                    value={m.role}
                    // FIX: now passes kitchen.id as first argument (was missing → wrong kitchen updated)
                    onChange={(e) => updateMemberRole(kitchen.id, m.id, e.target.value as Role)}
                    className="rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm"
                  >
                    {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                  <button
                    // FIX: now passes kitchen.id as first argument
                    onClick={() => {
                      if (confirm(`Rimuovere ${m.name}?`)) {
                        removeMember(kitchen.id, m.id);
                      }
                    }}
                    className="rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm hover:bg-neutral-50"
                    title="Rimuovi membro"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <div className="text-xs text-neutral-500">Solo lettura</div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
