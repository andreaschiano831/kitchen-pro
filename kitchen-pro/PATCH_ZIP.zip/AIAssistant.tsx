import { useCallback, useEffect, useRef, useState } from "react";
import { useKitchen } from "../store/kitchenStore";
import { useSpeech } from "../hooks/useSpeech";

type Message = { role: "user" | "ai"; text: string };

const LOCS = ["freezer", "fridge", "dry", "counter"] as const;
const nowIso = () => new Date().toISOString();
const today = () => new Date().toISOString().slice(0, 10);

/**
 * Parses simple Italian voice/text commands locally without calling the API.
 * Returns a feedback string if handled, or null to forward to Claude.
 */
function parseLocalIntent(text: string, store: ReturnType<typeof useKitchen>): string | null {
  const t = text.toLowerCase().trim();

  // "aggiungi 3 pz di lombata al frigo"
  const addMatch = t.match(
    /(?:aggiungi|carica)\s+(\d+(?:[.,]\d+)?)\s*(pz|kg|g|ml|l|vac|busta|kg)?\s+(?:di\s+)?(.+?)(?:\s+(?:al|nel|in|a)\s+(frigo|freezer|dispensa|bancone))?$/i
  );
  if (addMatch) {
    const qty = parseFloat(addMatch[1].replace(",", "."));
    const unit = (addMatch[2] ?? "pz") as any;
    const name = addMatch[3].trim();
    const locMap: Record<string, string> = {
      frigo: "fridge", freezer: "freezer", dispensa: "dry", bancone: "counter",
    };
    const location = (locMap[addMatch[4]] ?? "fridge") as any;
    store.stockAdd({
      name, quantity: qty, unit, location,
      insertedAt: nowIso(), insertedDate: today(),
      lot: `AI-${today()}`,
    });
    return `✅ Aggiunto: ${qty} ${unit} di ${name} → ${location}`;
  }

  // "rimuovi lombata"
  const removeMatch = t.match(/rimuovi\s+(?:il\s+|la\s+|lo\s+|i\s+)?(.+)/i);
  if (removeMatch) {
    const name = removeMatch[1].trim();
    const k = store.state.kitchens.find((x) => x.id === store.state.currentKitchenId);
    if (k) {
      for (const loc of LOCS) {
        const item = k[loc].find((x) => x.name.toLowerCase().includes(name));
        if (item) {
          store.removeFreezerItem(item.id);
          return `🗑️ Rimosso: ${item.name} da ${loc}`;
        }
      }
    }
    return `❌ "${name}" non trovato in nessuna location.`;
  }

  // "mostra scadenze / urgenti"
  if (t.includes("scadenz") || t.includes("urgenti") || t.includes("in scadenza")) {
    const k = store.state.kitchens.find((x) => x.id === store.state.currentKitchenId);
    if (!k) return "Nessuna kitchen attiva.";
    const inv = LOCS.flatMap((l) => k[l]);
    const now = Date.now();
    const urgent = inv.filter((x) => {
      if (!x.expiresAt) return false;
      const h = (Date.parse(x.expiresAt) - now) / 3_600_000;
      return h <= 72;
    });
    if (urgent.length === 0) return "✅ Nessun prodotto in scadenza entro 72 ore.";
    return (
      `⚠️ Prodotti in scadenza:\n` +
      urgent.map((x) => `• ${x.name} (${x.expiresAt?.slice(0, 10)})`).join("\n")
    );
  }

  // "stock basso / low stock"
  if (t.includes("low stock") || t.includes("stock basso") || t.includes("sotto par")) {
    const k = store.state.kitchens.find((x) => x.id === store.state.currentKitchenId);
    if (!k) return "Nessuna kitchen attiva.";
    const inv = LOCS.flatMap((l) => k[l]);
    const low = inv.filter((x) => x.unit === "pz" && x.parLevel != null && x.quantity < x.parLevel);
    if (low.length === 0) return "✅ Nessun prodotto sotto par.";
    return (
      `🔴 Low stock (${low.length}):\n` +
      low.map((x) => `• ${x.name}: ${x.quantity}/${x.parLevel} pz`).join("\n")
    );
  }

  return null; // forward to Claude API
}

type Props = { onClose: () => void };

export default function AIAssistant({ onClose }: Props) {
  const store = useKitchen();
  const { transcript, status, start, stop, setTranscript } = useSpeech();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "ai",
      text: "Ciao Chef! 👨‍🍳 Sono il tuo assistente AI. Puoi dirmi:\n• «Aggiungi 3 pz di lombata al frigo»\n• «Mostra scadenze urgenti»\n• «Stock basso?»\nOppure chiedimi qualsiasi cosa sulla cucina.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (transcript) {
      setInput(transcript);
      setTranscript("");
    }
  }, [transcript]);

  async function send(text: string) {
    const userMsg = text.trim();
    if (!userMsg) return;
    setMessages((p) => [...p, { role: "user", text: userMsg }]);
    setInput("");
    setLoading(true);

    // Try local intent first
    const local = parseLocalIntent(userMsg, store);
    if (local) {
      setMessages((p) => [...p, { role: "ai", text: local }]);
      setLoading(false);
      return;
    }

    // Build inventory context for Claude
    const k = store.state.kitchens.find((x) => x.id === store.state.currentKitchenId);
    const inv = k
      ? LOCS.flatMap((l) => k[l].map((i) => `${i.name} ${i.quantity}${i.unit} (${l})`))
          .slice(0, 50)
          .join(", ")
      : "nessuna";

    const systemPrompt = `Sei l'assistente AI di una cucina stellata Michelin. Rispondi sempre in italiano, in modo conciso e professionale.
Inventario attuale: ${inv}.
Puoi suggerire azioni, analizzare scadenze, aiutare con preparazioni MEP, menu e lista spesa.
Per azioni dirette (aggiungi, rimuovi) l'utente deve confermare vocalmente o per iscritto.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 500,
          system: systemPrompt,
          messages: [{ role: "user", content: userMsg }],
        }),
      });
      const data = await res.json();
      const reply =
        data.content?.find((c: any) => c.type === "text")?.text ?? "Non ho capito, riprova.";
      setMessages((p) => [...p, { role: "ai", text: reply }]);
    } catch {
      setMessages((p) => [...p, { role: "ai", text: "⚠️ Errore connessione. Riprova." }]);
    }
    setLoading(false);
  }

  return (
    <div
      style={{
        position: "fixed", bottom: 80, right: 0, left: 0, zIndex: 55,
        maxWidth: 480, margin: "0 auto",
        background: "var(--panel)", border: "1px solid var(--border)",
        borderRadius: "14px 14px 0 0",
        boxShadow: "0 -8px 32px rgba(0,0,0,.15)",
        display: "flex", flexDirection: "column", maxHeight: "55vh", overflow: "hidden",
      }}
      // Desktop: float on the right
      className="ai-panel-responsive"
    >
      {/* Header */}
      <div
        style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "10px 14px", borderBottom: "1px solid var(--border)",
        }}
      >
        <div style={{ fontSize: ".8rem", fontWeight: 700, letterSpacing: ".06em", textTransform: "uppercase", color: "var(--accent)" }}>
          🤖 AI Kitchen Assistant
        </div>
        <button
          onClick={onClose}
          style={{ background: "none", border: "none", cursor: "pointer", fontSize: "1rem", color: "var(--muted)", padding: "2px 6px" }}
        >
          ✕
        </button>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: 14, display: "flex", flexDirection: "column", gap: 8 }}>
        {messages.map((m, i) => (
          <div
            key={i}
            style={{
              padding: "8px 12px", borderRadius: 10, fontSize: ".8125rem",
              maxWidth: "85%", lineHeight: 1.5, whiteSpace: "pre-line",
              alignSelf: m.role === "user" ? "flex-end" : "flex-start",
              background: m.role === "user" ? "var(--accent)" : "rgba(128,128,128,.1)",
              color: m.role === "user" ? "#fff" : "var(--text)",
            }}
          >
            {m.text}
          </div>
        ))}
        {loading && (
          <div style={{ padding: "8px 12px", borderRadius: 10, fontSize: ".8125rem", background: "rgba(128,128,128,.1)", color: "var(--muted)", alignSelf: "flex-start" }}>
            ⏳ …
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Status */}
      {status === "listening" && (
        <div style={{ fontSize: ".7rem", color: "var(--accent)", padding: "0 14px 4px", animation: "pulse 1s infinite" }}>
          🎙️ In ascolto…
        </div>
      )}

      {/* Input row */}
      <div style={{ display: "flex", gap: 8, padding: "10px 12px", borderTop: "1px solid var(--border)" }}>
        <input
          className="input"
          style={{ flex: 1 }}
          placeholder="Scrivi o usa la voce…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") send(input); }}
        />
        <button
          className={`btn ${status === "listening" ? "btn-primary" : "btn-ghost"} btn-icon`}
          onClick={status === "listening" ? stop : start}
          title="Voce"
          style={{ flexShrink: 0 }}
        >
          🎙️
        </button>
        <button
          className="btn btn-primary"
          onClick={() => send(input)}
          disabled={!input.trim() || loading}
          style={{ flexShrink: 0 }}
        >
          ➤
        </button>
      </div>
    </div>
  );
}
