import { useMemo, useState } from "react";
import { useKitchen } from "../store/kitchenStore";
import type { LedgerRow } from "../store/kitchenStore";
import { exportLedgerCSV, filterLedger } from "../utils/ledger";

type Tab = "linea" | "ledger";

const ACTION_LABELS: Record<LedgerRow["action"], string> = {
  ADD:    "Carico",
  ADJUST: "Rettifica",
  MOVE:   "Spostamento",
  MERGE:  "Unione",
  CONSUME:"Consumo",
};

const ACTION_COLOR: Record<LedgerRow["action"], string> = {
  ADD:    "bg-green-100 text-green-800",
  ADJUST: "bg-yellow-100 text-yellow-800",
  MOVE:   "bg-blue-100 text-blue-800",
  MERGE:  "bg-indigo-100 text-indigo-800",
  CONSUME:"bg-red-100 text-red-800",
};

function fmtDate(iso: string) {
  return iso.slice(0, 10) + " " + iso.slice(11, 16);
}

export default function Line() {
  const { state, getCurrentRole, stockMove } = useKitchen();
  const role = getCurrentRole();
  const canEdit = role === "admin" || role === "chef" || role === "sous-chef" || role === "capo-partita";

  const kitchen = useMemo(
    () => state.kitchens.find((k) => k.id === state.currentKitchenId),
    [state.kitchens, state.currentKitchenId]
  );

  const [tab, setTab] = useState<Tab>("linea");

  // ── Linea tab state ──────────────────────────────────────────────────────────
  const [qtyMap,    setQtyMap]    = useState<Record<string, number>>({});
  const [reasonMap, setReasonMap] = useState<Record<string, string>>({});

  // batches available to pull to the line (freezer + dry)
  const sources = useMemo(() => {
    if (!kitchen) return [];
    return [
      ...kitchen.freezer.filter((x) => x.location === "freezer"),
      ...kitchen.dry.filter((x) => x.location === "dry"),
    ].sort((a, b) => a.name.localeCompare(b.name, "it"));
  }, [kitchen]);

  function stepFor(unit: string) {
    if (unit === "g" || unit === "ml") return 100;
    return 1;
  }

  function handleMove(batchId: string, unit: string) {
    if (!canEdit) return;
    const def = stepFor(unit);
    const qty = qtyMap[batchId] ?? def;
    if (qty <= 0) return;
    stockMove({
      batchId,
      toLocation: "fridge",
      qty,
      reason: reasonMap[batchId]?.trim() || "Linea / MEP",
    });
    // reset row
    setQtyMap((prev) => { const n = { ...prev }; delete n[batchId]; return n; });
    setReasonMap((prev) => { const n = { ...prev }; delete n[batchId]; return n; });
  }

  // ── Ledger tab state ─────────────────────────────────────────────────────────
  const [filterName,    setFilterName]    = useState("");
  const [filterAction,  setFilterAction]  = useState<LedgerRow["action"] | "">("");
  const [filterDateFrom,setFilterDateFrom]= useState("");
  const [filterDateTo,  setFilterDateTo]  = useState("");
  const [filterLot,     setFilterLot]     = useState("");
  const [page,          setPage]          = useState(0);
  const PAGE_SIZE = 30;

  const filteredLedger = useMemo(() => {
    if (!kitchen) return [];
    return filterLedger(kitchen.ledger, {
      action:   filterAction  || undefined,
      name:     filterName    || undefined,
      dateFrom: filterDateFrom || undefined,
      dateTo:   filterDateTo   || undefined,
      lot:      filterLot      || undefined,
    });
  }, [kitchen, filterAction, filterName, filterDateFrom, filterDateTo, filterLot]);

  const ledgerPage = useMemo(
    () => filteredLedger.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE),
    [filteredLedger, page]
  );

  const totalPages = Math.max(1, Math.ceil(filteredLedger.length / PAGE_SIZE));

  if (!kitchen) return <div className="p-muted card p-6">Seleziona una kitchen.</div>;

  return (
    <div className="space-y-4">

      {/* ── header + tabs ── */}
      <div className="card p-4">
        <div className="h2">Linea & Movimenti</div>
        <div className="p-muted text-xs mt-1">
          Sposta stock da freezer/dispensa in frigo per la linea. Ogni movimento registra un ledger immutabile.
        </div>
        <div className="mt-3 flex gap-2">
          <button
            className={tab === "linea"  ? "btn btn-primary text-xs" : "btn btn-ghost text-xs"}
            onClick={() => setTab("linea")}
          >
            🔄 Linea
          </button>
          <button
            className={tab === "ledger" ? "btn btn-primary text-xs" : "btn btn-ghost text-xs"}
            onClick={() => setTab("ledger")}
          >
            📋 Ledger ({kitchen.ledger.length})
          </button>
          {tab === "ledger" && (
            <button
              className="btn btn-ghost text-xs ml-auto"
              onClick={() => exportLedgerCSV(kitchen)}
            >
              ⬇ Export CSV
            </button>
          )}
        </div>
      </div>

      {/* ════════════════════════════ LINEA TAB ════════════════════════════ */}
      {tab === "linea" && (
        <div className="card p-4">
          <div className="text-sm font-semibold mb-3">
            Disponibile (Freezer / Dispensa)
          </div>

          {sources.length === 0 ? (
            <div className="p-muted text-sm">
              Nessun prodotto disponibile in freezer o dispensa.
            </div>
          ) : (
            <div className="space-y-2">
              {sources.map((x) => {
                const def = stepFor(x.unit);
                const val = qtyMap[x.id] ?? def;
                const isOver = val > x.quantity;
                return (
                  <div
                    key={x.id}
                    className="rounded-xl border bg-white px-3 py-3 space-y-2"
                    style={{ borderColor: "var(--line)" }}
                  >
                    {/* product info */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-sm font-semibold truncate">{x.name}</div>
                        <div className="text-xs p-muted">
                          {x.location} • stock <strong>{x.quantity} {x.unit}</strong>
                          {x.lot       ? ` • lotto ${x.lot}` : ""}
                          {x.expiresAt ? ` • scad. ${x.expiresAt}` : ""}
                        </div>
                      </div>
                      {x.expiresAt && x.expiresAt <= new Date().toISOString().slice(0, 10) && (
                        <span className="badge badge-expired flex-shrink-0">SCADUTO</span>
                      )}
                    </div>

                    {/* controls */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <input
                        className={`input w-24 ${isOver ? "border-red-400" : ""}`}
                        type="number"
                        min={0}
                        step={def}
                        value={val}
                        onChange={(e) =>
                          setQtyMap((prev) => ({ ...prev, [x.id]: Number(e.target.value || 0) }))
                        }
                        disabled={!canEdit}
                      />
                      <span className="text-xs p-muted">{x.unit}</span>

                      <input
                        className="input flex-1 min-w-[120px] text-xs"
                        placeholder="Motivo (opz.)"
                        value={reasonMap[x.id] ?? ""}
                        onChange={(e) =>
                          setReasonMap((prev) => ({ ...prev, [x.id]: e.target.value }))
                        }
                        disabled={!canEdit}
                      />

                      <button
                        className="btn btn-gold text-xs"
                        disabled={!canEdit || val <= 0 || isOver}
                        onClick={() => handleMove(x.id, x.unit)}
                      >
                        → Frigo
                      </button>
                    </div>

                    {isOver && (
                      <div className="text-xs text-red-500">
                        Quantità supera lo stock disponibile ({x.quantity} {x.unit}).
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ════════════════════════════ LEDGER TAB ════════════════════════════ */}
      {tab === "ledger" && (
        <div className="space-y-3">

          {/* filters */}
          <div className="card p-4 space-y-3">
            <div className="h2">Filtri</div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              <input
                className="input text-xs"
                placeholder="Prodotto…"
                value={filterName}
                onChange={(e) => { setFilterName(e.target.value); setPage(0); }}
              />
              <input
                className="input text-xs"
                placeholder="Lotto…"
                value={filterLot}
                onChange={(e) => { setFilterLot(e.target.value); setPage(0); }}
              />
              <select
                className="input text-xs"
                value={filterAction}
                onChange={(e) => { setFilterAction(e.target.value as any); setPage(0); }}
              >
                <option value="">Tutte le azioni</option>
                <option value="ADD">Carico</option>
                <option value="ADJUST">Rettifica</option>
                <option value="MOVE">Spostamento</option>
                <option value="MERGE">Unione</option>
              </select>
              <input
                className="input text-xs"
                type="date"
                placeholder="Da data"
                value={filterDateFrom}
                onChange={(e) => { setFilterDateFrom(e.target.value); setPage(0); }}
              />
              <input
                className="input text-xs"
                type="date"
                placeholder="A data"
                value={filterDateTo}
                onChange={(e) => { setFilterDateTo(e.target.value); setPage(0); }}
              />
              <button
                className="btn btn-ghost text-xs"
                onClick={() => {
                  setFilterName(""); setFilterAction(""); setFilterDateFrom("");
                  setFilterDateTo(""); setFilterLot(""); setPage(0);
                }}
              >
                Reset filtri
              </button>
            </div>
            <div className="p-muted text-xs">
              {filteredLedger.length} righe {filteredLedger.length !== kitchen.ledger.length ? `(su ${kitchen.ledger.length} totali)` : ""}
            </div>
          </div>

          {/* rows */}
          {kitchen.ledger.length === 0 ? (
            <div className="card p-6">
              <div className="p-muted text-sm">
                Ledger vuoto. Ogni carico, rettifica o spostamento apparirà qui.
              </div>
            </div>
          ) : (
            <div className="card divide-y" style={{ divideColor: "var(--line)" }}>
              {ledgerPage.length === 0 ? (
                <div className="p-4 p-muted text-sm">Nessun risultato per i filtri applicati.</div>
              ) : (
                ledgerPage.map((r) => (
                  <div key={r.id} className="px-4 py-3 flex items-start justify-between gap-3">
                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${ACTION_COLOR[r.action]}`}>
                          {ACTION_LABELS[r.action]}
                        </span>
                        <span className="text-sm font-semibold truncate">{r.name}</span>
                      </div>
                      <div className="text-xs p-muted">
                        {fmtDate(r.at)} • {r.memberName}
                        {r.lot ? ` • lotto ${r.lot}` : ""}
                        {r.reason ? ` • ${r.reason}` : ""}
                      </div>
                      {(r.fromLocation || r.toLocation) && (
                        <div className="text-xs p-muted">
                          {r.fromLocation ? `${r.fromLocation} →` : "→"} {r.toLocation ?? "—"}
                        </div>
                      )}
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-sm font-semibold">
                        {r.action === "ADJUST" && r.qty > 0 ? "+" : ""}
                        {r.qty} {r.unit}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-3">
              <button
                className="btn btn-ghost text-xs"
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
              >
                ← Prec
              </button>
              <span className="text-xs p-muted">
                {page + 1} / {totalPages}
              </span>
              <button
                className="btn btn-ghost text-xs"
                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1}
              >
                Succ →
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
