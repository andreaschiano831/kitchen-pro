export type Unit =
  | "pz"
  | "g"
  | "kg"
  | "ml"
  | "l"
  | "vac"
  | "busta"
  | "brik"
  | "latta"
  | "box"
  | "vasch";

export type Location = "freezer" | "fridge" | "dry" | "counter";

export type FreezerItem = {
  id: string;
  name: string;
  quantity: number;
  unit: Unit;
  location: Location;
  insertedAt: string;
  insertedDate?: string;
  expiresAt?: string;
  lot?: string;
  notes?: string;
  section?: string;
  category?: string;
  catalogId?: string;
  parLevel?: number | null;
};
