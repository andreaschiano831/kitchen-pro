
/**
 * KITCHEN PRO — Michelin Kitchen Management
 * Refactored & enhanced single-file React component
 *
 * FIXES applied vs original codebase:
 * 1. stockAdd alias properly wired in store (was undefined, crashed StockIntake)
 * 2. Duplicate guard in ITEM_ADD reducer removed
 * 3. Members.removeMember/updateMemberRole now pass kitchenId correctly
 * 4. AppShell/AppLayout consolidated — no more double TopBar render
 * 5. useSpeech error handling + abort on unmount
 * 6. _kitchenId unused var removed from store useMemo
 * 7. CSS container unified (.container → max-w-5xl px-4)
 * 8. Theme switcher (Dark / Light / Luxury) via CSS vars
 * 9. AI assistant panel (voice + text → Claude API)
 * 10. Camera/photo capture stub with OCR parse intent
 */

import { useState, useEffect, useReducer, useContext, createContext,
         useMemo, useRef, useCallback } from "react";
import { v4 as uuid } from "https://cdn.jsdelivr.net/npm/uuid@9/+esm";

// ─── TYPES (inlined) ─────────────────────────────────────────────────────────
// Unit | Location | FreezerItem | Member | ShoppingItem | StockMovement | Kitchen | KitchenState

// ─── THEME ───────────────────────────────────────────────────────────────────
const THEMES = {
  light: {
    "--bg": "#FAFAF8", "--panel": "#FFFFFF", "--text": "#111111",
    "--muted": "#6B7280", "--border": "rgba(17,17,17,.10)",
    "--accent": "#7A0C0C", "--gold": "#C6A75E",
    "--shadow": "0 10px 25px rgba(17,17,17,.06)",
    "--nav-bg": "rgba(250,250,248,.92)", "--topbar-bg": "rgba(250,250,248,.92)",
  },
  dark: {
    "--bg": "#0D0D0D", "--panel": "#181818", "--text": "#F0EDE8",
    "--muted": "#9CA3AF", "--border": "rgba(255,255,255,.10)",
    "--accent": "#E05252", "--gold": "#D4AF6A",
    "--shadow": "0 10px 25px rgba(0,0,0,.35)",
    "--nav-bg": "rgba(13,13,13,.92)", "--topbar-bg": "rgba(13,13,13,.92)",
  },
  luxury: {
    "--bg": "#0A0705", "--panel": "#13100C", "--text": "#F5EDD8",
    "--muted": "#A89070", "--border": "rgba(198,167,94,.18)",
    "--accent": "#8B0000", "--gold": "#C6A75E",
    "--shadow": "0 12px 30px rgba(0,0,0,.5)",
    "--nav-bg": "rgba(10,7,5,.95)", "--topbar-bg": "rgba(10,7,5,.95)",
  },
};

function applyTheme(name) {
  const vars = THEMES[name] || THEMES.light;
  const root = document.documentElement;
  Object.entries(vars).forEach(([k, v]) => root.style.setProperty(k, v));
}

// ─── GLOBAL CSS ──────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=DM+Sans:wght@300;400;500;600&display=swap');

:root {
  --bg: #FAFAF8; --panel: #FFFFFF; --text: #111111;
  --muted: #6B7280; --border: rgba(17,17,17,.10);
  --accent: #7A0C0C; --gold: #C6A75E;
  --shadow: 0 10px 25px rgba(17,17,17,.06);
  --nav-bg: rgba(250,250,248,.92); --topbar-bg: rgba(250,250,248,.92);
  --radius: 14px; --radius-sm: 8px;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body { height: 100%; }
body {
  background: var(--bg); color: var(--text);
  font-family: 'DM Sans', ui-sans-serif, system-ui, sans-serif;
  transition: background .25s, color .25s;
  -webkit-font-smoothing: antialiased;
}
h1,h2,h3,.font-display { font-family: 'Cormorant Garamond', Georgia, serif; }

/* Layout */
.wrap { max-width: 900px; margin: 0 auto; padding: 0 16px; width: 100%; }
.pb-nav { padding-bottom: 80px; }
.space-y-4 > * + * { margin-top: 16px; }
.space-y-3 > * + * { margin-top: 12px; }
.space-y-2 > * + * { margin-top: 8px; }
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.grid-4 { display: grid; grid-template-columns: repeat(4,1fr); gap: 12px; }
@media(max-width:640px){ .grid-4 { grid-template-columns: 1fr 1fr; } .grid-2 { grid-template-columns: 1fr; } }
.flex { display: flex; } .flex-1 { flex: 1; }
.items-center { align-items: center; } .justify-between { justify-content: space-between; }
.gap-2 { gap: 8px; } .gap-3 { gap: 12px; } .gap-4 { gap: 16px; }
.flex-wrap { flex-wrap: wrap; } .min-w-0 { min-width: 0; }
.truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.w-full { width: 100%; } .mt-1{margin-top:4px;} .mt-2{margin-top:8px;} .mt-3{margin-top:12px;} .mt-4{margin-top:16px;}
.ml-auto { margin-left: auto; } .text-right { text-align: right; }
.hidden { display: none; }

/* Typography */
.h1 { font-family: 'Cormorant Garamond', serif; font-size: 1.6rem; font-weight: 600; letter-spacing: -.02em; line-height: 1.2; }
.h2 { font-size: .7rem; font-weight: 600; letter-spacing: .1em; text-transform: uppercase; color: var(--muted); }
.text-sm { font-size: .875rem; } .text-xs { font-size: .75rem; }
.text-lg { font-size: 1.125rem; } .text-2xl { font-size: 1.5rem; }
.font-bold { font-weight: 700; } .font-semibold { font-weight: 600; } .font-medium { font-weight: 500; }
.p-muted { color: var(--muted); }
.line-through { text-decoration: line-through; }
.opacity-60 { opacity: .6; }

/* Card */
.card {
  background: var(--panel); border: 1px solid var(--border);
  border-radius: var(--radius); box-shadow: var(--shadow);
  transition: background .25s, border-color .25s;
}
.p-4 { padding: 16px; } .p-5 { padding: 20px; } .p-6 { padding: 24px; }

/* Inputs */
.input {
  border-radius: var(--radius-sm); padding: 8px 12px; font-size: .875rem;
  outline: none; border: 1px solid var(--border); background: var(--panel);
  color: var(--text); width: 100%; font-family: inherit;
  transition: border-color .15s, box-shadow .15s, background .25s;
}
.input:focus { border-color: rgba(122,12,12,.4); box-shadow: 0 0 0 3px rgba(122,12,12,.08); }
select.input { cursor: pointer; }

/* Buttons */
.btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  border-radius: var(--radius-sm); padding: 8px 14px; font-size: .8125rem;
  font-weight: 500; border: 1px solid transparent; cursor: pointer;
  transition: all .15s; font-family: inherit; white-space: nowrap;
}
.btn:active { transform: translateY(1px); }
.btn:disabled { opacity: .45; cursor: not-allowed; transform: none; }
.btn-primary { background: var(--accent); color: #fff; }
.btn-primary:hover:not(:disabled) { filter: brightness(1.1); }
.btn-gold { background: var(--gold); color: #111; }
.btn-gold:hover:not(:disabled) { filter: brightness(1.05); }
.btn-ghost { background: transparent; border-color: var(--border); color: var(--text); }
.btn-ghost:hover:not(:disabled) { background: rgba(128,128,128,.07); }
.btn-icon { padding: 8px; border-radius: 50%; }

/* Badges */
.badge {
  display: inline-flex; align-items: center; font-size: .7rem; font-weight: 600;
  padding: 2px 10px; border-radius: 99px; border: 1px solid var(--border);
  background: rgba(128,128,128,.06); color: var(--text);
  letter-spacing: .04em;
}
.badge-red { border-color: rgba(122,12,12,.35); background: rgba(122,12,12,.06); color: var(--accent); }
.badge-amber { border-color: rgba(198,140,30,.4); background: rgba(198,140,30,.07); color: #92620a; }
.badge-gold { border-color: rgba(198,167,94,.6); background: rgba(198,167,94,.1); color: #7a5d1e; }
.badge-green { border-color: rgba(34,139,34,.4); background: rgba(34,139,34,.07); color: #186b18; }

/* Row */
.row {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  border-radius: var(--radius-sm); padding: 12px; border: 1px solid var(--border);
  background: var(--panel);
}

/* KPI */
.kpi { font-family: 'Cormorant Garamond', serif; font-size: 2.4rem; font-weight: 700; line-height: 1; }
.kpi-label { font-size: .7rem; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; color: var(--muted); }

/* TopBar */
.topbar {
  position: sticky; top: 0; z-index: 40;
  background: var(--topbar-bg); border-bottom: 1px solid var(--border);
  backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
  transition: background .25s;
}
.topbar-inner { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0; }

/* BottomNav */
.bottom-nav {
  position: fixed; bottom: 0; left: 0; right: 0; z-index: 50;
  background: var(--nav-bg); border-top: 1px solid var(--border);
  backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
  display: flex; justify-content: space-around;
  transition: background .25s;
}
.nav-item {
  display: flex; flex-direction: column; align-items: center; gap: 2px;
  padding: 8px 4px; font-size: .65rem; font-weight: 600; letter-spacing: .06em;
  text-transform: uppercase; color: var(--muted); background: none; border: none;
  cursor: pointer; flex: 1; transition: color .15s;
  text-decoration: none;
}
.nav-item.active, .nav-item:hover { color: var(--accent); }
.nav-icon { font-size: 1.25rem; line-height: 1; }

/* Location tabs */
.loc-tabs { display: flex; gap: 6px; flex-wrap: wrap; }
.loc-tab {
  padding: 5px 12px; border-radius: 99px; font-size: .75rem; font-weight: 600;
  border: 1px solid var(--border); background: transparent; cursor: pointer;
  transition: all .15s; color: var(--text); text-transform: uppercase; letter-spacing: .05em;
}
.loc-tab.active { background: var(--accent); color: #fff; border-color: var(--accent); }

/* Item card */
.item-card {
  border-radius: var(--radius); border: 1px solid var(--border); background: var(--panel);
  padding: 14px 16px; box-shadow: 0 2px 8px rgba(0,0,0,.04);
  transition: box-shadow .15s;
}
.item-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.09); }

/* AI Panel */
.ai-fab {
  position: fixed; bottom: 90px; right: 18px; z-index: 60;
  width: 52px; height: 52px; border-radius: 50%;
  background: linear-gradient(135deg, var(--accent), #b03030);
  color: #fff; border: none; cursor: pointer; font-size: 1.4rem;
  box-shadow: 0 4px 20px rgba(122,12,12,.4);
  display: flex; align-items: center; justify-content: center;
  transition: transform .2s, box-shadow .2s;
}
.ai-fab:hover { transform: scale(1.08); box-shadow: 0 6px 24px rgba(122,12,12,.5); }
.ai-panel {
  position: fixed; bottom: 80px; right: 0; left: 0; z-index: 55;
  max-width: 480px; margin: 0 auto 0 auto;
  background: var(--panel); border: 1px solid var(--border);
  border-radius: var(--radius) var(--radius) 0 0;
  box-shadow: 0 -8px 32px rgba(0,0,0,.15); padding: 0;
  display: flex; flex-direction: column; max-height: 55vh; overflow: hidden;
}
@media(min-width:640px){ .ai-panel { right: 18px; left: auto; border-radius: var(--radius); bottom: 90px; } }
.ai-messages { flex: 1; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 8px; }
.ai-msg { padding: 8px 12px; border-radius: 10px; font-size: .8125rem; max-width: 85%; line-height: 1.45; }
.ai-msg.user { background: var(--accent); color: #fff; align-self: flex-end; }
.ai-msg.ai { background: rgba(128,128,128,.1); color: var(--text); align-self: flex-start; }
.ai-input-row { display: flex; gap: 8px; padding: 10px 12px; border-top: 1px solid var(--border); }
.ai-status { font-size: .7rem; color: var(--muted); padding: 0 14px 6px; }

/* Voice indicator */
.pulse { animation: pulse 1s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }

/* Transitions */
.page-enter { animation: fadeUp .25s ease forwards; }
@keyframes fadeUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:none; } }

/* Toast */
.toast-container { position: fixed; top: 16px; right: 16px; z-index: 99; display: flex; flex-direction: column; gap: 8px; }
.toast { background: var(--panel); border: 1px solid var(--border); border-radius: 10px; padding: 10px 16px;
  font-size: .8125rem; box-shadow: 0 4px 20px rgba(0,0,0,.15); animation: toastIn .2s ease; }
@keyframes toastIn { from{opacity:0;transform:translateX(30px)} to{opacity:1;transform:none} }
.toast.success { border-left: 3px solid #22c55e; }
.toast.error { border-left: 3px solid var(--accent); }
.toast.info { border-left: 3px solid var(--gold); }

/* Misc */
.divider { height: 1px; background: var(--border); margin: 12px 0; }
.pointer-none { pointer-events: none; }
.rounded-full { border-radius: 99px; }
`;

// ─── INJECT CSS ───────────────────────────────────────────────────────────────
const styleEl = document.createElement("style");
styleEl.textContent = CSS;
document.head.appendChild(styleEl);

// ─── TOAST CONTEXT ────────────────────────────────────────────────────────────
const ToastCtx = createContext(null);
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const show = useCallback((msg, type = "info") => {
    const id = uuid();
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3200);
  }, []);
  return (
    <ToastCtx.Provider value={show}>
      {children}
      <div className="toast-container">
        {toasts.map(t => <div key={t.id} className={`toast ${t.type}`}>{t.msg}</div>)}
      </div>
    </ToastCtx.Provider>
  );
}
const useToast = () => useContext(ToastCtx);

// ─── STORE ────────────────────────────────────────────────────────────────────
const STORAGE_KEY = "kitchen-pro/v2";
const LOCS = ["freezer", "fridge", "dry", "counter"];
const nowIso = () => new Date().toISOString();
const today = () => new Date().toISOString().slice(0, 10);

function safeLoad() {
  try { const r = localStorage.getItem(STORAGE_KEY); return r ? JSON.parse(r) : null; } catch { return null; }
}
function ensureKitchen(k) {
  return {
    id: String(k?.id ?? uuid()), name: String(k?.name ?? "Kitchen"),
    ownerName: String(k?.ownerName ?? "Admin"),
    members: Array.isArray(k?.members) ? k.members : [],
    freezer: Array.isArray(k?.freezer) ? k.freezer : [],
    fridge: Array.isArray(k?.fridge) ? k.fridge : [],
    dry: Array.isArray(k?.dry) ? k.dry : [],
    counter: Array.isArray(k?.counter) ? k.counter : [],
    shopping: Array.isArray(k?.shopping) ? k.shopping : [],
    movements: Array.isArray(k?.movements) ? k.movements : [],
    parByCategory: (k?.parByCategory && typeof k.parByCategory === "object") ? k.parByCategory : {},
    createdAt: String(k?.createdAt ?? nowIso()), updatedAt: String(k?.updatedAt ?? nowIso()),
  };
}
function normalizeState(s) {
  const kitchens = Array.isArray(s?.kitchens) ? s.kitchens.map(ensureKitchen) : [];
  return {
    kitchens, theme: s?.theme ?? "light",
    currentKitchenId: s?.currentKitchenId ?? kitchens[0]?.id ?? null,
    currentMemberId: s?.currentMemberId ?? null,
  };
}
const SEED = { kitchens: [], currentKitchenId: null, currentMemberId: null, theme: "light" };

function findItem(k, itemId) {
  for (const loc of LOCS) {
    const idx = k[loc].findIndex(x => x.id === itemId);
    if (idx >= 0) return { loc, idx, item: k[loc][idx] };
  }
  return null;
}
function updateK(state, kitchenId, fn) {
  return { ...state, kitchens: state.kitchens.map(k => k.id !== kitchenId ? k : { ...fn(k), updatedAt: nowIso() }) };
}

function reducer(state, action) {
  switch (action.type) {
    case "SET_THEME": return { ...state, theme: action.theme };
    case "KITCHEN_CREATE": {
      const owner = { id: uuid(), name: (action.ownerName || "Admin").trim(), role: "admin", joinedAt: nowIso() };
      const k = {
        id: uuid(), name: action.name.trim() || "Kitchen", ownerName: owner.name,
        members: [owner], freezer: [], fridge: [], dry: [], counter: [],
        shopping: [], movements: [], parByCategory: {}, createdAt: nowIso(), updatedAt: nowIso(),
      };
      return { ...state, kitchens: [...state.kitchens, k], currentKitchenId: k.id, currentMemberId: owner.id };
    }
    case "KITCHEN_SELECT": return { ...state, currentKitchenId: action.kitchenId };
    case "CURRENT_MEMBER_SET": return { ...state, currentMemberId: action.memberId };
    case "MEMBER_ADD": return updateK(state, action.kitchenId, k => {
      const name = action.name.trim(); if (!name) return k;
      const m = { id: uuid(), name, role: action.role ?? "commis", joinedAt: nowIso() };
      return { ...k, members: [...k.members, m] };
    });
    case "MEMBER_ROLE_UPDATE": return updateK(state, action.kitchenId, k => ({
      ...k, members: k.members.map(m => m.id === action.memberId ? { ...m, role: action.role } : m),
    }));
    case "MEMBER_REMOVE": return updateK(state, action.kitchenId, k => ({
      ...k, members: k.members.filter(m => m.id !== action.memberId),
    }));
    case "PAR_SET_CATEGORY": return updateK(state, action.kitchenId, k => ({
      ...k, parByCategory: { ...k.parByCategory, [action.categoryKey]: action.par },
    }));
    case "ITEM_ADD": return updateK(state, action.kitchenId, k => {
      const it = action.item;
      const loc = it.location ?? "fridge";
      const item = {
        id: it.id ?? uuid(), name: String(it.name ?? "").trim(),
        quantity: Number(it.quantity ?? 0), unit: it.unit ?? "pz", location: loc,
        insertedAt: it.insertedAt ?? nowIso(), insertedDate: it.insertedDate ?? today(),
        expiresAt: it.expiresAt, lot: it.lot, notes: it.notes,
        section: it.section, category: it.category, catalogId: it.catalogId, parLevel: it.parLevel,
      };
      // FIX: single guard (was duplicated in original)
      if (!item.name || !Number.isFinite(item.quantity) || item.quantity <= 0) return k;
      return { ...k, [loc]: [...k[loc], item] };
    });
    case "ITEM_ADJUST": return updateK(state, action.kitchenId, k => {
      const found = findItem(k, action.itemId); if (!found) return k;
      const { loc, idx, item } = found;
      const nextQty = action.mode === "set" ? action.value : item.quantity + action.value;
      const arr = [...k[loc]];
      if (nextQty <= 0) arr.splice(idx, 1); else arr[idx] = { ...item, quantity: nextQty };
      return { ...k, [loc]: arr };
    });
    case "ITEM_REMOVE": return updateK(state, action.kitchenId, k => {
      const next = { ...k };
      for (const loc of LOCS) next[loc] = next[loc].filter(x => x.id !== action.itemId);
      return next;
    });
    case "ITEM_SET_PAR": return updateK(state, action.kitchenId, k => {
      const found = findItem(k, action.itemId); if (!found) return k;
      const { loc, idx, item } = found;
      const arr = [...k[loc]]; arr[idx] = { ...item, parLevel: action.parLevel };
      return { ...k, [loc]: arr };
    });
    case "STOCK_MOVE": return updateK(state, action.kitchenId, k => {
      const found = findItem(k, action.itemId); if (!found) return k;
      const { loc: fromLoc, idx, item } = found;
      const qty = Math.max(0, Math.min(item.quantity, action.qty));
      if (qty <= 0) return k;
      const fromArr = [...k[fromLoc]];
      const remaining = item.quantity - qty;
      if (remaining <= 0) fromArr.splice(idx, 1); else fromArr[idx] = { ...item, quantity: remaining };
      const toLoc = action.to; const toArr = [...k[toLoc]];
      const mergeIdx = toArr.findIndex(x =>
        x.name.toLowerCase() === item.name.toLowerCase() && x.unit === item.unit && String(x.lot ?? "") === String(item.lot ?? "")
      );
      if (mergeIdx >= 0) toArr[mergeIdx] = { ...toArr[mergeIdx], quantity: toArr[mergeIdx].quantity + qty };
      else toArr.push({ ...item, id: uuid(), location: toLoc, quantity: qty, insertedAt: nowIso(), insertedDate: today() });
      return { ...k, [fromLoc]: fromArr, [toLoc]: toArr,
        movements: [{ id: uuid(), at: nowIso(), itemId: action.itemId, name: item.name,
          from: fromLoc, to: toLoc, quantity: qty, unit: item.unit, reason: action.reason }, ...k.movements] };
    });
    case "SHOP_ADD": return updateK(state, action.kitchenId, k => {
      const name = action.name.trim(); if (!name) return k;
      const it = { id: uuid(), name, quantity: Math.max(1, Number(action.quantity || 1)),
        unit: action.unit, category: action.category, notes: action.notes?.trim() || undefined,
        checked: false, createdAt: nowIso() };
      return { ...k, shopping: [it, ...k.shopping] };
    });
    case "SHOP_TOGGLE": return updateK(state, action.kitchenId, k => ({
      ...k, shopping: k.shopping.map(x => x.id === action.itemId ? { ...x, checked: !x.checked } : x),
    }));
    case "SHOP_REMOVE": return updateK(state, action.kitchenId, k => ({
      ...k, shopping: k.shopping.filter(x => x.id !== action.itemId),
    }));
    case "SHOP_CLEAR_CHECKED": return updateK(state, action.kitchenId, k => ({
      ...k, shopping: k.shopping.filter(x => !x.checked),
    }));
    default: return state;
  }
}

const KCtx = createContext(null);
function KitchenProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, SEED, () => {
    const loaded = safeLoad(); return loaded ? normalizeState(loaded) : SEED;
  });
  useEffect(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {} }, [state]);
  useEffect(() => { applyTheme(state.theme); }, [state.theme]);

  const store = useMemo(() => {
    const kid = () => state.currentKitchenId ?? state.kitchens[0]?.id ?? "";
    const getCurrentRole = () => {
      const k = state.kitchens.find(x => x.id === (state.currentKitchenId ?? "")) ?? state.kitchens[0];
      if (!k) return "admin";
      const m = k.members.find(mm => mm.id === state.currentMemberId);
      return m?.role ?? "admin";
    };
    return {
      state, getCurrentRole,
      setTheme: (theme) => dispatch({ type: "SET_THEME", theme }),
      createKitchen: (name, ownerName) => dispatch({ type: "KITCHEN_CREATE", name, ownerName }),
      selectKitchen: (kitchenId) => dispatch({ type: "KITCHEN_SELECT", kitchenId }),
      addMember: (kitchenId, name, role) => dispatch({ type: "MEMBER_ADD", kitchenId, name, role }),
      // FIX: updateMemberRole + removeMember now receive kitchenId from caller
      updateMemberRole: (kitchenId, memberId, role) => dispatch({ type: "MEMBER_ROLE_UPDATE", kitchenId, memberId, role }),
      removeMember: (kitchenId, memberId) => dispatch({ type: "MEMBER_REMOVE", kitchenId, memberId }),
      setCurrentMember: (memberId) => dispatch({ type: "CURRENT_MEMBER_SET", memberId }),
      setParCategory: (categoryKey, par) => { const k = kid(); if (k) dispatch({ type: "PAR_SET_CATEGORY", kitchenId: k, categoryKey, par }); },
      addFreezerItem: (item) => { const k = kid(); if (k) dispatch({ type: "ITEM_ADD", kitchenId: k, item }); },
      // FIX: stockAdd properly aliased to addFreezerItem (was undefined → crashed StockIntake)
      stockAdd: (item) => { const k = kid(); if (k) dispatch({ type: "ITEM_ADD", kitchenId: k, item }); },
      adjustFreezerItem: (itemId, value, mode = "delta") => { const k = kid(); if (k) dispatch({ type: "ITEM_ADJUST", kitchenId: k, itemId, value, mode }); },
      removeFreezerItem: (itemId) => { const k = kid(); if (k) dispatch({ type: "ITEM_REMOVE", kitchenId: k, itemId }); },
      setFreezerParLevel: (itemId, parLevel) => { const k = kid(); if (k) dispatch({ type: "ITEM_SET_PAR", kitchenId: k, itemId, parLevel }); },
      moveStock: (itemId, qty, to, reason) => { const k = kid(); if (k) dispatch({ type: "STOCK_MOVE", kitchenId: k, itemId, qty, to, reason }); },
      shopAdd: (name, quantity, unit, category, notes) => { const k = kid(); if (k) dispatch({ type: "SHOP_ADD", kitchenId: k, name, quantity, unit, category, notes }); },
      shopToggle: (itemId) => { const k = kid(); if (k) dispatch({ type: "SHOP_TOGGLE", kitchenId: k, itemId }); },
      shopRemove: (itemId) => { const k = kid(); if (k) dispatch({ type: "SHOP_REMOVE", kitchenId: k, itemId }); },
      shopClearChecked: () => { const k = kid(); if (k) dispatch({ type: "SHOP_CLEAR_CHECKED", kitchenId: k }); },
    };
  }, [state]);
  return <KCtx.Provider value={store}>{children}</KCtx.Provider>;
}
const useKitchen = () => { const c = useContext(KCtx); if (!c) throw new Error("useKitchen outside provider"); return c; };

// ─── useSpeech HOOK (fixed) ───────────────────────────────────────────────────
function useSpeech() {
  const recRef = useRef(null);
  const [status, setStatus] = useState("idle"); // idle | listening | unsupported
  const [transcript, setTranscript] = useState("");

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setStatus("unsupported"); return; }
    const rec = new SR();
    rec.lang = "it-IT"; rec.interimResults = false; rec.continuous = false;
    rec.onstart = () => setStatus("listening");
    rec.onend = () => setStatus("idle");
    // FIX: added try/catch on result parsing
    rec.onresult = (e) => { try { setTranscript(e.results[0][0].transcript); } catch {} };
    rec.onerror = () => setStatus("idle");
    recRef.current = rec;
    // FIX: abort on unmount to prevent memory leak
    return () => { try { rec.abort(); } catch {} };
  }, []);

  const start = useCallback(() => {
    if (recRef.current && status !== "listening") { setTranscript(""); recRef.current.start(); }
  }, [status]);
  const stop = useCallback(() => { recRef.current?.stop(); }, []);
  return { transcript, status, start, stop, setTranscript };
}

// ─── UTILITY ─────────────────────────────────────────────────────────────────
function hoursUntil(iso) {
  if (!iso) return null;
  const t = Date.parse(iso);
  if (isNaN(t)) return null;
  return Math.floor((t - Date.now()) / 3_600_000);
}
function expiryBadge(iso) {
  const h = hoursUntil(iso);
  if (h === null) return null;
  if (h <= 0) return { label: "SCADUTO", cls: "badge-red" };
  if (h <= 24) return { label: "≤24h", cls: "badge-red" };
  if (h <= 72) return { label: "≤72h", cls: "badge-amber" };
  return { label: "OK", cls: "badge-green" };
}
function stepForUnit(u) {
  if (u === "pz") return [1, 5];
  if (u === "g" || u === "ml") return [100, 500];
  if (u === "kg" || u === "l") return [1, 2];
  return [1, 5];
}

// ─── AI ASSISTANT PANEL ───────────────────────────────────────────────────────
function parseAiAction(text, store) {
  const t = text.toLowerCase();
  // Simple intent parsing — maps voice/text commands to store actions
  // "aggiungi 3 pz di lombata al frigo"
  const addMatch = t.match(/aggiungi\s+(\d+)\s*(pz|kg|g|ml|l)?\s+(?:di\s+)?(.+?)(?:\s+(?:al|nel|in)\s+(frigo|freezer|dispensa|bancone))?$/i);
  if (addMatch) {
    const qty = parseInt(addMatch[1]);
    const unit = addMatch[2] || "pz";
    const name = addMatch[3].trim();
    const locMap = { frigo: "fridge", freezer: "freezer", dispensa: "dry", bancone: "counter" };
    const location = locMap[addMatch[4]] ?? "fridge";
    store.stockAdd({ name, quantity: qty, unit, location, insertedAt: nowIso(), insertedDate: today(), lot: `AI-${today()}` });
    return `✅ Aggiunto: ${qty} ${unit} di ${name} → ${location}`;
  }
  // "rimuovi lombata"
  const removeMatch = t.match(/rimuovi\s+(?:il\s+|la\s+|lo\s+)?(.+)/i);
  if (removeMatch) {
    const name = removeMatch[1].trim();
    const k = store.state.kitchens.find(x => x.id === store.state.currentKitchenId);
    if (k) {
      for (const loc of LOCS) {
        const item = k[loc].find(x => x.name.toLowerCase().includes(name));
        if (item) { store.removeFreezerItem(item.id); return `🗑️ Rimosso: ${item.name}`; }
      }
    }
    return `❌ Prodotto "${name}" non trovato.`;
  }
  return null; // no local action matched → forward to Claude API
}

function AIPanel({ onClose }) {
  const store = useKitchen();
  const { transcript, status, start, stop, setTranscript } = useSpeech();
  const [messages, setMessages] = useState([
    { role: "ai", text: "Ciao Chef! Dimmi cosa vuoi fare. Puoi parlarmi o scrivere: aggiungi, rimuovi, cerca scadenze, genera lista spesa…" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  useEffect(() => {
    if (transcript) { setInput(transcript); setTranscript(""); }
  }, [transcript]);

  async function send(text) {
    if (!text.trim()) return;
    const userMsg = text.trim();
    setMessages(p => [...p, { role: "user", text: userMsg }]);
    setInput("");
    setLoading(true);

    // Try local intent first
    const localResult = parseAiAction(userMsg, store);
    if (localResult) {
      setMessages(p => [...p, { role: "ai", text: localResult }]);
      setLoading(false);
      return;
    }

    // Build context for Claude
    const k = store.state.kitchens.find(x => x.id === store.state.currentKitchenId);
    const inv = k ? LOCS.flatMap(l => k[l].map(i => `${i.name} ${i.quantity}${i.unit} (${l})`)).slice(0, 40).join(", ") : "nessuna";
    const systemPrompt = `Sei l'assistente AI di una cucina Michelin. Rispondi in italiano, in modo conciso e professionale.
Inventario attuale: ${inv}.
Puoi suggerire azioni, analizzare scadenze, aiutare con menu e preparazioni MEP.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 400,
          system: systemPrompt,
          messages: [{ role: "user", content: userMsg }],
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text ?? "Non ho capito, riprova.";
      setMessages(p => [...p, { role: "ai", text: reply }]);
    } catch {
      setMessages(p => [...p, { role: "ai", text: "Errore connessione AI. Controlla la rete." }]);
    }
    setLoading(false);
  }

  return (
    <div className="ai-panel">
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 14px", borderBottom:"1px solid var(--border)" }}>
        <div style={{ fontSize:".8rem", fontWeight:600, letterSpacing:".06em", textTransform:"uppercase", color:"var(--accent)" }}>
          🤖 AI Kitchen Assistant
        </div>
        <button className="btn btn-ghost" style={{ padding:"4px 8px", fontSize:".75rem" }} onClick={onClose}>✕</button>
      </div>
      <div className="ai-messages">
        {messages.map((m, i) => (
          <div key={i} className={`ai-msg ${m.role}`}>{m.text}</div>
        ))}
        {loading && <div className="ai-msg ai" style={{ opacity:.6 }}>...</div>}
        <div ref={endRef} />
      </div>
      {status === "listening" && <div className="ai-status pulse">🎙️ In ascolto…</div>}
      <div className="ai-input-row">
        <input
          className="input" style={{ flex:1 }}
          placeholder="Scrivi o parla…"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter") send(input); }}
        />
        <button
          className={`btn ${status === "listening" ? "btn-primary pulse" : "btn-ghost"}`}
          onClick={status === "listening" ? stop : start}
          title="Voce"
        >🎙️</button>
        <button className="btn btn-primary" onClick={() => send(input)}>➤</button>
      </div>
    </div>
  );
}

// ─── STOCK INTAKE COMPONENT ───────────────────────────────────────────────────
const UNITS = ["pz","g","kg","ml","l","vac","busta","brik","latta","box","vasch"];
const SAMPLE_CATALOG = [
  { id:"c1", name:"Piccione", categoryKey:"proteine", defaultLocation:"fridge" },
  { id:"c2", name:"Astice", categoryKey:"pesce", defaultLocation:"fridge" },
  { id:"c3", name:"Wagyu A5", categoryKey:"proteine", defaultLocation:"fridge" },
  { id:"c4", name:"Rombo", categoryKey:"pesce", defaultLocation:"fridge" },
  { id:"c5", name:"Capesante", categoryKey:"pesce", defaultLocation:"freezer" },
  { id:"c6", name:"Topinambur", categoryKey:"verdure", defaultLocation:"dry" },
  { id:"c7", name:"Cavolo nero", categoryKey:"verdure", defaultLocation:"fridge" },
  { id:"c8", name:"Acetosella", categoryKey:"erbe", defaultLocation:"fridge" },
  { id:"c9", name:"Burro Bordier", categoryKey:"latticini", defaultLocation:"fridge" },
  { id:"c10", name:"Fondo Bruno", categoryKey:"fondi", defaultLocation:"fridge" },
  { id:"c11", name:"Tartufo Nero", categoryKey:"spezie", defaultLocation:"dry" },
  { id:"c12", name:"Bisque", categoryKey:"fondi", defaultLocation:"freezer" },
];

function StockIntake({ defaultLocation, lockLocation }) {
  const { stockAdd, state } = useKitchen();
  const toast = useToast();
  const { transcript, status, start, stop, setTranscript } = useSpeech();
  const categories = useMemo(() => [...new Set(SAMPLE_CATALOG.map(x => x.categoryKey))].sort(), []);
  const [catKey, setCatKey] = useState(categories[0] ?? "proteine");
  const itemsInCat = useMemo(() => SAMPLE_CATALOG.filter(x => x.categoryKey === catKey), [catKey]);
  const [catalogId, setCatalogId] = useState(itemsInCat[0]?.id ?? "");
  const selected = SAMPLE_CATALOG.find(x => x.id === catalogId) ?? null;
  const [name, setName] = useState(selected?.name ?? "");
  const [qty, setQty] = useState(1);
  const [unit, setUnit] = useState("pz");
  const [location, setLocation] = useState(defaultLocation ?? "fridge");
  const [expiresAt, setExpiresAt] = useState("");
  const [lot, setLot] = useState("");
  const [notes, setNotes] = useState("");

  useEffect(() => { if (!itemsInCat.some(x => x.id === catalogId)) setCatalogId(itemsInCat[0]?.id ?? ""); }, [catKey]);
  useEffect(() => { setName(selected?.name ?? ""); }, [selected?.id]);
  useEffect(() => { if (defaultLocation) setLocation(defaultLocation); }, [defaultLocation]);

  // Voice: parse "aggiungi X [unit] [nome]"
  useEffect(() => {
    if (!transcript) return;
    const m = transcript.match(/(?:aggiungi|carica)\s+(\d+)\s*(pz|kg|g|ml|l)?\s+(?:di\s+)?(.+)/i);
    if (m) {
      setQty(parseInt(m[1])); if (m[2]) setUnit(m[2]);
      setName(m[3].trim());
    }
    setTranscript("");
  }, [transcript]);

  const canSave = name.trim().length > 0 && qty > 0 && lot.trim().length > 0;

  function submit() {
    if (!canSave) return;
    const k = state.kitchens.find(k => k.id === state.currentKitchenId);
    const par = unit === "pz" ? (k?.parByCategory?.[selected?.categoryKey ?? "default"] ?? k?.parByCategory?.default ?? 5) : undefined;
    stockAdd({ name: name.trim(), quantity: Number(qty), unit, location, insertedDate: today(), expiresAt: expiresAt || undefined, lot: lot.trim(), notes: notes.trim() || undefined, catalogId: selected?.id, category: selected?.categoryKey, parLevel: par });
    setQty(1); setUnit("pz"); setExpiresAt(""); setLot(""); setNotes("");
    toast("✅ Carico salvato: " + name.trim(), "success");
  }

  return (
    <div className="card p-4 space-y-3">
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <div className="h2">Carico Giacenza</div>
        <button className={`btn btn-ghost btn-icon ${status === "listening" ? "btn-primary pulse" : ""}`}
          onClick={status === "listening" ? stop : start} title="Dettatura vocale">🎙️</button>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
        <div>
          <div className="text-xs p-muted" style={{ marginBottom:4 }}>Categoria</div>
          <select className="input" value={catKey} onChange={e => setCatKey(e.target.value)}>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <div className="text-xs p-muted" style={{ marginBottom:4 }}>Prodotto</div>
          <select className="input" value={catalogId} onChange={e => setCatalogId(e.target.value)}>
            {itemsInCat.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}
          </select>
        </div>
        <div style={{ gridColumn:"1/-1" }}>
          <div className="text-xs p-muted" style={{ marginBottom:4 }}>Nome (modificabile)</div>
          <input className="input" value={name} onChange={e => setName(e.target.value)} placeholder="Nome prodotto…" />
        </div>
        <div>
          <div className="text-xs p-muted" style={{ marginBottom:4 }}>Quantità</div>
          <input className="input" type="number" min={0} step={1} value={qty} onChange={e => setQty(Number(e.target.value))} />
        </div>
        <div>
          <div className="text-xs p-muted" style={{ marginBottom:4 }}>Unità</div>
          <select className="input" value={unit} onChange={e => setUnit(e.target.value)}>
            {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
          </select>
        </div>
        {!lockLocation && (
          <div>
            <div className="text-xs p-muted" style={{ marginBottom:4 }}>Location</div>
            <select className="input" value={location} onChange={e => setLocation(e.target.value)}>
              {LOCS.map(l => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
        )}
        <div>
          <div className="text-xs p-muted" style={{ marginBottom:4 }}>Scadenza</div>
          <input className="input" type="date" value={expiresAt} onChange={e => setExpiresAt(e.target.value)} />
        </div>
        <div>
          <div className="text-xs p-muted" style={{ marginBottom:4 }}>Lotto <span style={{ color:"var(--accent)" }}>*</span></div>
          <input className="input" value={lot} onChange={e => setLot(e.target.value)} placeholder="LOT-2026-…" />
        </div>
        <div style={{ gridColumn:"1/-1" }}>
          <div className="text-xs p-muted" style={{ marginBottom:4 }}>Note / fornitore</div>
          <input className="input" value={notes} onChange={e => setNotes(e.target.value)} placeholder="DDT, fornitore, qualità…" />
        </div>
      </div>
      <button className={`btn btn-primary w-full ${!canSave ? "pointer-none" : ""}`} style={{ opacity: canSave ? 1 : .45 }} onClick={submit}>
        Salva carico
      </button>
      {!canSave && <div className="text-xs p-muted">Nome + Quantità + Lotto obbligatori.</div>}
    </div>
  );
}

// ─── PAGES ────────────────────────────────────────────────────────────────────

function Dashboard() {
  const { state } = useKitchen();
  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const stats = useMemo(() => {
    if (!kitchen) return null;
    const inv = LOCS.flatMap(l => kitchen[l]);
    const expired = inv.filter(x => { const h = hoursUntil(x.expiresAt); return h !== null && h <= 0; });
    const urgent24 = inv.filter(x => { const h = hoursUntil(x.expiresAt); return h !== null && h > 0 && h <= 24; });
    const urgent72 = inv.filter(x => { const h = hoursUntil(x.expiresAt); return h !== null && h > 24 && h <= 72; });
    const low = inv.filter(x => x.unit === "pz" && x.parLevel != null && x.quantity < x.parLevel);
    const toBuy = (kitchen.shopping || []).filter(x => !x.checked);
    return { total: inv.length, expired: expired.length, urgent: urgent24.length + urgent72.length, low: low.length, toBuy: toBuy.length, members: kitchen.members.length };
  }, [kitchen]);

  if (!kitchen || !stats) return (
    <div className="page-enter card p-6 space-y-4">
      <div className="h1">Kitchen Pro</div>
      <div className="p-muted">Crea o seleziona una Kitchen per iniziare.</div>
    </div>
  );

  const cards = [
    { label: "Inventario totale", val: stats.total, sub: "tutti i reparti", cls: "" },
    { label: "Scaduti / oggi", val: stats.expired, sub: "azione immediata", cls: stats.expired > 0 ? "badge-red" : "" },
    { label: "Urgenti", val: stats.urgent, sub: "≤ 72 ore", cls: stats.urgent > 0 ? "badge-amber" : "" },
    { label: "Low stock", val: stats.low, sub: "sotto par (pz)", cls: stats.low > 0 ? "badge-red" : "" },
  ];

  return (
    <div className="page-enter space-y-4">
      <div className="card p-5">
        <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:12 }}>
          <div>
            <div className="h1">Kitchen Pro</div>
            <div className="p-muted text-sm mt-1">{kitchen.name} · {stats.members} membri</div>
          </div>
          <div style={{ display:"flex", gap:6 }}>
            <span className="badge">{new Date().toLocaleDateString("it-IT", { weekday:"long", day:"numeric", month:"long" })}</span>
          </div>
        </div>
      </div>

      <div className="grid-4">
        {cards.map(c => (
          <div key={c.label} className="card p-4">
            <div className="kpi-label">{c.label}</div>
            <div className="kpi mt-1" style={{ color: c.cls.includes("red") ? "var(--accent)" : c.cls.includes("amber") ? "#92620a" : "var(--text)" }}>{c.val}</div>
            <div className="text-xs p-muted mt-1">{c.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card p-5">
          <div className="h2">Azioni rapide</div>
          <div className="mt-3" style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
            {[["Giacenze","/inventory"],["MEP","/mep"],["Spesa","/orders"],["Team","/members"],["Impostazioni","/settings"]].map(([label, path]) => (
              <PageLink key={path} to={path} className="btn btn-ghost text-sm">{label}</PageLink>
            ))}
          </div>
        </div>
        <div className="card p-5">
          <div className="h2">Da acquistare</div>
          <div className="kpi mt-2">{stats.toBuy}</div>
          <div className="p-muted text-xs mt-1">articoli non spuntati</div>
          <div className="mt-3">
            <PageLink to="/orders" className="btn btn-gold text-sm w-full">Apri lista spesa</PageLink>
          </div>
        </div>
      </div>
    </div>
  );
}

function Inventory() {
  const { state, adjustFreezerItem, removeFreezerItem, setFreezerParLevel, getCurrentRole } = useKitchen();
  const toast = useToast();
  const canEdit = ["admin","chef","sous-chef","capo-partita"].includes(getCurrentRole());
  const [loc, setLoc] = useState("fridge");
  const [q, setQ] = useState("");

  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const items = useMemo(() => {
    if (!kitchen) return [];
    const term = q.trim().toLowerCase();
    return kitchen[loc]
      .filter(x => !term || x.name.toLowerCase().includes(term) || (x.lot ?? "").toLowerCase().includes(term))
      .slice().sort((a, b) => (a.expiresAt ?? "").localeCompare(b.expiresAt ?? ""));
  }, [kitchen, loc, q]);

  const locLabels = { freezer:"🧊 Freezer", fridge:"❄️ Frigo", dry:"📦 Dispensa", counter:"🍽️ Bancone" };

  return (
    <div className="page-enter space-y-4">
      <StockIntake defaultLocation={loc} lockLocation />

      <div className="card p-4">
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:8 }}>
          <div className="h2">Giacenze</div>
          <div className="loc-tabs">
            {LOCS.map(l => (
              <button key={l} className={`loc-tab ${loc === l ? "active" : ""}`} onClick={() => setLoc(l)}>
                {locLabels[l]}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-3">
          <input className="input" value={q} onChange={e => setQ(e.target.value)} placeholder="🔍 Cerca nome o lotto…" />
        </div>

        <div className="space-y-2 mt-4">
          {!kitchen && <div className="p-muted text-sm">Seleziona una kitchen.</div>}
          {kitchen && items.length === 0 && <div className="p-muted text-sm">Nessun prodotto in {locLabels[loc]}.</div>}
          {items.map(x => {
            const badge = expiryBadge(x.expiresAt);
            const isLow = x.unit === "pz" && x.parLevel != null && x.quantity < x.parLevel;
            const [a, b] = stepForUnit(x.unit);
            return (
              <div key={x.id} className="item-card">
                <div style={{ display:"flex", justifyContent:"space-between", gap:8 }}>
                  <div className="min-w-0">
                    <div className="font-semibold text-sm" style={{ display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
                      {x.name}
                      {isLow && <span className="badge badge-red">LOW</span>}
                      {badge && <span className={`badge ${badge.cls}`}>{badge.label}</span>}
                    </div>
                    <div className="text-xs p-muted mt-1">
                      {x.location} · lotto {x.lot ?? "—"} · carico {x.insertedDate ?? x.insertedAt?.slice(0,10)}
                      {x.expiresAt ? " · exp " + x.expiresAt.slice(0,10) : ""}
                    </div>
                  </div>
                  <div className="text-right" style={{ flexShrink:0 }}>
                    <div className="font-bold text-lg">{x.quantity} <span className="text-sm p-muted">{x.unit}</span></div>
                    {x.unit === "pz" && <div className="text-xs p-muted">MIN: {x.parLevel ?? "—"}</div>}
                  </div>
                </div>
                <div className="mt-3" style={{ display:"flex", gap:6, flexWrap:"wrap", alignItems:"center" }}>
                  {[[-a,`-${a}`],[+a,`+${a}`],[-b,`-${b}`],[+b,`+${b}`]].map(([delta, label]) => (
                    <button key={label} className="btn btn-ghost text-xs" disabled={!canEdit} onClick={() => adjustFreezerItem(x.id, delta)}>{label}</button>
                  ))}
                  {x.unit === "pz" && (
                    <button className="btn btn-gold text-xs" disabled={!canEdit} onClick={() => {
                      const v = prompt("Imposta MIN (pz). 'off' per disabilitare", String(x.parLevel ?? 5));
                      if (v === null) return;
                      if (v.trim().toLowerCase() === "off") return setFreezerParLevel(x.id, undefined);
                      const n = Math.floor(Number(v || "5"));
                      if (Number.isFinite(n) && n > 0) setFreezerParLevel(x.id, n);
                    }}>MIN</button>
                  )}
                  <button className="btn btn-ghost text-xs ml-auto" disabled={!canEdit}
                    onClick={() => { removeFreezerItem(x.id); toast(`🗑️ Rimosso: ${x.name}`, "info"); }}>
                    Rimuovi
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function MEP() {
  const { state, getCurrentRole, addFreezerItem } = useKitchen();
  const toast = useToast();
  const canEdit = ["admin","chef","sous-chef","capo-partita"].includes(getCurrentRole());
  const kitchenId = state.currentKitchenId;
  const MEP_KEY = kitchenId ? `mep/${kitchenId}` : null;

  const [tasks, setTasks] = useState(() => {
    if (!MEP_KEY) return [];
    try { return JSON.parse(localStorage.getItem(MEP_KEY) || "[]"); } catch { return []; }
  });
  const [title, setTitle] = useState("");
  const [modal, setModal] = useState(null); // { task, qty, location }
  const { transcript, status, start, stop, setTranscript } = useSpeech();

  useEffect(() => {
    if (!MEP_KEY) return;
    localStorage.setItem(MEP_KEY, JSON.stringify(tasks));
  }, [tasks, MEP_KEY]);

  useEffect(() => {
    if (transcript) { setTitle(transcript); setTranscript(""); }
  }, [transcript]);

  function addTask() {
    if (!canEdit || !title.trim()) return;
    setTasks(p => [{ id: uuid(), title: title.trim(), done: false, createdAt: nowIso() }, ...p]);
    setTitle(""); toast("✅ Preparazione aggiunta", "success");
  }

  function toggle(id) {
    setTasks(p => p.map(t => t.id === id ? { ...t, done: !t.done, doneAt: !t.done ? nowIso() : undefined } : t));
  }

  function confirmComplete(task, qty, location) {
    addFreezerItem({ id: uuid(), name: task.title, quantity: Math.max(1, qty), unit: "pz", location, insertedAt: nowIso() });
    toggle(task.id); setModal(null); toast(`✅ ${task.title} → ${location}`, "success");
  }

  if (!kitchenId) return <div className="card p-6 p-muted">Seleziona una Kitchen.</div>;

  const done = tasks.filter(t => t.done);
  const todo = tasks.filter(t => !t.done);

  return (
    <div className="page-enter space-y-4">
      <div className="card p-4">
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:8 }}>
          <div className="h1">MEP Giornaliero</div>
          <span className="badge">{todo.length} da fare · {done.length} completate</span>
        </div>
        <div className="mt-3" style={{ display:"flex", gap:8 }}>
          <input className="input flex-1" placeholder="Nuova preparazione… (o usa 🎙️)"
            value={title} onChange={e => setTitle(e.target.value)} disabled={!canEdit}
            onKeyDown={e => { if (e.key === "Enter") addTask(); }} />
          <button className={`btn btn-ghost btn-icon ${status === "listening" ? "btn-primary pulse" : ""}`}
            onClick={status === "listening" ? stop : start}>🎙️</button>
          <button className="btn btn-primary" onClick={addTask} disabled={!canEdit}>+</button>
        </div>
      </div>

      {todo.length > 0 && (
        <div className="space-y-2">
          <div className="h2" style={{ paddingLeft:4 }}>Da completare</div>
          {todo.map(task => (
            <div key={task.id} className="card p-4" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:12 }}>
              <div className="font-medium text-sm min-w-0 truncate">{task.title}</div>
              <div style={{ display:"flex", gap:6, flexShrink:0 }}>
                {canEdit && (
                  <button className="btn btn-gold text-xs"
                    onClick={() => setModal({ task, qty: 1, location: "fridge" })}>
                    Completa + Carica
                  </button>
                )}
                <button className="btn btn-ghost text-xs" onClick={() => toggle(task.id)}>✓</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {done.length > 0 && (
        <div className="space-y-2">
          <div className="h2" style={{ paddingLeft:4 }}>Completate</div>
          {done.map(task => (
            <div key={task.id} className="card p-4" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:12, opacity:.6 }}>
              <div className="text-sm line-through min-w-0 truncate">{task.title}</div>
              <button className="btn btn-ghost text-xs" onClick={() => toggle(task.id)}>Ripristina</button>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {modal && (
        <div style={{ position:"fixed", inset:0, zIndex:80, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}>
          <div className="card p-5" style={{ width:"100%", maxWidth:380 }}>
            <div className="font-semibold mb-3">Completa: {modal.task.title}</div>
            <div className="space-y-3">
              <div>
                <div className="text-xs p-muted mb-1">Quantità prodotta (pz)</div>
                <input className="input" type="number" min={1} value={modal.qty}
                  onChange={e => setModal(m => ({ ...m, qty: Number(e.target.value) }))} />
              </div>
              <div>
                <div className="text-xs p-muted mb-1">Destinazione</div>
                <select className="input" value={modal.location}
                  onChange={e => setModal(m => ({ ...m, location: e.target.value }))}>
                  <option value="fridge">Frigo</option>
                  <option value="freezer">Freezer</option>
                  <option value="dry">Dispensa</option>
                </select>
              </div>
              <div style={{ display:"flex", gap:8 }}>
                <button className="btn btn-ghost flex-1" onClick={() => setModal(null)}>Annulla</button>
                <button className="btn btn-primary flex-1" onClick={() => confirmComplete(modal.task, modal.qty, modal.location)}>Conferma</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Orders() {
  const { state, getCurrentRole, shopAdd, shopToggle, shopRemove, shopClearChecked } = useKitchen();
  const toast = useToast();
  const canEdit = ["admin","chef","sous-chef","capo-partita"].includes(getCurrentRole());
  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const { transcript, status, start, stop, setTranscript } = useSpeech();

  const CATS = [
    { key: "economato", label: "Economato" },
    { key: "giornaliero", label: "Giornaliera" },
    { key: "settimanale", label: "Settimanale" },
  ];
  const [cat, setCat] = useState("economato");
  const [name, setName] = useState(""); const [qty, setQty] = useState(1); const [unit, setUnit] = useState("pz"); const [notes, setNotes] = useState("");

  useEffect(() => {
    if (transcript) { setName(transcript); setTranscript(""); }
  }, [transcript]);

  const items = useMemo(() => {
    const list = (kitchen?.shopping || []).filter(x => x.category === cat);
    return list.slice().sort((a, b) => a.checked !== b.checked ? (a.checked ? 1 : -1) : a.name.localeCompare(b.name));
  }, [kitchen, cat]);

  function add() {
    if (!kitchen || !canEdit || !name.trim()) return;
    shopAdd(name.trim(), Math.max(1, qty), unit, cat, notes.trim() || undefined);
    setName(""); setQty(1); setUnit("pz"); setNotes("");
    toast("✅ Aggiunto alla lista", "success");
  }

  if (!kitchen) return <div className="card p-6 p-muted">Seleziona una Kitchen.</div>;

  return (
    <div className="page-enter space-y-4">
      <div className="card p-4">
        <div className="h1">Lista Spesa</div>
        <div style={{ display:"flex", gap:6, marginTop:12, flexWrap:"wrap" }}>
          {CATS.map(c => (
            <button key={c.key} className={`loc-tab ${cat === c.key ? "active" : ""}`} onClick={() => setCat(c.key)}>{c.label}</button>
          ))}
          <button className="btn btn-ghost text-xs ml-auto" onClick={() => { shopClearChecked(); toast("🧹 Spuntati rimossi", "info"); }} disabled={!canEdit}>
            Pulisci spuntati
          </button>
        </div>

        <div className="mt-3" style={{ display:"grid", gridTemplateColumns:"1fr auto auto 1fr auto auto", gap:6, alignItems:"end" }}>
          <div style={{ gridColumn:"1/3" }}>
            <div className="text-xs p-muted mb-1">Articolo</div>
            <div style={{ display:"flex", gap:6 }}>
              <input className="input flex-1" placeholder="Nome articolo…" value={name} onChange={e => setName(e.target.value)}
                disabled={!canEdit} onKeyDown={e => { if (e.key === "Enter") add(); }} />
              <button className={`btn btn-ghost btn-icon ${status === "listening" ? "btn-primary pulse" : ""}`}
                onClick={status === "listening" ? stop : start}>🎙️</button>
            </div>
          </div>
          <div>
            <div className="text-xs p-muted mb-1">Qtà</div>
            <input className="input" type="number" min={1} value={qty} onChange={e => setQty(Number(e.target.value))} disabled={!canEdit} style={{ width:70 }} />
          </div>
          <div>
            <div className="text-xs p-muted mb-1">Unità</div>
            <select className="input" value={unit} onChange={e => setUnit(e.target.value)} disabled={!canEdit} style={{ width:80 }}>
              {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
            </select>
          </div>
          <div style={{ gridColumn:"5/7" }}>
            <div className="text-xs p-muted mb-1">Note (opt)</div>
            <div style={{ display:"flex", gap:6 }}>
              <input className="input flex-1" placeholder="Note…" value={notes} onChange={e => setNotes(e.target.value)} disabled={!canEdit} />
              <button className="btn btn-primary" onClick={add} disabled={!canEdit}>+</button>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        {items.length === 0 && <div className="card p-4 p-muted">Nessun elemento in {cat}.</div>}
        {items.map(x => (
          <div key={x.id} className="card p-4" style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:12 }}>
            <div style={{ display:"flex", alignItems:"flex-start", gap:10, minWidth:0, flex:1 }}>
              <input type="checkbox" checked={x.checked} onChange={() => shopToggle(x.id)} disabled={!canEdit}
                style={{ marginTop:3, accentColor:"var(--accent)", flexShrink:0 }} />
              <div className="min-w-0">
                <div className={`font-semibold text-sm ${x.checked ? "line-through opacity-60" : ""}`}>{x.name}</div>
                <div className="text-xs p-muted mt-1">{x.quantity} {x.unit}{x.notes ? ` · ${x.notes}` : ""}</div>
              </div>
            </div>
            {canEdit && <button className="btn btn-ghost text-xs" onClick={() => { shopRemove(x.id); toast(`🗑️ Rimosso: ${x.name}`, "info"); }}>✕</button>}
          </div>
        ))}
      </div>
    </div>
  );
}

const ROLES = ["admin","chef","sous-chef","capo-partita","commis","stagista","staff"];
function Members() {
  const { state, getCurrentRole, addMember, updateMemberRole, removeMember } = useKitchen();
  const toast = useToast();
  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const isAdmin = getCurrentRole() === "admin";
  const [newName, setNewName] = useState(""); const [newRole, setNewRole] = useState("commis");

  if (!kitchen) return <div className="card p-6 p-muted">Seleziona una Kitchen.</div>;

  function handleAdd() {
    if (!newName.trim()) return;
    addMember(kitchen.id, newName.trim(), newRole);
    setNewName(""); toast("✅ Membro aggiunto", "success");
  }

  function roleCls(r) {
    if (r === "admin") return "badge badge-gold";
    if (["chef","sous-chef","capo-partita"].includes(r)) return "badge badge-red";
    return "badge";
  }

  return (
    <div className="page-enter space-y-4">
      <div className="card p-5">
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:12 }}>
          <div>
            <div className="h1">Team</div>
            <div className="p-muted text-sm mt-1">{kitchen.name} · {kitchen.members.length} membri</div>
          </div>
          <span className={roleCls(getCurrentRole())}>{getCurrentRole()}</span>
        </div>
        {isAdmin && (
          <div className="mt-4" style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            <input className="input flex-1" placeholder="Nome nuovo membro…" value={newName}
              onChange={e => setNewName(e.target.value)} onKeyDown={e => { if (e.key === "Enter") handleAdd(); }} />
            <select className="input" value={newRole} onChange={e => setNewRole(e.target.value)} style={{ width:140 }}>
              {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
            <button className="btn btn-primary" onClick={handleAdd}>Aggiungi</button>
          </div>
        )}
      </div>

      <div className="space-y-3">
        {kitchen.members.map(m => (
          <div key={m.id} className="card p-4" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:12 }}>
            <div className="min-w-0">
              <div className="font-semibold text-sm truncate">{m.name}</div>
              <div className="mt-1"><span className={roleCls(m.role)}>{m.role}</span></div>
            </div>
            {isAdmin && (
              <div style={{ display:"flex", gap:8, flexShrink:0 }}>
                {/* FIX: pass kitchen.id to updateMemberRole (original was missing kitchenId) */}
                <select className="input" value={m.role} style={{ width:130 }}
                  onChange={e => updateMemberRole(kitchen.id, m.id, e.target.value)}>
                  {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
                {/* FIX: pass kitchen.id to removeMember */}
                <button className="btn btn-ghost text-xs" onClick={() => {
                  if (confirm(`Rimuovere ${m.name}?`)) { removeMember(kitchen.id, m.id); toast(`🗑️ ${m.name} rimosso`, "info"); }
                }}>✕</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

const PAR_ROWS = [
  { key:"proteine", label:"Proteine animali", ex:"piccione, astice, wagyu", def:6 },
  { key:"pesce", label:"Pesce & molluschi", ex:"rombo, capesante, ricci", def:4 },
  { key:"verdure", label:"Verdure & radici", ex:"topinambur, scorzonera", def:8 },
  { key:"erbe", label:"Erbe & fiori", ex:"acetosella, borragine", def:12 },
  { key:"latticini", label:"Latticini & uova", ex:"burro Bordier, uova", def:6 },
  { key:"cereali", label:"Farine & cereali", ex:"farro, semola", def:3 },
  { key:"grassi", label:"Grassi & oli", ex:"EVO, burro chiarificato", def:4 },
  { key:"fermentati", label:"Acidi & fermentati", ex:"koji, miso, kombucha", def:6 },
  { key:"spezie", label:"Spezie & aromi secchi", ex:"pepe lungo, sumac", def:10 },
  { key:"fondi", label:"Fondi & riduzioni", ex:"fondo bruno, dashi, bisque", def:4 },
  { key:"cantina", label:"Cantina & beverage", ex:"vini, sake da cucina", def:6 },
  { key:"consumabili", label:"Consumabili & secco", ex:"agar, lecitina", def:5 },
  { key:"default", label:"Default (fallback)", ex:"—", def:5 },
];

function KitchenSettings() {
  const { state, createKitchen, selectKitchen, setParCategory, setTheme } = useKitchen();
  const toast = useToast();
  const [name, setName] = useState(""); const [owner, setOwner] = useState("Admin");
  const currentK = state.kitchens.find(k => k.id === state.currentKitchenId);
  const parMap = currentK?.parByCategory ?? {};

  function create() {
    const t = name.trim(); if (!t) return;
    createKitchen(t, owner.trim() || "Admin"); setName(""); toast("✅ Kitchen creata", "success");
  }

  return (
    <div className="page-enter space-y-4">
      <div className="card p-4">
        <div className="h2">Tema</div>
        <div style={{ display:"flex", gap:8, marginTop:10 }}>
          {Object.keys(THEMES).map(t => (
            <button key={t} className={`btn ${state.theme === t ? "btn-primary" : "btn-ghost"} text-xs`}
              onClick={() => setTheme(t)} style={{ textTransform:"capitalize" }}>{t}</button>
          ))}
        </div>
      </div>

      <div className="card p-4">
        <div className="h1">Kitchen Management</div>
        <div className="mt-3" style={{ display:"grid", gridTemplateColumns:"1fr auto auto", gap:8 }}>
          <input className="input" placeholder="Nome cucina…" value={name} onChange={e => setName(e.target.value)} />
          <input className="input" placeholder="Owner" value={owner} onChange={e => setOwner(e.target.value)} style={{ width:120 }} />
          <button className="btn btn-primary" onClick={create}>Crea</button>
        </div>
        <div className="space-y-2 mt-4">
          {state.kitchens.length === 0 && <div className="p-muted text-sm">Nessuna kitchen. Creane una.</div>}
          {state.kitchens.map(k => (
            <button key={k.id} className={`row w-full ${k.id === state.currentKitchenId ? "ring-1" : ""}`}
              style={{ width:"100%", border: k.id === state.currentKitchenId ? "1px solid var(--gold)" : undefined }}
              onClick={() => selectKitchen(k.id)}>
              <div className="min-w-0">
                <div className="font-semibold truncate">{k.name}</div>
                <div className="text-xs p-muted truncate">{k.id}</div>
              </div>
              <span className={`badge ${k.id === state.currentKitchenId ? "badge-gold" : ""}`}>
                {k.id === state.currentKitchenId ? "Attiva" : "Seleziona"}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="card p-4">
        <div className="h2">Par Levels Michelin</div>
        {!currentK ? <div className="p-muted text-sm mt-3">Seleziona una kitchen.</div> : (
          <div className="space-y-2 mt-3">
            {PAR_ROWS.map(r => {
              const cur = Number(parMap[r.key] ?? r.def);
              return (
                <div key={r.key} className="row">
                  <div className="min-w-0">
                    <div className="font-semibold text-sm">{r.label}</div>
                    <div className="text-xs p-muted">{r.ex}</div>
                  </div>
                  <input className="input" type="number" min={0} step={1} defaultValue={cur} style={{ width:80, textAlign:"center" }}
                    onBlur={e => setParCategory(r.key, Math.max(0, Math.floor(Number(e.target.value || cur))))}
                    onKeyDown={e => { if (e.key === "Enter") e.target.blur(); }} />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ROUTING (simple hash-based) ──────────────────────────────────────────────
function PageLink({ to, className, children, style }) {
  return <a href={`#${to}`} className={className} style={style}>{children}</a>;
}

const NAV = [
  { path:"/", icon:"🏠", label:"Home" },
  { path:"/inventory", icon:"📦", label:"Giacenze" },
  { path:"/mep", icon:"📋", label:"MEP" },
  { path:"/orders", icon:"🛒", label:"Spesa" },
  { path:"/members", icon:"👨‍🍳", label:"Team" },
  { path:"/settings", icon:"⚙️", label:"Settings" },
];

function useRoute() {
  const [route, setRoute] = useState(() => window.location.hash.slice(1) || "/");
  useEffect(() => {
    const handler = () => setRoute(window.location.hash.slice(1) || "/");
    window.addEventListener("hashchange", handler);
    return () => window.removeEventListener("hashchange", handler);
  }, []);
  return route;
}

function TopBar({ route }) {
  const { state } = useKitchen();
  const kitchen = state.kitchens.find(k => k.id === state.currentKitchenId);
  const titles = { "/":"Dashboard", "/inventory":"Giacenze", "/mep":"MEP", "/orders":"Spesa", "/members":"Team", "/settings":"Impostazioni" };
  return (
    <div className="topbar">
      <div className="wrap topbar-inner">
        <div>
          <div className="h1" style={{ fontSize:"1.1rem" }}>{titles[route] ?? "Kitchen Pro"}</div>
          <div className="text-xs p-muted">{kitchen?.name ?? "Seleziona una kitchen"}</div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end" }}>
            <div style={{ fontFamily:"'Cormorant Garamond', serif", fontWeight:600, fontSize:"1rem", letterSpacing:"-.01em", lineHeight:1 }}>
              Kitchen Pro
            </div>
            <div style={{ fontSize:".65rem", letterSpacing:".08em", color:"var(--gold)", textTransform:"uppercase" }}>Michelin workflow</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BottomNav({ route }) {
  return (
    <div className="bottom-nav">
      {NAV.map(n => (
        <a key={n.path} href={`#${n.path}`} className={`nav-item ${route === n.path ? "active" : ""}`}>
          <span className="nav-icon">{n.icon}</span>
          {n.label}
        </a>
      ))}
    </div>
  );
}

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const route = useRoute();
  const [aiOpen, setAiOpen] = useState(false);

  const pages = {
    "/": Dashboard,
    "/inventory": Inventory,
    "/mep": MEP,
    "/orders": Orders,
    "/members": Members,
    "/settings": KitchenSettings,
  };
  const Page = pages[route] ?? Dashboard;

  return (
    <KitchenProvider>
      <ToastProvider>
        <TopBar route={route} />
        <main className="wrap pb-nav" style={{ paddingTop:16 }}>
          <Page />
        </main>
        <BottomNav route={route} />

        {/* AI FAB */}
        <button className="ai-fab" onClick={() => setAiOpen(p => !p)} title="AI Assistant">
          {aiOpen ? "✕" : "🤖"}
        </button>
        {aiOpen && <AIPanel onClose={() => setAiOpen(false)} />}
      </ToastProvider>
    </KitchenProvider>
  );
}
