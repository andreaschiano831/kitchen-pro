// FIX: AppShell and AppLayout were both rendering TopBar/BottomNav
// Solution: Use only AppShell (via App.tsx) — AppLayout.tsx is now unused.
// App.tsx should use AppShell as root wrapper, not AppLayout.

import { useState } from "react";
import TopBar from "./TopBar";
import BottomNav from "./BottomNav";
import AIAssistant from "../components/AIAssistant";

export default function AppShell({ children }: { children: React.ReactNode }) {
  const [aiOpen, setAiOpen] = useState(false);

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <TopBar />

      <main
        className="container"
        style={{ paddingBottom: 88, paddingTop: 16, flex: 1 }}
      >
        {children}
      </main>

      <BottomNav />

      {/* AI Floating Action Button */}
      <button
        onClick={() => setAiOpen((p) => !p)}
        title="AI Kitchen Assistant"
        style={{
          position: "fixed", bottom: 90, right: 18, zIndex: 60,
          width: 52, height: 52, borderRadius: "50%",
          background: "linear-gradient(135deg, var(--accent), #b03030)",
          color: "#fff", border: "none", cursor: "pointer", fontSize: "1.4rem",
          boxShadow: "0 4px 20px rgba(122,12,12,.4)",
          display: "flex", alignItems: "center", justifyContent: "center",
          transition: "transform .2s, box-shadow .2s",
        }}
        onMouseEnter={(e) => { (e.target as HTMLElement).style.transform = "scale(1.08)"; }}
        onMouseLeave={(e) => { (e.target as HTMLElement).style.transform = "scale(1)"; }}
      >
        {aiOpen ? "✕" : "🤖"}
      </button>

      {aiOpen && <AIAssistant onClose={() => setAiOpen(false)} />}
    </div>
  );
}
